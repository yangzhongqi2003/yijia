#!/usr/bin/env sh
# 1000亿级场景：每个表先 SQL 查询 id 范围，再按范围并行执行 full。
# 用法（自动按表查 min/max id）：
#   WORKERS=8 sh run_parallel_full.sh
# 可选：
#   WHERE_SQL='instime>=1710000000 AND instime<1710100000' ACTION_AFTER=post sh run_parallel_full.sh
# 手工覆盖全局范围（会覆盖自动探测）：
#   RANGE_START=1 RANGE_END=100000000 WORKERS=8 sh run_parallel_full.sh

set -eu

SCRIPT="$(cd "$(dirname "$0")" && pwd)/mysql_to_mongo_restore.php"
LOG_DIR="$(cd "$(dirname "$0")" && pwd)/runtime/logs"
mkdir -p "$LOG_DIR"

# ===== 基础配置（可用环境变量覆盖） =====
MYSQL_HOST="${MYSQL_HOST:-mysql-idn-tr-instance-1.c3ykomem8ks1.ap-southeast-3.rds.amazonaws.com}"
MYSQL_PORT="${MYSQL_PORT:-3306}"
MYSQL_USER="${MYSQL_USER:-admin}"
MYSQL_PASS="${MYSQL_PASS:-BBup%&iCg26icgLd}"
MYSQL_DB="${MYSQL_DB:-pay}"
MYSQL_PREFIX="${MYSQL_PREFIX:-pay_}"

MONGO_URI="${MONGO_URI:-mongodb://mongodb-headless.mongodb-idn-tr:27017}"
MONGO_DB="${MONGO_DB:-coldpay}"
MONGO_USER="${MONGO_USER:-root}"
MONGO_PASS="${MONGO_PASS:-j25OuvEvLjdPbdJB}"
MONGO_AUTH_DB="${MONGO_AUTH_DB:-admin}"

WORKERS="${WORKERS:-8}"
RANGE_START="${RANGE_START:-}"
RANGE_END="${RANGE_END:-}"
WHERE_SQL="${WHERE_SQL:-}"

BATCH_SIZE="${BATCH_SIZE:-5000}"
SLEEP_MS="${SLEEP_MS:-0}"
CHECKPOINT_EVERY_BATCHES="${CHECKPOINT_EVERY_BATCHES:-20}"
MYSQL_RETRIES="${MYSQL_RETRIES:-5}"
MONGO_RETRIES="${MONGO_RETRIES:-5}"
RETRY_BASE_MS="${RETRY_BASE_MS:-200}"
RETRY_MAX_MS="${RETRY_MAX_MS:-5000}"

# 1=每个映射开始前先 clear（只清不写）；0=不清（续跑）
CLEAR_FIRST="${CLEAR_FIRST:-1}"
# 全量模式（auto/insert/upsert）：auto 下 clear 场景走 insert，更快
FULL_MODE="${FULL_MODE:-auto}"
# 续跑策略（auto/0/1）：auto 下 clear 场景关 resume，续跑场景开 resume
RESUME="${RESUME:-auto}"
# none | post（full 全部完成后再跑 index/verify/repair/verify）
ACTION_AFTER="${ACTION_AFTER:-none}"
# 1=某个表不存在时跳过；0=遇到不存在直接失败
SKIP_MISSING_TABLE="${SKIP_MISSING_TABLE:-1}"

if [ "$WORKERS" -le 0 ]; then
  echo "ERROR: WORKERS must be > 0" >&2
  exit 1
fi

run_php() {
  php "$SCRIPT" \
    --mysql-host="$MYSQL_HOST" --mysql-port="$MYSQL_PORT" --mysql-user="$MYSQL_USER" --mysql-pass="$MYSQL_PASS" \
    --mysql-db="$MYSQL_DB" --mysql-table-prefix="$MYSQL_PREFIX" \
    --mongo-uri="$MONGO_URI" --mongo-db="$MONGO_DB" --mongo-user="$MONGO_USER" --mongo-pass="$MONGO_PASS" --mongo-auth-db="$MONGO_AUTH_DB" \
    --batch-size="$BATCH_SIZE" --sleep-ms="$SLEEP_MS" \
    --checkpoint-every-batches="$CHECKPOINT_EVERY_BATCHES" \
    --mysql-retries="$MYSQL_RETRIES" --mongo-retries="$MONGO_RETRIES" \
    --retry-base-ms="$RETRY_BASE_MS" --retry-max-ms="$RETRY_MAX_MS" \
    --quiet=1 \
    "$@"
}

query_bounds() {
  mysql_table="$1"
  full_table="$mysql_table"
  case "$full_table" in
    "$MYSQL_PREFIX"*) ;;
    *) full_table="${MYSQL_PREFIX}${mysql_table}" ;;
  esac

  TABLE_NAME="$full_table" \
  WHERE_SQL="$WHERE_SQL" \
  MYSQL_HOST="$MYSQL_HOST" MYSQL_PORT="$MYSQL_PORT" MYSQL_USER="$MYSQL_USER" MYSQL_PASS="$MYSQL_PASS" MYSQL_DB="$MYSQL_DB" \
  php -r '
    try {
        $table = (string)(getenv("TABLE_NAME") ?: "");
        if (!preg_match("/^[A-Za-z0-9_]+$/", $table)) {
            fwrite(STDERR, "invalid table name: {$table}\n");
            exit(2);
        }
        $where = trim((string)(getenv("WHERE_SQL") ?: ""));
        $dsn = sprintf(
            "mysql:host=%s;port=%d;dbname=%s;charset=utf8mb4",
            (string)getenv("MYSQL_HOST"),
            (int)getenv("MYSQL_PORT"),
            (string)getenv("MYSQL_DB")
        );
        $pdo = new PDO($dsn, (string)getenv("MYSQL_USER"), (string)getenv("MYSQL_PASS"), [
            PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
        ]);
        $sql = "SELECT MIN(`id`) AS min_id, MAX(`id`) AS max_id, COUNT(*) AS row_count FROM `{$table}`";
        if ($where !== "") {
            $sql .= " WHERE ({$where})";
        }
        $row = $pdo->query($sql)->fetch() ?: [];
        if (($row["min_id"] ?? null) === null || ($row["max_id"] ?? null) === null) {
            echo "EMPTY\tEMPTY\t0";
            exit(0);
        }
        echo (int)$row["min_id"] . "\t" . (int)$row["max_id"] . "\t" . (int)$row["row_count"];
    } catch (Throwable $e) {
        fwrite(STDERR, $e->getMessage() . "\n");
        exit(3);
    }
  '
}

run_mapping_full() {
  mysql_table="$1"
  mongo_collection="$2"
  mapping="${mysql_table}:${mongo_collection}"

  run_mode="$FULL_MODE"
  if [ "$run_mode" = "auto" ]; then
    if [ "$CLEAR_FIRST" = "1" ]; then
      run_mode="insert"
    else
      run_mode="upsert"
    fi
  fi
  case "$run_mode" in
    insert|upsert) ;;
    *)
      echo "ERROR: FULL_MODE must be auto/insert/upsert, got: $FULL_MODE" >&2
      return 1
      ;;
  esac

  run_resume="$RESUME"
  if [ "$run_resume" = "auto" ]; then
    if [ "$CLEAR_FIRST" = "1" ]; then
      run_resume="0"
    else
      run_resume="1"
    fi
  fi
  case "$run_resume" in
    0|1) ;;
    *)
      echo "ERROR: RESUME must be auto/0/1, got: $RESUME" >&2
      return 1
      ;;
  esac

  bounds=""
  if [ -n "$RANGE_START" ] && [ -n "$RANGE_END" ]; then
    bounds="${RANGE_START}	${RANGE_END}"
  else
    if ! bounds="$(query_bounds "$mysql_table" 2>/tmp/rebuild_mongo_bounds.err)"; then
      err_msg="$(cat /tmp/rebuild_mongo_bounds.err 2>/dev/null || true)"
      if [ "$SKIP_MISSING_TABLE" = "1" ] && echo "$err_msg" | grep -qi "doesn't exist\|does not exist\|1146"; then
        echo "[skip] missing table for mapping=${mapping}"
        return 0
      fi
      echo "[error] query bounds failed for mapping=${mapping}: $err_msg" >&2
      return 1
    fi
  fi

  min_id="$(echo "$bounds" | awk -F '\t' '{print $1}')"
  max_id="$(echo "$bounds" | awk -F '\t' '{print $2}')"
  row_count="$(echo "$bounds" | awk -F '\t' '{print $3}')"
  if [ "$min_id" = "EMPTY" ] || [ "$max_id" = "EMPTY" ]; then
    echo "[skip] no rows for mapping=${mapping}"
    if [ "$CLEAR_FIRST" = "1" ]; then
      if [ -n "$WHERE_SQL" ]; then
        run_php --action=full --tables="$mapping" --clear-target=1 --start-id=1 --end-id=0 --where="$WHERE_SQL"
      else
        run_php --action=full --tables="$mapping" --clear-target=1 --start-id=1 --end-id=0
      fi
    fi
    return 0
  fi

  if [ "$CLEAR_FIRST" = "1" ]; then
    echo "[prep] clear mapping=${mapping}"
    if [ -n "$WHERE_SQL" ]; then
      run_php --action=full --tables="$mapping" --clear-target=1 --start-id=1 --end-id=0 --where="$WHERE_SQL"
    else
      run_php --action=full --tables="$mapping" --clear-target=1 --start-id=1 --end-id=0
    fi
  fi

  total=$((max_id - min_id + 1))
  id_diff=$((max_id - min_id))
  effective_workers="$WORKERS"
  if [ "$row_count" -gt 0 ] && [ "$row_count" -lt "$WORKERS" ]; then
    effective_workers="$row_count"
  fi
  if [ "$effective_workers" -le 0 ]; then
    effective_workers=1
  fi
  chunk=$(((total + effective_workers - 1) / effective_workers))
  density_ppm=0
  if [ "$total" -gt 0 ]; then
    density_ppm=$((row_count * 1000000 / total))
  fi
  mapping_start_at="$(date '+%Y-%m-%d %H:%M:%S')"
  echo "[run] mapping=${mapping} workers=${effective_workers}/${WORKERS} mode=${run_mode} resume=${run_resume} start_time='${mapping_start_at}' id_start=${min_id} id_end=${max_id} id_diff=${id_diff} row_count=${row_count} id_span=${total} density_ppm=${density_ppm} chunk=${chunk}"
  mapping_start_ts="$(date +%s)"

  i=0
  worker_meta=""
  while [ "$i" -lt "$effective_workers" ]; do
    start_id=$((min_id + i * chunk))
    if [ "$start_id" -gt "$max_id" ]; then
      break
    fi
    end_id=$((start_id + chunk - 1))
    if [ "$end_id" -gt "$max_id" ]; then
      end_id="$max_id"
    fi

    safe_coll="$(echo "$mongo_collection" | tr -c 'A-Za-z0-9_-' '_')"
    log_file="$LOG_DIR/full_${mysql_table}_${safe_coll}_worker_${i}.log"
    worker_id_diff=$((end_id - start_id))
    worker_start_at="$(date '+%Y-%m-%d %H:%M:%S')"
    echo "[worker-$i] start mapping=${mapping} start_time='${worker_start_at}' id_start=${start_id} id_end=${end_id} id_diff=${worker_id_diff} log=${log_file}"
    worker_start_ts="$(date +%s)"
    if [ -n "$WHERE_SQL" ]; then
      run_php --action=full --tables="$mapping" --clear-target=0 --resume="$run_resume" --mode="$run_mode" --worker-id="${mysql_table}-${i}" --start-id="$start_id" --end-id="$end_id" --where="$WHERE_SQL" >"$log_file" 2>&1 &
    else
      run_php --action=full --tables="$mapping" --clear-target=0 --resume="$run_resume" --mode="$run_mode" --worker-id="${mysql_table}-${i}" --start-id="$start_id" --end-id="$end_id" >"$log_file" 2>&1 &
    fi
    pid="$!"
    worker_meta="${worker_meta}
${pid}|${i}|${start_id}|${end_id}|${worker_start_ts}|${worker_start_at}|${log_file}"
    i=$((i + 1))
  done

  failed=0
  OLD_IFS="$IFS"
  IFS='
'
  for item in $worker_meta; do
    [ -z "$item" ] && continue
    IFS='|'
    set -- $item
    IFS='
'
    pid="$1"
    worker_idx="$2"
    worker_s="$3"
    worker_e="$4"
    worker_start="$5"
    worker_start_at="$6"
    worker_log="$7"

    if wait "$pid"; then
      worker_status="ok"
    else
      worker_status="fail"
      failed=1
    fi
    worker_end="$(date +%s)"
    worker_end_at="$(date '+%Y-%m-%d %H:%M:%S')"
    worker_elapsed=$((worker_end - worker_start))
    worker_id_diff=$((worker_e - worker_s))
    echo "[worker-${worker_idx}] done mapping=${mapping} status=${worker_status} start_time='${worker_start_at}' end_time='${worker_end_at}' elapsed=${worker_elapsed}s id_start=${worker_s} id_end=${worker_e} id_diff=${worker_id_diff} log=${worker_log}"
  done
  IFS="$OLD_IFS"
  if [ "$failed" -ne 0 ]; then
    echo "[error] some workers failed for mapping=${mapping}, check logs in $LOG_DIR" >&2
    return 1
  fi

  mapping_end_ts="$(date +%s)"
  mapping_end_at="$(date '+%Y-%m-%d %H:%M:%S')"
  mapping_elapsed=$((mapping_end_ts - mapping_start_ts))
  echo "[done] full finished mapping=${mapping} start_time='${mapping_start_at}' end_time='${mapping_end_at}' elapsed=${mapping_elapsed}s id_start=${min_id} id_end=${max_id} id_diff=${id_diff} row_count=${row_count}"
  return 0
}

run_mapping_post() {
  mysql_table="$1"
  mongo_collection="$2"
  mapping="${mysql_table}:${mongo_collection}"
  echo "[post] mapping=${mapping} index"
  if [ -n "$WHERE_SQL" ]; then
    run_php --action=index --tables="$mapping" --where="$WHERE_SQL"
  else
    run_php --action=index --tables="$mapping"
  fi
}

MAPPINGS="
order:mch_bak_order_{mid}
order:order
payout_order:mch_bak_payout_order_{mid}
payout_order:payout_order
merchant_bill_binlog:mch_bak_merchant_bill_log_{mid}
merchant_bill_log:mch_bak_merchant_bill_log_{mid}
source_order:source_order
payout_source_order:payout_source_order
"

overall_failed=0

for mapping in $MAPPINGS; do
  mysql_table="$(echo "$mapping" | awk -F ':' '{print $1}')"
  mongo_collection="$(echo "$mapping" | awk -F ':' '{print $2}')"
  if ! run_mapping_full "$mysql_table" "$mongo_collection"; then
    overall_failed=1
    break
  fi
done

if [ "$overall_failed" -ne 0 ]; then
  exit 1
fi

if [ "$ACTION_AFTER" = "post" ]; then
  for mapping in $MAPPINGS; do
    mysql_table="$(echo "$mapping" | awk -F ':' '{print $1}')"
    mongo_collection="$(echo "$mapping" | awk -F ':' '{print $2}')"
    run_mapping_post "$mysql_table" "$mongo_collection"
  done
fi
