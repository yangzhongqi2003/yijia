<?php
declare(strict_types=1);

/**
 * Mature one-file MySQL -> Mongo sync tool (native PHP).
 *
 * 说明（通俗易懂）：
 * - 纯原生 `PHP CLI` 脚本：不依赖你项目的框架启动流程/路由/ORM。
 * - 直接用 `PDO(MySQL)` + `MongoDB Driver` 连库同步数据。
 * - 用 `--action=full/index/verify/repair/ping` 分阶段跑：先回灌、再建索引、再校验、最后补差；`ping` 只做连通性检查。
 * - 用 `--progress-file` + `--resume=1` 支持断点续跑（每批记录 start_id/end_id/last_end_id）。
 * - 对 `mch_bak_*_{mid}` 这类集合，按项目的 `rowDefault` 做字段白名单裁剪，尽量保证 Mongo 结构跟线上一致。
 *
 * 参数控制（五个阶段）：
 * - `--action=full`   ：按主键 `id` 游标分批回灌（带断点续跑）。
 * - `--action=index`  ：给 Mongo 目标集合创建索引（固定集合按集合名；`mch_bak_*_{mid}` 会对每个 merchant 的 mid 建同样的索引）。
 * - `--action=verify` ：校验 MySQL 与 Mongo 是否一致：
 *   - 默认走“按区间 range 校验”，数据太大建议用 `--verify-mode=count`（只比对总数；repair 再用完整 id 范围补齐）。
 * - `--action=repair` ：读取 `verify` 产生的 diff 文件，只针对不一致的 id 区间进行补齐（`upsert` 写入）。
 * - `--action=ping`   ：只创建连接并发起最小 ping（不迁移、不建索引、不查表数据）。
 *
 * {mid} 模板说明：
 * - 对每个商户的动态集合模板，用 `{mid}` 占位，例如 `mch_bak_order_{mid}`。
 *
 * 索引策略：
 * - 脚本只使用内置索引定义，不依赖外部 JSON 文件（用于重建时可控、可复现）。
 *
 * MchBak “字段对齐”逻辑（对齐你项目的 BaseBakModel）：
 * - 写入 `mch_bak_*_{mid}` 时，只保留与线上 `$rowDefault` 相同的字段（不会把 mid 存进 Mongo 文档）。
 * - `merchant_bill_log` + `merchant_bill_binlog` 会共享 `mch_bak_merchant_bill_log_{mid}`：
 *   因为这两张表的自增 id 可能会冲突，所以 **任务清单里**先 binlog、后 bill_log，
 *   从而在 `upsert` 冲突时让主表 `merchant_bill_log` 后写入、覆盖 binlog（与“同集合同 id”策略一致）。
 * - `--preset=project6` / `all6`：**只负责生成固定的 8 条表映射任务**，并在 `verify` 且未显式传 `--verify-mode` 时默认用 `count`。
 *   **不会**在一次 `php` 命令里自动串联 full → index → verify → repair；每个阶段都要你分别指定 `--action` 各跑一遍。
 *
 * 性能提示（大数据量）：
 * - `full`：MySQL 端用 id seek（`WHERE id > ? ORDER BY id LIMIT n`），你需要确保（id + where 相关列）的组合索引有效。
 *   一个 batch 可能同时包含多个 mid（动态集合）→ 会对多个 Mongo 集合分别 bulk 写。
 *   你可以在内存允许的情况下适当增大 `--batch-size`；必要时用 `--sleep-ms` 节流；也建议用 MySQL 从库并分段用多个进程跑。
 * - `verify`：`project6/all6` 默认 `--verify-mode=count`（更快）；如果改 `range` 会变成“商户 × id 切片”的大量 count 查询，要避免在超大规模下直接跑。
 * - `index`：对 `mch_bak` 大致是“商户数 × 索引数”的复杂度；建议非高峰期做。
 *   另外在集合特别大时，Mongo count 也会偏慢，所以尽量先建好索引再 verify。
 */

if (PHP_SAPI !== 'cli') {
    fwrite(STDERR, "CLI only.\n");
    exit(1);
}
if (!extension_loaded('pdo_mysql')) {
    fwrite(STDERR, "Missing extension pdo_mysql.\n");
    exit(1);
}
if (!class_exists('\MongoDB\Driver\Manager')) {
    fwrite(STDERR, "Missing mongodb extension.\n");
    exit(1);
}

/*
 * ---------------------------------------------------------------------------
 * 配置从哪来？——全部靠「命令行参数」，没有单独的 .env / ini 文件。
 *
 * 运行方式：`php mysql_to_mongo_restore.php --mysql-host=... --mysql-user=... ...`
 * （长选项必须写成 `--name=value` 或 `--name value`，与项目里其它脚本习惯一致即可。）
 *
 * 【连库五件套（推荐显式传）】不传时会回落到下方“默认配置”
 *   --mysql-host     MySQL 地址（例：`127.0.0.1` 或 `rm-xxxx.mysql.rds.aliyuncs.com`）
 *   --mysql-user     MySQL 用户名（例：`pay`）
 *   --mysql-db       MySQL 库名（例：`pay`；脚本会把表当成 `mysql-db`.`order` 这类）
 *   --mongo-uri      Mongo 连接串（例：`mongodb://127.0.0.1:27017`）
 *   --mongo-db       Mongo 数据库名（例：`onepaynew`，集合会建在该库下）
 *
 * 【可选 —— Mongo 认证（推荐用参数显式传）】
 *   --mongo-user     Mongo 账号（username）
 *   --mongo-pass     Mongo 密码（password）
 *   --mongo-auth-db  认证库（authSource），例如 `admin`（不传则不强制追加 authSource 参数）
 *
 * 【选传 —— MySQL】
 *   --mysql-pass     MySQL 密码（例：`MYSQL_PASS`；可不传）
 *   --mysql-port     端口，默认 `3306`（例：`3306`）
 *
 * 【选传 —— 迁哪些表】
 *   --tables         映射：`mysql表:mongo集合`，多个用逗号（例：
 *                   `order:mch_bak_order_{mid},payout_order:mch_bak_payout_order_{mid}`）
 *                   你如果不写，就必须配合 --preset。
 *   --preset         用脚本内置任务清单（例：`project6` 或 `all6`），省去手写 --tables。
 *
 * 【选传 —— 流程】
 *   --action         `full | index | verify | repair | ping`（默认 `full`）
 *                   其中 `ping` 只检查连通性，不做数据迁移/索引/校验。
 *
 * where 参数说明（非常重要）：
 * - where 是 MySQL 的“SQL 片段”，脚本会原样拼到 SQL 里，并用在 full/verify/repair。
 * - 不要写关键字 WHERE（因为脚本内部会拼 WHERE）。
 * - 例：`--where="updtime>=1710000000 AND updtime<1710100000"`
 *
 * 快速示例（你本地 Mongo 默认走 onepaynew；若 MySQL 表名有前缀请用 --mysql-table-prefix）：
 * 1) 测连通（Mongo 成功 + MySQL 成功才算全通）：
 *    php mysql_to_mongo_restore.php --action=ping
 * 2) 重建 Mongo（drop 旧集合 + 写新数据）：
 *    php mysql_to_mongo_restore.php --action=full --preset=project6 --clear-target=1 --mysql-table-prefix=pay_
 * 3) 建索引：
 *    php mysql_to_mongo_restore.php --action=index --preset=project6 --mysql-table-prefix=pay_
 * 4) 对账（强烈建议大数据用 count）：
 *    php mysql_to_mongo_restore.php --action=verify --preset=project6 --verify-mode=count --mysql-table-prefix=pay_
 * 5) 补差：
 *    php mysql_to_mongo_restore.php --action=repair --preset=project6 --mysql-table-prefix=pay_
 *
 * 如果你这几个步骤都需要（推荐顺序：full -> index -> verify -> repair -> verify），可以直接执行下面这一套：
 *
 *   SCRIPT="/Users/mac/php-project/pay/scripts/mysql_to_mongo_restore.php"
 *
 *   # 0) 连通性（可选，但建议先跑）
 *   php "$SCRIPT" --action=ping
 *
 *   # 1) FULL：重建 Mongo 数据（会按 preset 遍历所有任务；clear-target=1 会 drop 目标集合后重写）
 *   php "$SCRIPT" --action=full   --preset=project6 --clear-target=1 --mysql-table-prefix=pay_ --quiet
 *
 *   # 2) INDEX：给目标集合建索引（脚本只使用内置索引定义）
 *   php "$SCRIPT" --action=index  --preset=project6 --mysql-table-prefix=pay_ --quiet
 *
 *   # 3) VERIFY：对账校验（count 只比数量，速度快；range 会切片很多次 count，超大数据不建议）
 *   php "$SCRIPT" --action=verify --preset=project6 --verify-mode=count --mysql-table-prefix=pay_ --quiet
 *
 *   # 4) REPAIR：读取 diff-file，只对不一致区间做 upsert 补齐
 *   php "$SCRIPT" --action=repair --preset=project6 --mysql-table-prefix=pay_ --quiet
 *
 *   # 5) 再跑一次 VERIFY：确认 repair 后已一致
 *   php "$SCRIPT" --action=verify --preset=project6 --verify-mode=count --mysql-table-prefix=pay_ --quiet
 *
 * 其余参数见下面 getopt 列表旁的注释。
 * ---------------------------------------------------------------------------
 */

$opts = getopt('', [
    // 要跑哪一阶段：full 回灌 / index 建索引 / verify 对账 / repair 按 diff 补漏
    'action::', // 例：`--action=full`；也可 `index/verify/repair/ping`
    // 内置任务清单：project6、all6（与 --tables 二选一逻辑在 resolveTableTasks）
    'preset::', // 例：`--preset=project6`（或 `all6`）

    // —— MySQL 连接（host/user/db 必填；pass、port 可选）——
    'mysql-host:', // 例：`--mysql-host=127.0.0.1`
    'mysql-port::', // 例：`--mysql-port=3306`
    'mysql-user:', // 例：`--mysql-user=pay`
    'mysql-pass::', // 例：`--mysql-pass=MYSQL_PASS`
    'mysql-db:', // 例：`--mysql-db=pay`
    // MySQL 表名前缀：例如 pre=pay_ 时，preset 里的 order -> pay_order
    'mysql-table-prefix:', // 例：`--mysql-table-prefix=pay_`

    // —— Mongo 连接 ——
    'mongo-uri:', // 例：`--mongo-uri=mongodb://127.0.0.1:27017`
    'mongo-db:', // 例：`--mongo-db=onepaynew`
    'mongo-user::', // 例：`--mongo-user=myuser`
    'mongo-pass::', // 例：`--mongo-pass=mypass`
    'mongo-auth-db::', // 例：`--mongo-auth-db=admin`

    // 表映射；例：order:mch_bak_order_{mid},payout_order:mch_bak_payout_order_{mid}
    'tables::', // 例：`--tables="order:order,payout_order:payout_order"`
    // MySQL 里用作游标、与 Mongo 文档里对齐的业务主键字段名，默认 id
    'id-field::', // 例：`--id-field=id`（默认）或 `--id-field=order_id`
    // 历史上预留；当前脚本写死为空，Mongo 的 _id 不会从 MySQL 某列映射（避免类型/语义问题）
    'mongo-id-from::', // 目前脚本默认写死为空（不读取该参数）

    // insert 只插入；upsert 可重复跑、按主键覆盖/补齐（默认 upsert）
    'mode::', // 例：`--mode=upsert`（默认）或 `--mode=insert`
    'batch-size::', // 例：`--batch-size=2000`
    // 1=先 drop 目标集合再灌；0=保留已有数据（适合续跑、增量）
    'clear-target::', // 例：`--clear-target=1`
    'start-id::', // 例：`--start-id=1000`
    'end-id::', // 例：`--end-id=2000`
    // 额外 AND 条件，原样拼进 SQL，常用时间窗：如 updtime 范围（四处阶段要保持一致）
    'where::', // 例：`--where="updtime>=1710000000 AND updtime<1710100000"`
    // 1=读 progress 文件从上次 last_end_id+1 继续
    'resume::', // 例：`--resume=1`
    'progress-file::', // 例：`--progress-file=/tmp/p.jsonl`
    'diff-file::', // 例：`--diff-file=/tmp/d.jsonl`
    'verify-range-size::', // 例：`--verify-range-size=100000`（仅 range 模式用）
    'verify-mode::', // 例：`--verify-mode=count`（大数据建议）
    // quiet：减少终端输出（主要是每 batch 的日志），不影响写入 progress/diff/数据。
    'quiet::', // 例：`--quiet=1`（默认不安静）
    // 每批写完 Mongo 后休眠毫秒数，给库降压
    'sleep-ms::', // 例：`--sleep-ms=50`
    // 每 N 批写一次 progress（1=每批都写；N>1 可降低 I/O，但宕机会回退到最近 checkpoint）
    'checkpoint-every-batches::', // 例：`--checkpoint-every-batches=20`
    // MySQL/Mongo 操作失败时重试次数（0=不重试）
    'mysql-retries::', // 例：`--mysql-retries=5`
    'mongo-retries::', // 例：`--mongo-retries=5`
    // 指数退避参数（毫秒）
    'retry-base-ms::', // 例：`--retry-base-ms=200`
    'retry-max-ms::', // 例：`--retry-max-ms=5000`
    // worker 标识（多进程并行时用于日志/进度定位）
    'worker-id::', // 例：`--worker-id=3`
]);

/*
 * ---------------------------------------------------------------------------
 * 默认配置（用于你本地测试快速连通）
 * 说明：
 * - 这是“默认值”，你仍然可以用命令行参数覆盖（--mysql-host/--mongo-uri 等）。
 * - 注意：这里直接写入了密码。请不要把该文件提交到代码仓库。
 * ---------------------------------------------------------------------------
 */
$defaultMongoUri = 'mongodb://127.0.0.1:27017';
$defaultMongoDb = 'onepaynew';

// mysql 配置：按你给的 default[...] 里字段映射到脚本真正会用到的部分
$defaultMysqlConfig = [
    'host' => 'rm-uf6go72d3o53gs3co1o.mysql.rds.aliyuncs.com',
    'port' => 3306,
    'user' => 'pay',
    'password' => 'mLP5amPY*MEk@ZZ5F8',
    'database' => 'pay',
    'pre' => 'pay_',
];

// 默认值回填（仅当 CLI 未传或传空）
$defaults = [
    'mongo-uri' => $defaultMongoUri,
    'mongo-db' => $defaultMongoDb,
    'mysql-host' => $defaultMysqlConfig['host'],
    'mysql-port' => (string)$defaultMysqlConfig['port'],
    'mysql-user' => $defaultMysqlConfig['user'],
    'mysql-pass' => $defaultMysqlConfig['password'],
    'mysql-db' => $defaultMysqlConfig['database'],
    'mysql-table-prefix' => (string)($defaultMysqlConfig['pre'] ?? ''),
];
foreach ($defaults as $key => $value) {
    if (!isset($opts[$key]) || $opts[$key] === '') {
        $opts[$key] = $value;
    }
}

// 这 5 个键在“默认回填后”必须有值，否则说明配置仍不完整。
$required = ['mysql-host', 'mysql-user', 'mysql-db', 'mongo-uri', 'mongo-db'];
foreach ($required as $key) {
    if (!isset($opts[$key]) || $opts[$key] === '') {
        fwrite(STDERR, "Missing required config: {$key}\n");
        exit(1);
    }
}

// 必填已齐；下面把字符串选项转成变量，最后 createPdo / createMongo 真正建连接。
$action = strtolower((string)($opts['action'] ?? 'full'));
$preset = strtolower((string)($opts['preset'] ?? ''));
$mysqlPort = isset($opts['mysql-port']) ? (int)$opts['mysql-port'] : 3306;
$idField = (string)($opts['id-field'] ?? 'id');
// 断点续跑和“分批游标”用的就是这个字段（默认表主键叫 `id`）
// 如果你的 MySQL 主键不是 `id`，请务必传 `--id-field=你的字段名`
// --mongo-id-from 逻辑禁用：保证脚本绝不把 MySQL 字段写入 Mongo 文档 _id（防止被改成数字）
$mongoIdFrom = '';

// 写入策略：
// - `--mode=insert`：只 insert，不会更新已有数据（一般不推荐用于“可重复跑”的补漏流程）
// - `--mode=upsert`：同一个主键(idField)重复执行会“更新/补齐”，所以可以多次跑到一致
$mode = strtolower((string)($opts['mode'] ?? 'upsert'));

// 每批从 MySQL 拉取多少行，再一次性 bulk 写到 Mongo。
// 数据量巨大时：建议逐步调大（但太大可能吃内存/超时）。
$batchSize = max(1, (int)($opts['batch-size'] ?? 2000));

// 是否清空目标 Mongo 集合再全量回灌：
// - `--clear-target=1`：会 drop 目标集合（包括 {mid} 动态集合会逐 mid drop）
// - `--clear-target=0`：不会 drop（适合你已经有部分数据时做断点续跑/增量补漏）
$clearTarget = !empty($opts['clear-target']) && (string)$opts['clear-target'] !== '0';

// 这两个参数主要用于“分片/分段”处理（以及配合 resume 定位）：
// - `--start-id` / `--end-id`：限定只处理 id 落在区间内的记录
$startId = isset($opts['start-id']) ? (int)$opts['start-id'] : null;
$endId = isset($opts['end-id']) ? (int)$opts['end-id'] : null;

// `--where` 是 SQL 片段，通常用于限制时间窗（你项目里通常是 `updtime` 或 `instime`）。
// 重要：请保证你在 full/index/verify/repair 里传的 where 完全一致，
// 否则“校验对比的时间窗口”和“回灌写入的时间窗口”可能对不上。
$where = trim((string)($opts['where'] ?? ''));
if ($where !== '' && preg_match('/\bupdtime\b/i', $where) === 1) {
    fwrite(STDERR, "Unsupported where: do not use updtime. Please use id/instime or other indexed columns.\n");
    exit(1);
}

// 断点续跑：
// - `--resume=1`：如果 progress-file 中已经有该“任务”的 last_end_id，就从 last_end_id+1 开始继续
$resume = !empty($opts['resume']) && (string)$opts['resume'] !== '0';

// progress-file：记录每次 batch 写成功后的进度（JSONL 每行一条记录）
// diff-file：verify 发现不一致后写出来的“差异证据”（JSONL 每行一条 diff）
$progressFile = (string)($opts['progress-file'] ?? (__DIR__ . '/runtime/mysql_to_mongo_progress.jsonl'));
$diffFile = (string)($opts['diff-file'] ?? (__DIR__ . '/runtime/mysql_to_mongo_diff.jsonl'));

// verify-range-size：当 verify-mode=range 时，把 [minId,maxId] 再切成一段段更小的区间，
// 逐段 count 对比，减少单次查询压力。
$verifyRangeSize = max(1, (int)($opts['verify-range-size'] ?? 100000));

// 校验模式：
// - `count`：只对比“总数量是否一致”（快，但不会告诉你具体缺了哪个子区间）
// - `range`：对比区间内数量（更细，但查询次数更多，超大数据会更慢）
$verifyMode = strtolower((string)($opts['verify-mode'] ?? 'range'));

// 节流（可选）：每批写入 Mongo 之后 sleep 一点点，避免把 Mongo 或 MySQL 打爆
$sleepMs = max(0, (int)($opts['sleep-ms'] ?? 0));
// 轻量 checkpoint：每 N 批落一条进度记录（N 越大，I/O 越低，但故障恢复会回退更多批次）
$checkpointEveryBatches = max(1, (int)($opts['checkpoint-every-batches'] ?? 1));
// 重试控制（超大规模长跑任务建议开启）
$mysqlRetries = max(0, (int)($opts['mysql-retries'] ?? 5));
$mongoRetries = max(0, (int)($opts['mongo-retries'] ?? 5));
$retryBaseMs = max(1, (int)($opts['retry-base-ms'] ?? 200));
$retryMaxMs = max($retryBaseMs, (int)($opts['retry-max-ms'] ?? 5000));
$workerId = trim((string)($opts['worker-id'] ?? ''));
// 全局控制台输出：减少大量 echo 的开销与噪音
$QUIET = !empty($opts['quiet']) && (string)$opts['quiet'] !== '0';
$tablesOpt = (string)($opts['tables'] ?? '');
$mysqlTablePrefix = (string)($opts['mysql-table-prefix'] ?? '');
$tableTasks = resolveTableTasks($tablesOpt, $preset, $mysqlTablePrefix);

// tableTasks = “任务清单”：每条任务是一张 MySQL 表 -> 一个 Mongo 集合模板/实例
// preset=project6/all6 会生成多条任务（尤其包含 {mid} 动态集合）
if (empty($tableTasks) && $action !== 'ping') {
    fwrite(STDERR, "No valid table mapping in --tables.\n");
    exit(1);
}
if (!in_array($action, ['full', 'index', 'verify', 'repair', 'ping'], true)) {
    fwrite(STDERR, "--action must be one of: full/index/verify/repair/ping\n");
    exit(1);
}
if (!in_array($mode, ['insert', 'upsert'], true)) {
    fwrite(STDERR, "--mode must be insert or upsert\n");
    exit(1);
}
if (!in_array($verifyMode, ['range', 'count'], true)) {
    fwrite(STDERR, "--verify-mode must be range or count\n");
    exit(1);
}

if ($action === 'verify' && ($preset === 'project6' || $preset === 'all6') && !isset($opts['verify-mode'])) {
    $verifyMode = 'count';
}

// 真正建连：MySQL 用 host/port/db/user/pass；Mongo 用 URI（可额外通过 --mongo-user/--mongo-pass 注入认证）
$pdo = null;
try {
    $pdo = createPdo($opts, $mysqlPort);
} catch (Throwable $e) {
    if ($action === 'ping') {
        fwrite(STDERR, "MySQL connect failed (ping continues): " . $e->getMessage() . "\n");
    } else {
        throw $e;
    }
}

$mongoUser = (string)($opts['mongo-user'] ?? '');
$mongoPass = (string)($opts['mongo-pass'] ?? '');
$mongoAuthDb = (string)($opts['mongo-auth-db'] ?? '');
if (($mongoUser !== '' || $mongoPass !== '') && ($mongoUser === '' || $mongoPass === '')) {
    fwrite(STDERR, "Both --mongo-user and --mongo-pass are required when either one is set.\n");
    exit(1);
}
$mongoUri = buildMongoUri((string)$opts['mongo-uri'], $mongoUser, $mongoPass, $mongoAuthDb);

$mongo = createMongo($mongoUri);
$mongoDb = (string)$opts['mongo-db'];

switch ($action) {
    case 'full':
        runFull($pdo, $mongo, $mongoDb, $tableTasks, $idField, $mongoIdFrom, $mode, $batchSize, $clearTarget, $startId, $endId, $where, $resume, $progressFile, $sleepMs, $checkpointEveryBatches, $mysqlRetries, $mongoRetries, $retryBaseMs, $retryMaxMs, $workerId);
        break;
    case 'index':
        runIndex($pdo, $mongo, $mongoDb, $tableTasks, $where);
        break;
    case 'verify':
        runVerify($pdo, $mongo, $mongoDb, $tableTasks, $idField, $verifyRangeSize, $verifyMode, $diffFile, $where, $startId, $endId);
        break;
    case 'repair':
        runRepair($pdo, $mongo, $mongoDb, $tableTasks, $idField, $mongoIdFrom, $batchSize, $where, $diffFile, $progressFile, $sleepMs, $checkpointEveryBatches, $mysqlRetries, $mongoRetries, $retryBaseMs, $retryMaxMs, $workerId);
        break;
    case 'ping':
        runPing($pdo, $mongo, $mongoDb);
        break;
}

echo "All done.\n";

/**
 * runPing：只做最小连通性检查（不迁移、不建索引、不对账）。
 */
function runPing(?PDO $pdo, $mongo, string $mongoDb): void
{
    $exitCode = 0;

    // MySQL: 最小 SELECT 1（失败不直接退出，让你至少能看到 Mongo 是否通）
    if ($pdo === null) {
        fwrite(STDERR, "MySQL connect unavailable (skipped).\n");
        $exitCode = max($exitCode, 2);
    } else {
    try {
        $row = $pdo->query('SELECT 1 AS v')->fetch(PDO::FETCH_ASSOC);
        $v = $row['v'] ?? null;
        echo "MySQL ping ok: v=" . (string)$v . "\n";
    } catch (Throwable $e) {
        fwrite(STDERR, "MySQL ping failed: " . $e->getMessage() . "\n");
        $exitCode = max($exitCode, 2);
    }
    }

    // Mongo: executeCommand(ping)
    try {
        $cmdClass = 'MongoDB\\Driver\\Command';
        $cmd = new $cmdClass(['ping' => 1]);
        $cursor = $mongo->executeCommand($mongoDb, $cmd);

        $has = false;
        foreach ($cursor as $doc) {
            $has = true;
            break;
        }

        if ($has) {
            echo "Mongo ping ok: db={$mongoDb}\n";
        } else {
            fwrite(STDERR, "Mongo ping failed: empty cursor (db={$mongoDb})\n");
            $exitCode = max($exitCode, 3);
        }
    } catch (Throwable $e) {
        fwrite(STDERR, "Mongo ping failed: " . $e->getMessage() . "\n");
        $exitCode = max($exitCode, 4);
    }

    if ($exitCode !== 0) {
        exit($exitCode);
    }
}

/**
 * runFull：执行 `--action=full`。按任务清单串行把 MySQL 表数据分批同步到 Mongo（可 clear、可 resume、可 id 区间与 where）。
 */
function runFull(PDO $pdo, $mongo, string $mongoDb, array $tableTasks, string $idField, string $mongoIdFrom, string $mode, int $batchSize, bool $clearTarget, ?int $startId, ?int $endId, string $where, bool $resume, string $progressFile, int $sleepMs, int $checkpointEveryBatches, int $mysqlRetries, int $mongoRetries, int $retryBaseMs, int $retryMaxMs, string $workerId = ''): void
{
    global $QUIET;
    $progressState = loadProgressState($progressFile);
    $i = 0;
    $total = count($tableTasks);
    // 任务是串行执行的：一个任务写完所有批次才进入下一个任务
    // 这样断点续跑/校验定位会更清晰，也更好控制写 Mongo 的压力。
    foreach ($tableTasks as $task) {
        $mysqlTable = (string)($task['mysql_table'] ?? '');
        $mongoCollection = (string)($task['mongo_collection'] ?? '');
        $mchBakParity = !empty($task['mch_bak_parity']);
        if ($mysqlTable === '' || $mongoCollection === '') {
            continue;
        }
        $i++;
        if (!$QUIET) {
            echo sprintf("\n[%d/%d] FULL %s -> %s\n", $i, $total, $mysqlTable, $mongoCollection);
        }

        if ($clearTarget) {
            if (str_contains($mongoCollection, '{mid}')) {
                $mids = getDistinctMids($pdo, $mysqlTable, $where);
                foreach ($mids as $mid) {
                    dropCollection($mongo, $mongoDb, str_replace('{mid}', (string)$mid, $mongoCollection));
                }
                // 允许 mid 为空（null/''）：项目里 BaseBakModel::getTable($mid) 会把 null 拼成空字符串
                // 因此集合名会变成类似 mch_bak_order_ 这种“尾部带下划线”的形式。
                dropCollection($mongo, $mongoDb, str_replace('{mid}', '', $mongoCollection));
            } else {
                dropCollection($mongo, $mongoDb, $mongoCollection);
            }
        }

        $tableStart = $startId;
        $taskKey = taskKey($mysqlTable, $mongoCollection);
        if ($resume && isset($progressState[$taskKey]['last_end_id']) && is_numeric((string)$progressState[$taskKey]['last_end_id'])) {
            $resumeStart = (int)$progressState[$taskKey]['last_end_id'] + 1;
            if ($tableStart === null || $resumeStart > $tableStart) {
                $tableStart = $resumeStart;
            }
            if (!$QUIET) {
                echo "  - resume from id {$tableStart}\n";
            }
        }

        $count = syncRange(
            $pdo,
            $mongo,
            $mongoDb,
            $mysqlTable,
            $mongoCollection,
            $idField,
            $mongoIdFrom,
            $mode,
            $batchSize,
            $tableStart,
            $endId,
            $where,
            $progressFile,
            'full',
            null,
            $mchBakParity,
            $sleepMs,
            $checkpointEveryBatches,
            $mysqlRetries,
            $mongoRetries,
            $retryBaseMs,
            $retryMaxMs,
            $workerId
        );
        if (!$QUIET) {
            echo "  - done, rows={$count}\n";
        }
    }
}

/**
 * runIndex：执行 `--action=index`。按任务为 Mongo 集合创建索引；`{mid}` 模板会对每个商户 mid 建一套相同索引。
 */
function runIndex(PDO $pdo, $mongo, string $mongoDb, array $tableTasks, string $where): void
{
    global $QUIET;

    // 建索引逻辑（两层）：
    // 1) 先确定“要建哪些索引”（resolveIndexDefinitions）：基于集合名拿到 keys/options
    // 2) 如果集合是动态模板（包含 {mid}），就先查出有哪些 mid，然后对每个 mid 都创建同样的索引
    foreach ($tableTasks as $task) {
        $mysqlTable = (string)($task['mysql_table'] ?? '');
        $collection = (string)($task['mongo_collection'] ?? '');
        if ($mysqlTable === '' || $collection === '') {
            continue;
        }
        $defs = resolveIndexDefinitions($collection);
        if (!is_array($defs) || empty($defs)) {
            if (!$QUIET) {
                echo "INDEX {$mysqlTable} -> {$collection}: skip (no definitions)\n";
            }
            continue;
        }

        if (str_contains($collection, '{mid}')) {
            $mids = getDistinctMids($pdo, $mysqlTable, $where);
            if (!$QUIET) {
                echo "INDEX {$mysqlTable} -> {$collection}: " . count($mids) . " merchants\n";
            }
            // 注意：这里的 mid 列表来自 getDistinctMids（会过滤掉 NULL/空字符串），
            // 所以“空 mid 对应的集合（例如 mch_bak_order_）”不会被本次 index 去建。
            // 如果你希望把空 mid 也算进去，需要让 getDistinctMids 不过滤/或者额外补建。
            foreach ($mids as $mid) {
                $resolved = str_replace('{mid}', (string)$mid, $collection);
                foreach ($defs as $idx) {
                    $keys = indexDefKeys(is_array($idx) ? $idx : []);
                    if ($keys === null) {
                        continue;
                    }
                    $opts = $idx['options'] ?? [];
                    createIndex($mongo, $mongoDb, $resolved, $keys, is_array($opts) ? $opts : []);
                    if (!$QUIET) {
                        echo "  - {$resolved} keys=" . json_encode($keys, JSON_UNESCAPED_UNICODE) . "\n";
                    }
                }
            }
            continue;
        }

        foreach ($defs as $idx) {
            $keys = indexDefKeys(is_array($idx) ? $idx : []);
            if ($keys === null) {
                continue;
            }
            $opts = $idx['options'] ?? [];
            createIndex($mongo, $mongoDb, $collection, $keys, is_array($opts) ? $opts : []);
            if (!$QUIET) {
                echo "INDEX {$collection}: " . json_encode($keys, JSON_UNESCAPED_UNICODE) . "\n";
            }
        }
    }
}

/**
 * runVerify：执行 `--action=verify`。对比 MySQL 与 Mongo 行数（count 或按 id 分段 range），将差异写入 diff 文件供 repair 使用。
 */
function runVerify(PDO $pdo, $mongo, string $mongoDb, array $tableTasks, string $idField, int $rangeSize, string $verifyMode, string $diffFile, string $where, ?int $startId, ?int $endId): void
{
    global $QUIET;
    ensureParentDir($diffFile);
    file_put_contents($diffFile, '');

    // verify 会生成 diff-file（JSONL，每行一条）：
    // - type = diff
    // - verify_mode = count/range
    // - 给 repair 提供一个“证据链”：
    //   - count：用 [minId,maxId] 作为建议补齐区间
    //   - range：每个子区间都可能产生一条 diff（start_id/end_id）
    foreach ($tableTasks as $task) {
        $mysqlTable = (string)($task['mysql_table'] ?? '');
        $collection = (string)($task['mongo_collection'] ?? '');
        if ($mysqlTable === '' || $collection === '') {
            continue;
        }
        if (!$QUIET) {
            echo "\nVERIFY {$mysqlTable} -> {$collection} (mode={$verifyMode})\n";
        }

        // 校验模式：
        // - `count`：只比较“总数是否一致”（更快，适合超大数据量）
        // - `range`：按 id 切片区间逐段比较（更细，但通常更慢）
        if (str_contains($collection, '{mid}')) {
            $mids = getDistinctMids($pdo, $mysqlTable, $where);
            if (!$QUIET) {
                echo "  - merchants=" . count($mids) . " (per-mid collections, same as MchBakModel)\n";
            }
            // 同样注意：getDistinctMids 会过滤掉 NULL/空字符串 mid，
            // 因此 verify/repair 这条分支不会检查那些“尾部为空的集合名”（如 mch_bak_order_）。
            // 你的 syncRange 已经允许写入这种集合（mid 为空会被转成 ''），但校验/建索引需要额外考虑。
            $totalDiff = 0;
            foreach ($mids as $mid) {
                $resolved = str_replace('{mid}', (string)$mid, $collection);
                [$minId, $maxId] = getIdBoundsForMid($pdo, $mysqlTable, $idField, (int)$mid, $where, $startId, $endId);
                if ($minId === null || $maxId === null) {
                    continue;
                }

                if ($verifyMode === 'count') {
                    $mysqlCnt = countMysqlTotalForMid($pdo, $mysqlTable, (int)$mid, $where);
                    $mongoCnt = countMongoCollection($mongo, $mongoDb, $resolved);
                    if ($mysqlCnt !== $mongoCnt) {
                        $totalDiff++;
                        $row = [
                            'type' => 'diff',
                            'verify_mode' => 'count',
                            'time' => date('c'),
                            'mysql_table' => $mysqlTable,
                            'mongo_collection' => $resolved,
                            'mongo_collection_template' => $collection,
                            'mid' => (int)$mid,
                            'start_id' => $minId,
                            'end_id' => $maxId,
                            'mysql_count' => $mysqlCnt,
                            'mongo_count' => $mongoCnt,
                        ];
                        appendJsonLine($diffFile, $row);
                        echo "  - DIFF count mid={$mid} coll={$resolved} mysql={$mysqlCnt} mongo={$mongoCnt} (repair span id [{$minId},{$maxId}])\n";
                    }
                    continue;
                }

                $diffCount = 0;
                for ($s = $minId; $s <= $maxId; $s += $rangeSize) {
                    $e = min($s + $rangeSize - 1, $maxId);
                    $mysqlCnt = countMysqlRangeForMid($pdo, $mysqlTable, $idField, (int)$mid, $s, $e, $where);
                    $mongoCnt = countMongoRange($mongo, $mongoDb, $resolved, $idField, $s, $e);
                    if ($mysqlCnt !== $mongoCnt) {
                        $diffCount++;
                        $row = [
                            'type' => 'diff',
                            'verify_mode' => 'range',
                            'time' => date('c'),
                            'mysql_table' => $mysqlTable,
                            'mongo_collection' => $resolved,
                            'mongo_collection_template' => $collection,
                            'mid' => (int)$mid,
                            'start_id' => $s,
                            'end_id' => $e,
                            'mysql_count' => $mysqlCnt,
                            'mongo_count' => $mongoCnt,
                        ];
                        appendJsonLine($diffFile, $row);
                        echo "  - DIFF mid={$mid} coll={$resolved} range=[{$s},{$e}] mysql={$mysqlCnt} mongo={$mongoCnt}\n";
                    }
                }
                $totalDiff += $diffCount;
            }
            if (!$QUIET) {
                echo "  - verify complete, diff_entries={$totalDiff}\n";
            }
            continue;
        }

        [$minId, $maxId] = getIdBounds($pdo, $mysqlTable, $idField, $where, $startId, $endId);
        if ($minId === null || $maxId === null) {
            if (!$QUIET) {
                echo "  - skip (no data)\n";
            }
            continue;
        }

        if ($verifyMode === 'count') {
            $mysqlCnt = countMysqlTotal($pdo, $mysqlTable, $where);
            $mongoCnt = countMongoCollection($mongo, $mongoDb, $collection);
            if ($mysqlCnt !== $mongoCnt) {
                $row = [
                    'type' => 'diff',
                    'verify_mode' => 'count',
                    'time' => date('c'),
                    'mysql_table' => $mysqlTable,
                    'mongo_collection' => $collection,
                    'start_id' => $minId,
                    'end_id' => $maxId,
                    'mysql_count' => $mysqlCnt,
                    'mongo_count' => $mongoCnt,
                ];
                appendJsonLine($diffFile, $row);
                echo "  - DIFF count mysql={$mysqlCnt} mongo={$mongoCnt} (repair span id [{$minId},{$maxId}])\n";
            }
            if (!$QUIET) {
                echo "  - verify complete\n";
            }
            continue;
        }

        $diffCount = 0;
        for ($s = $minId; $s <= $maxId; $s += $rangeSize) {
            $e = min($s + $rangeSize - 1, $maxId);
            $mysqlCnt = countMysqlRange($pdo, $mysqlTable, $idField, $s, $e, $where);
            $mongoCnt = countMongoRange($mongo, $mongoDb, $collection, $idField, $s, $e);
            if ($mysqlCnt !== $mongoCnt) {
                $diffCount++;
                $row = [
                    'type' => 'diff',
                    'verify_mode' => 'range',
                    'time' => date('c'),
                    'mysql_table' => $mysqlTable,
                    'mongo_collection' => $collection,
                    'start_id' => $s,
                    'end_id' => $e,
                    'mysql_count' => $mysqlCnt,
                    'mongo_count' => $mongoCnt,
                ];
                appendJsonLine($diffFile, $row);
                echo "  - DIFF range=[{$s},{$e}] mysql={$mysqlCnt} mongo={$mongoCnt}\n";
            }
        }
        if (!$QUIET) {
            echo "  - verify complete, diff_ranges={$diffCount}\n";
        }
    }
}

/**
 * runRepair：执行 `--action=repair`。读取 verify 生成的 diff（JSONL），按区间（及可选 mid）调用 syncRange 以 upsert 补漏。
 */
function runRepair(PDO $pdo, $mongo, string $mongoDb, array $tableTasks, string $idField, string $mongoIdFrom, int $batchSize, string $where, string $diffFile, string $progressFile, int $sleepMs, int $checkpointEveryBatches, int $mysqlRetries, int $mongoRetries, int $retryBaseMs, int $retryMaxMs, string $workerId = ''): void
{
    global $QUIET;
    if (!is_file($diffFile)) {
        throw new RuntimeException("diff file not found: {$diffFile}");
    }
    $taskMap = [];
    foreach ($tableTasks as $task) {
        $mysql = (string)($task['mysql_table'] ?? '');
        $coll = (string)($task['mongo_collection'] ?? '');
        if ($mysql === '' || $coll === '') {
            continue;
        }
        $taskMap[taskKey($mysql, $coll)] = $task;
    }

    // repair 会读取 diff-file（JSONL），对其中每个 diff 条目做一次“定向回灌”：
    // - type=diff
    // - mysql_table / mongo_collection / start_id / end_id
    // - 对 dynamic {mid} 集合，如果 diff 中带了 mid，就用它精确过滤（filterMid）
    //
    // 然后用 syncRange(..., phase='repair', mode='upsert') 把差异区间补齐。
    // diff-file 可能会很大：用 SplFileObject 逐行读，避免一次性 file() 把全部内容加载进内存。
    $fp = new SplFileObject($diffFile);
    while (!$fp->eof()) {
        $line = (string)$fp->fgets();
        $line = trim($line);
        if ($line === '') {
            continue;
        }
        $row = json_decode($line, true);
        if (!is_array($row) || ($row['type'] ?? '') !== 'diff') {
            continue;
        }
        $mysqlTable = (string)($row['mysql_table'] ?? '');
        $collection = trim((string)($row['mongo_collection'] ?? ''));
        if ($mysqlTable === '' || $collection === '') {
            continue;
        }
        $taskKey = taskKey($mysqlTable, $collection);
        $task = $taskMap[$taskKey] ?? null;
        if (!is_array($task)) {
            // fallback: allow template key if diff stores resolved collection for mch_bak
            $template = normalizeMchBakTemplateKey($collection);
            $task = $taskMap[taskKey($mysqlTable, $template)] ?? null;
        }
        if (!is_array($task)) {
            fwrite(STDERR, "REPAIR skip: no task for {$mysqlTable} -> {$collection}\n");
            continue;
        }
        $mchBakParity = !empty($task['mch_bak_parity']);
        // mid=0 是合法商户号：不能把 <=0 一律当成“无 mid”。
        // diff 里若显式写了 mid:null，应视为“没有 mid”，不能 (int)null 变成 0。
        $filterMid = null;
        if (array_key_exists('mid', $row) && $row['mid'] !== null && $row['mid'] !== '') {
            $filterMid = (int)$row['mid'];
        }
        if (str_contains($collection, '{mid}') && $filterMid === null) {
            fwrite(STDERR, "REPAIR skip: need mid in diff for {$mysqlTable} -> {$collection}\n");
            continue;
        }
        $s = isset($row['start_id']) ? (int)$row['start_id'] : null;
        $e = isset($row['end_id']) ? (int)$row['end_id'] : null;
        if ($s === null || $e === null) {
            continue;
        }
        $midLabel = $filterMid !== null ? ", mid={$filterMid}" : '';
        if (!$QUIET) {
            echo "\nREPAIR {$mysqlTable} -> {$collection}, range=[{$s},{$e}]{$midLabel}\n";
        }
        $count = syncRange(
            $pdo,
            $mongo,
            $mongoDb,
            $mysqlTable,
            $collection,
            $idField,
            $mongoIdFrom,
            'upsert',
            $batchSize,
            $s,
            $e,
            $where,
            $progressFile,
            'repair',
            $filterMid,
            $mchBakParity,
            $sleepMs,
            $checkpointEveryBatches,
            $mysqlRetries,
            $mongoRetries,
            $retryBaseMs,
            $retryMaxMs,
            $workerId
        );
        if (!$QUIET) {
            echo "  - repaired rows={$count}\n";
        }
    }
}

/**
 * syncRange：核心同步循环。按 idField 游标从 MySQL 分批 SELECT，再按目标集合（含 `{mid}` 动态路由）bulk 写入 Mongo，并追加 progress JSONL。返回本段累计迁移行数。
 */
function syncRange(PDO $pdo, $mongo, string $mongoDb, string $mysqlTable, string $collection, string $idField, string $mongoIdFrom, string $mode, int $batchSize, ?int $startId, ?int $endId, string $where, string $progressFile, string $phase, ?int $filterMid = null, bool $mchBakFieldParity = true, int $sleepMs = 0, int $checkpointEveryBatches = 1, int $mysqlRetries = 5, int $mongoRetries = 5, int $retryBaseMs = 200, int $retryMaxMs = 5000, string $workerId = ''): int
{
    global $QUIET;
    $migrated = 0;
    // $lastId 决定下一批 MySQL 用的游标：
    // - 如果传了 $startId：第一批会从 `id >= $startId` 开始
    // - 如果没传 $startId：就不加下界（从 where 条件下的最小 id 开始取）
    $lastId = $startId !== null ? $startId - 1 : 0;
    $batchNo = 0;
    $dynamicMidCollection = str_contains($collection, '{mid}');
    $pendingProgressRow = null;
    $workerTag = $workerId === '' ? '' : ("[worker={$workerId}] ");

    // 核心循环：按 id 游标从 MySQL 取一批 -> 分组写入 Mongo（bulk upsert）
    while (true) {
        [$sql, $bindings] = buildSelectSql($mysqlTable, $idField, $batchSize, $lastId, $startId, $endId, $where, $filterMid);
        $stmt = $pdo->prepare($sql);
        foreach ($bindings as $k => $v) {
            $stmt->bindValue($k, $v, PDO::PARAM_INT);
        }
        withRetry(
            function () use ($stmt): void {
                $stmt->execute();
            },
            $mysqlRetries,
            $retryBaseMs,
            $retryMaxMs,
            $workerTag . "mysql_execute {$mysqlTable}"
        );
        // 大数据场景避免一次性 fetchAll() 把整批数据拉进内存。
        // 逻辑保持不变：这个 batch 仍然最多取 batchSize 行，然后写 Mongo。
        $firstRow = $stmt->fetch();
        if ($firstRow === false) {
            break;
        }

        $batchNo++;
        $cnt = 0;
        $batchStartId = $firstRow[$idField] ?? null;
        $batchEndId = $batchStartId;

        // 一个 batch 里可能出现多个 mid（动态集合），所以：
        // - 以 ns = "db.collection" 做分组
        // - 每个 ns 维护一个 BulkWrite
        $bulkClass = 'MongoDB\\Driver\\BulkWrite';
        $bulkMap = [];

        $row = $firstRow;
        while ($row !== false) {
            $cnt++;
            // 动态集合名需要 mid，但 mch_bak 白名单裁剪会把 mid 从“待写入文档”里去掉（与线上 BaseBakModel 一致）。
            // 因此必须在 shape 之前取出 mid，只用于路由到哪个集合；Mongo 文档里仍然不会带 mid。
            $routeMid = null;
            if ($dynamicMidCollection) {
                if (!array_key_exists('mid', $row)) {
                    throw new RuntimeException("table {$mysqlTable} requires mid column for dynamic collection");
                }
                $routeMid = $row['mid'];
            }
            if ($mchBakFieldParity) {
                // `mch_bak_*_{mid}`：按项目线上模型的 rowDefault 做字段白名单裁剪
                // 目的：避免写入多余字段导致 Mongo 文档结构漂移。
                $row = shapeRowLikeMchBakInsert($collection, $row);
            }
            if ($mongoIdFrom !== '' && array_key_exists($mongoIdFrom, $row)) {
                $row['_id'] = normalizeScalar($row[$mongoIdFrom]);
            }
            $targetCollection = $collection;
            if ($dynamicMidCollection) {
                // mid 允许为空：null/'' 会被转成空字符串，从而落到 mch_bak_xxx_ 这类集合
                $targetCollection = str_replace('{mid}', (string)$routeMid, $collection);
            }
            $ns = "{$mongoDb}.{$targetCollection}";
            if (!isset($bulkMap[$ns])) {
                $bulkMap[$ns] = new $bulkClass(['ordered' => false]);
            }

            if ($mode === 'insert') {
                $bulkMap[$ns]->insert($row);
            } else {
                // upsert：如果这条记录（按 id 或 _id）已经存在，就更新为 MySQL 的最新值
                // 这样你可以反复跑（full/repair 多次），最终保证“补齐到一致”。
                $filter = ($mongoIdFrom !== '' && array_key_exists('_id', $row))
                    ? ['_id' => $row['_id']]
                    : [$idField => normalizeScalar($row[$idField] ?? null)];
                $bulkMap[$ns]->update($filter, ['$set' => $row], ['upsert' => true, 'multi' => false]);
            }
            $rid = isset($row[$idField]) ? (int)$row[$idField] : 0;
            if ($rid > $lastId) {
                $lastId = $rid;
            }
            $batchEndId = $row[$idField] ?? $batchEndId;

            $row = $stmt->fetch();
        }

        $wcClass = 'MongoDB\\Driver\\WriteConcern';
        $wc = new $wcClass(1, 10000);
        $totalInserted = 0;
        $totalModified = 0;
        $totalUpserted = 0;
        // insert 不是天然幂等：如果服务端已写入但客户端在响应前超时，重试会造成重复写。
        // 因此：仅 upsert 模式开启 Mongo 写重试；insert 模式强制关闭重试。
        $effectiveMongoRetries = $mode === 'insert' ? 0 : $mongoRetries;
        foreach ($bulkMap as $ns => $bulk) {
            // 兼容新版 ext-mongodb：把 writeConcern 放到 options 数组里，避免 Deprecated。
            $res = withRetry(
                function () use ($mongo, $ns, $bulk, $wc) {
                    return $mongo->executeBulkWrite($ns, $bulk, ['writeConcern' => $wc]);
                },
                $effectiveMongoRetries,
                $retryBaseMs,
                $retryMaxMs,
                $workerTag . "mongo_bulk_write {$ns}"
            );
            $totalInserted += $res->getInsertedCount();
            $totalModified += $res->getModifiedCount();
            $totalUpserted += $res->getUpsertedCount();
        }
        $migrated += $cnt;

        if (!$QUIET || 1) {
            echo sprintf(
                "  - %s%s batch#%d rows=%d range=[%s,%s] ins=%d mod=%d ups=%d\n",
                $workerTag,
                strtoupper($phase),
                $batchNo,
                $cnt,
                (string)$batchStartId,
                (string)$batchEndId,
                $totalInserted,
                $totalModified,
                $totalUpserted
            );
        }

        $progressRow = [
            'type' => 'batch',
            'time' => date('c'),
            'phase' => $phase,
            'mysql_table' => $mysqlTable,
            'mongo_collection' => $collection,
            'batch_no' => $batchNo,
            'batch_count' => $cnt,
            'batch_start_id' => $batchStartId,
            'batch_end_id' => $batchEndId,
            'last_end_id' => $batchEndId,
            'inserted' => $totalInserted,
            'modified' => $totalModified,
            'upserted' => $totalUpserted,
            'mode' => $mode,
            'dynamic_collection' => $dynamicMidCollection ? 1 : 0,
            'status' => 'ok',
        ];
        if ($workerId !== '') {
            $progressRow['worker_id'] = $workerId;
        }
        // progress-file 的格式（JSONL）：
        // - type=batch：表示一次 batch 写入成功
        // - last_end_id：用于 resume，从 last_end_id + 1 继续抓取下一批
        // - dynamic_collection=1 表示这次写入涉及 {mid} 动态集合
        if ($filterMid !== null) {
            $progressRow['filter_mid'] = $filterMid;
        }
        $pendingProgressRow = $progressRow;
        if ($checkpointEveryBatches <= 1 || ($batchNo % $checkpointEveryBatches) === 0) {
            appendJsonLine($progressFile, $progressRow);
            $pendingProgressRow = null;
        }

        if ($sleepMs > 0) {
            usleep($sleepMs * 1000);
        }

        if ($lastId <= 0) {
            break;
        }
    }

    // 任务结束时，确保最后一个未落盘 checkpoint 也会被写入。
    if (is_array($pendingProgressRow)) {
        appendJsonLine($progressFile, $pendingProgressRow);
    }

    return $migrated;
}

/**
 * buildSelectSql：拼一条带 id 游标、可选 endId、可选 mid、可选业务 where 的 MySQL 查询 SQL 与绑定参数。
 *
 * @return array{0: string, 1: array<string, int>}
 */
function buildSelectSql(string $mysqlTable, string $idField, int $batchSize, int $lastId, ?int $startId, ?int $endId, string $where, ?int $filterMid = null): array
{
    // 组装一条“分批游标 SQL”：
    // - 用 idField 做游标：`id > lastId` 或 `id >= startId`
    // - 可选限制上界：`id <= endId`
    // - 可选限制 mid：动态集合时用 `mid = :filterMid`
    // - 最后拼接你传进来的 where（通常是 updtime/instime 时间窗）
    // 注意：where 本质是字符串拼接进 SQL，因此你需要自己保证它是安全/正确的。
    $conds = [];
    $bind = [];
    if ($lastId > 0) {
        $conds[] = "`{$idField}` > :lastId";
        $bind[':lastId'] = $lastId;
    } elseif ($startId !== null) {
        $conds[] = "`{$idField}` >= :startId";
        $bind[':startId'] = $startId;
    }
    if ($endId !== null) {
        $conds[] = "`{$idField}` <= :endId";
        $bind[':endId'] = $endId;
    }
    if ($filterMid !== null) {
        $conds[] = '`mid` = :filterMid';
        $bind[':filterMid'] = $filterMid;
    }
    if ($where !== '') {
        $conds[] = "({$where})";
    }
    $whereSql = empty($conds) ? '' : ('WHERE ' . implode(' AND ', $conds));
    $sql = "SELECT * FROM `{$mysqlTable}` {$whereSql} LIMIT {$batchSize}";
    return [$sql, $bind];
}

/**
 * dropCollection：对指定 Mongo 库执行 drop 命令删除集合（失败则打印跳过原因，不中断脚本）。
 */
function dropCollection($mongo, string $db, string $collection): void
{
    global $QUIET;
    try {
        // drop 目标集合：用于 full 回灌时保证“从空开始”，避免历史残留影响 verify/repair。
        $cmdClass = 'MongoDB\\Driver\\Command';
        $cmd = new $cmdClass(['drop' => $collection]);
        $mongo->executeCommand($db, $cmd);
        if (!$QUIET) {
            echo "  - dropped {$collection}\n";
        }
    } catch (Throwable $e) {
        echo "  - drop skipped: {$e->getMessage()}\n";
    }
}

/**
 * indexDefKeys：从单条索引配置里取出「索引 key 文档」，同时兼容 PHP/JSON 里的 `keys` 与线上模型的 `key`。
 *
 * @return array<string, int>|null
 */
function indexDefKeys(array $idx): ?array
{
    foreach (['keys', 'key'] as $field) {
        if (!isset($idx[$field]) || !is_array($idx[$field]) || $idx[$field] === []) {
            continue;
        }
        return $idx[$field];
    }
    return null;
}

/**
 * createIndex：通过 Mongo `createIndexes` 命令在指定集合上创建一条索引。
 */
function createIndex($mongo, string $db, string $collection, array $keys, array $options = []): void
{
    // 创建 Mongo 索引：
    // - keys：例如 ['id'=>1] 或 ['instime'=>1]
    // - options：例如 ['unique'=>true, 'name'=>'xxx']
    // 如果 options 里没给 name，会根据 keys 生成一个默认 name。
    $cmdClass = 'MongoDB\\Driver\\Command';
    $cmd = new $cmdClass([
        'createIndexes' => $collection,
        'indexes' => [[
            'key' => $keys,
            'name' => $options['name'] ?? ('idx_' . md5(json_encode($keys))),
        ] + $options],
    ]);
    $mongo->executeCommand($db, $cmd);
}

/**
 * getIdBounds：查询单张 MySQL 表在 where/可选 id 区间下的 MIN(idField)、MAX(idField)，供 verify/repair 定界。
 *
 * @return array{0: ?int, 1: ?int}
 */
function getIdBounds(PDO $pdo, string $table, string $idField, string $where, ?int $startId, ?int $endId): array
{
    // 返回 id 的范围证据：MIN(id) 与 MAX(id)。
    // verify-mode=count/range 都会用到这类上下界：
    // - count 模式：如果总数不等，就把 [minId,maxId] 作为 repair 的补齐区间
    // - range 模式：会继续切片更细的 [s,e] 子区间
    $conds = [];
    $bind = [];
    if ($startId !== null) {
        $conds[] = "`{$idField}` >= :startId";
        $bind[':startId'] = $startId;
    }
    if ($endId !== null) {
        $conds[] = "`{$idField}` <= :endId";
        $bind[':endId'] = $endId;
    }
    if ($where !== '') {
        $conds[] = "({$where})";
    }
    $whereSql = empty($conds) ? '' : ('WHERE ' . implode(' AND ', $conds));
    $sql = "SELECT MIN(`{$idField}`) AS min_id, MAX(`{$idField}`) AS max_id FROM `{$table}` {$whereSql}";
    $stmt = $pdo->prepare($sql);
    foreach ($bind as $k => $v) {
        $stmt->bindValue($k, $v, PDO::PARAM_INT);
    }
    $stmt->execute();
    $row = $stmt->fetch(PDO::FETCH_ASSOC) ?: [];
    $minId = isset($row['min_id']) ? (int)$row['min_id'] : null;
    $maxId = isset($row['max_id']) ? (int)$row['max_id'] : null;
    if ($minId === 0 && $maxId === 0 && ($row['min_id'] === null || $row['max_id'] === null)) {
        return [null, null];
    }
    return [$minId, $maxId];
}

/**
 * countMysqlRange：统计 MySQL 表在 [startId,endId] 与 where 下的行数（固定集合 verify-range 用）。
 */
function countMysqlRange(PDO $pdo, string $table, string $idField, int $startId, int $endId, string $where): int
{
    $conds = ["`{$idField}` >= :s", "`{$idField}` <= :e"];
    if ($where !== '') {
        $conds[] = "({$where})";
    }
    $sql = "SELECT COUNT(*) AS c FROM `{$table}` WHERE " . implode(' AND ', $conds);
    $stmt = $pdo->prepare($sql);
    $stmt->bindValue(':s', $startId, PDO::PARAM_INT);
    $stmt->bindValue(':e', $endId, PDO::PARAM_INT);
    $stmt->execute();
    $row = $stmt->fetch(PDO::FETCH_ASSOC);
    return (int)($row['c'] ?? 0);
}

/**
 * countMongoRange：统计 Mongo 集合中 idField 落在 [startId,endId] 的文档数量（verify-range 用）。
 */
function countMongoRange($mongo, string $db, string $collection, string $idField, int $startId, int $endId): int
{
    // Mongo 端的 count（按 idField 范围过滤）：
    // - 只做“数字对比”，不需要把数据拉出来
    // - 用于 verify-mode=range 时的每个子区间对比
    $cmdClass = 'MongoDB\\Driver\\Command';
    $cmd = new $cmdClass([
        'count' => $collection,
        'query' => [
            $idField => ['$gte' => $startId, '$lte' => $endId],
        ],
    ]);
    $cursor = $mongo->executeCommand($db, $cmd);
    // 避免 toArray() 把游标结果一次性读进内存：这里 count 只需要第一条返回值。
    $arr = null;
    foreach ($cursor as $doc) {
        $arr = $doc;
        break;
    }
    if (!((is_object($arr) && isset($arr->n)) || (is_array($arr) && isset($arr['n'])))) {
        return 0;
    }
    return (int)(is_object($arr) ? $arr->n : $arr['n']);
}

/**
 * countMongoCollection：统计 Mongo 集合全文档数量（verify-mode=count 用，无过滤条件）。
 */
function countMongoCollection($mongo, string $db, string $collection): int
{
    // Mongo 端的总数 count（verify-mode=count 时用）
    // query 用空条件（全量计数），尽量保持与 MySQL count 的 where 对应逻辑一致。
    $cmdClass = 'MongoDB\\Driver\\Command';
    $cmd = new $cmdClass([
        'count' => $collection,
        'query' => new stdClass(),
    ]);
    $cursor = $mongo->executeCommand($db, $cmd);
    // 避免 toArray() 把游标结果一次性读进内存：这里 count 只需要第一条返回值。
    $arr = null;
    foreach ($cursor as $doc) {
        $arr = $doc;
        break;
    }
    if (!((is_object($arr) && isset($arr->n)) || (is_array($arr) && isset($arr['n'])))) {
        return 0;
    }
    return (int)(is_object($arr) ? $arr->n : $arr['n']);
}

/**
 * countMysqlTotal：统计 MySQL 表在可选 where 下的总行数（固定集合 verify-count 用）。
 */
function countMysqlTotal(PDO $pdo, string $table, string $where): int
{
    $sql = "SELECT COUNT(*) AS c FROM `{$table}`";
    if ($where !== '') {
        $sql .= " WHERE ({$where})";
    }
    $row = $pdo->query($sql)->fetch(PDO::FETCH_ASSOC);
    return (int)($row['c'] ?? 0);
}

/**
 * countMysqlTotalForMid：统计 MySQL 表在指定 mid 与可选 where 下的行数（动态集合 verify-count 用）。
 */
function countMysqlTotalForMid(PDO $pdo, string $table, int $mid, string $where): int
{
    $sql = "SELECT COUNT(*) AS c FROM `{$table}` WHERE `mid` = :mid";
    if ($where !== '') {
        $sql .= " AND ({$where})";
    }
    $stmt = $pdo->prepare($sql);
    $stmt->bindValue(':mid', $mid, PDO::PARAM_INT);
    $stmt->execute();
    $row = $stmt->fetch(PDO::FETCH_ASSOC);
    return (int)($row['c'] ?? 0);
}

/**
 * createPdo：根据 CLI 参数创建 MySQL PDO 连接（异常模式、assoc、非缓冲查询）。
 */
function createPdo(array $opts, int $mysqlPort): PDO
{
    // 创建 MySQL 连接：
    // - ERRMODE_EXCEPTION：SQL 错误直接抛异常（避免 silent failure）
    // - USE_BUFFERED_QUERY=false：尽量少把结果缓冲在客户端（大批量更稳）
    $dsn = sprintf('mysql:host=%s;port=%d;dbname=%s;charset=utf8mb4', $opts['mysql-host'], $mysqlPort, $opts['mysql-db']);
    return new PDO($dsn, (string)$opts['mysql-user'], (string)($opts['mysql-pass'] ?? ''), [
        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
        PDO::MYSQL_ATTR_USE_BUFFERED_QUERY => false,
    ]);
}

/**
 * createMongo：根据 URI 创建 `MongoDB\Driver\Manager`。
 */
function createMongo(string $uri)
{
    // 创建 MongoDB Driver Manager：
    // $uri 直接走你传入的连接串（可能包含用户名/密码/副本集等）
    $managerClass = 'MongoDB\\Driver\\Manager';
    return new $managerClass($uri);
}

/**
 * buildMongoUri：把 --mongo-user/--mongo-pass 注入到已有 --mongo-uri 中。
 *
 * 规则：
 * - 你仍然可以直接传带账号密码的 mongo-uri（脚本不会二次注入）。
 * - 你也可以传“无凭据”的 mongo-uri，通过参数传入认证信息（推荐）。
 * - 如果传了 --mongo-auth-db，会追加到连接串的 authSource 参数里（若连接串里尚未包含）。
 */
function buildMongoUri(string $uri, string $user, string $pass, string $authDb): string
{
    if ($user === '' && $pass === '') {
        return $uri;
    }

    // mongodb://user:pass@host:27017/?replicaSet=xxx
    $m = [];
    if (!preg_match('~^(mongodb(?:\+srv)?):\/\/(?:(?<userinfo>[^@\/?]+)@)?(?<hosts>[^\/?]+)(?<rest>.*)$~', $uri, $m)) {
        // 连接串格式不匹配：保守起见，直接返回原 uri（避免破坏原配置）。
        return $uri;
    }

    // 已经在 URI 里写了 userinfo，就不再改动。
    if (!empty($m['userinfo'])) {
        return $uri;
    }

    $scheme = (string)$m[1];
    $hosts = (string)$m['hosts'];
    $rest = (string)$m['rest'];

    $userinfo = rawurlencode($user) . ':' . rawurlencode($pass);
    $newUri = $scheme . '://' . $userinfo . '@' . $hosts . $rest;

    if ($authDb === '') {
        return $newUri;
    }
    if (str_contains($newUri, 'authSource=')) {
        return $newUri;
    }

    // 追加 authSource 参数（兼容 ? 和无 ? 两种情况）。
    $sep = str_contains($newUri, '?') ? '&' : '?';
    return $newUri . $sep . 'authSource=' . rawurlencode($authDb);
}

/**
 * parseTablePairs：解析 `--tables` 字符串为「MySQL 表名 => Mongo 集合名」映射数组。
 *
 * @return array<string, string>
 */
function parseTablePairs(string $input): array
{
    // 解析 `--tables` 参数格式：
    // - 例：`order:mch_bak_order_{mid},payout_order:mch_bak_payout_order_{mid}`
    // - 使用逗号分隔多个映射
    // - 每个映射使用 `mysql_table:mongo_collection_template` 形式
    // - 如果没有冒号，则会把左边也当作右边（等价：同名映射）
    $out = [];
    foreach (explode(',', $input) as $item) {
        $item = trim($item);
        if ($item === '') {
            continue;
        }
        $parts = explode(':', $item, 2);
        if (count($parts) === 1) {
            $out[$parts[0]] = $parts[0];
            continue;
        }
        $left = trim($parts[0]);
        $right = trim($parts[1]);
        if ($left !== '' && $right !== '') {
            $out[$left] = $right;
        }
    }
    return $out;
}

/**
 * resolveTableTasks：得到本次运行要处理的「任务清单」（每项含 mysql_table、mongo_collection、mch_bak_parity）。无 `--tables` 时可用 preset。
 *
 * @return list<array{mysql_table: string, mongo_collection: string, mch_bak_parity: bool}>
 */
function resolveTableTasks(string $tablesOpt, string $preset, string $mysqlTablePrefix): array
{
    $applyPrefix = function (string $table) use ($mysqlTablePrefix): string {
        if ($mysqlTablePrefix === '') {
            return $table;
        }
        // 避免重复拼接：如果你手动传了完整表名（已带前缀），就不再追加。
        if (str_starts_with($table, $mysqlTablePrefix)) {
            return $table;
        }
        return $mysqlTablePrefix . $table;
    };

    if (trim($tablesOpt) !== '') {
        $pairs = parseTablePairs($tablesOpt);
        $tasks = [];
        foreach ($pairs as $mysql => $coll) {
            $tasks[] = [
                'mysql_table' => $applyPrefix($mysql),
                'mongo_collection' => $coll,
                'mch_bak_parity' => str_starts_with($coll, 'mch_bak_') || str_contains($coll, 'mch_bak_'),
            ];
        }
        return $tasks;
    }
    if ($preset === 'project6' || $preset === 'all6') {
        // preset=project6/all6：自动生成固定的一组任务清单（对应你项目里的“订单备份恢复”场景）
        // 关键点：merchant_bill_binlog + merchant_bill_log 会写到同一个 Mongo：
        // - 都落在 `mch_bak_merchant_bill_log_{mid}`
        // - 如果同一条 id 同时存在，最终以“先写/后写”的顺序为准
        // - 所以这里按 binlog 再 bill_log 的顺序，让主表 bill_log 在冲突时获胜（fully automatic）。
        return [
            // merchant backend (per mid)
            ['mysql_table' => $applyPrefix('order'), 'mongo_collection' => 'mch_bak_order_{mid}', 'mch_bak_parity' => true],
            ['mysql_table' => $applyPrefix('payout_order'), 'mongo_collection' => 'mch_bak_payout_order_{mid}', 'mch_bak_parity' => true],
            ['mysql_table' => $applyPrefix('merchant_bill_binlog'), 'mongo_collection' => 'mch_bak_merchant_bill_log_{mid}', 'mch_bak_parity' => true],
            ['mysql_table' => $applyPrefix('merchant_bill_log'), 'mongo_collection' => 'mch_bak_merchant_bill_log_{mid}', 'mch_bak_parity' => true],

            // archive collections (fixed, same as ClearOldOrders)
            // ['mysql_table' => $applyPrefix('order'), 'mongo_collection' => 'order', 'mch_bak_parity' => false],
            // ['mysql_table' => $applyPrefix('payout_order'), 'mongo_collection' => 'payout_order', 'mch_bak_parity' => false],
            // ['mysql_table' => $applyPrefix('source_order'), 'mongo_collection' => 'source_order', 'mch_bak_parity' => false],
            // ['mysql_table' => $applyPrefix('payout_source_order'), 'mongo_collection' => 'payout_source_order', 'mch_bak_parity' => false],
        ];
    }
    return [];
}

/**
 * resolveIndexDefinitions：根据集合模板名与 JSON 配置，解析出「索引定义列表」。动态模板走 base key + 内置兜底，与线上 MchBak 索引对齐。
 *
 * Index config: static collection -> key is collection name.
 * Per-merchant backup -> use base name without _{mid}, e.g. "mch_bak_order" for template mch_bak_order_{mid}.
 * If JSON omits a base key, defaults match App/MongoDb/MchBakModel/*.php $indexs.
 */
function resolveIndexDefinitions(string $collectionTemplate): array
{
    if (str_contains($collectionTemplate, '{mid}')) {
        // 对动态集合：把 `mch_bak_xxx_{mid}` 转成配置 base key（去掉 `{mid}`）
        // 例如：mch_bak_order_{mid} -> mch_bak_order
        // 然后在 cfg 里找对应的 defs；找不到就走 defaultMchBakIndexesByBase($base)。
        $base = mchBakTemplateToConfigKey($collectionTemplate);
        return defaultMchBakIndexesByBase($base);
    }
    return defaultFixedIndexesByCollection($collectionTemplate);
}

/**
 * mchBakTemplateToConfigKey：把 `mch_bak_xxx_{mid}` 转为 JSON 配置用的 base key（如 `mch_bak_order`）。
 */
function mchBakTemplateToConfigKey(string $template): string
{
    if (preg_match('/^(mch_bak_[a-z_]+)_\{mid\}$/', $template, $m)) {
        return $m[1];
    }
    return $template;
}

/**
 * defaultMchBakIndexesByBase：当未提供 indexes JSON 或缺项时，按 mch_bak 类型返回内置索引列表（对齐 MchBak*::$indexs）。
 */
function defaultMchBakIndexesByBase(string $base): array
{
    // 内置兜底索引（当 indexesFile 没给或者缺某些模板时启用）
    // 目标是让常见 mch_bak 集合至少有主键/查询相关索引，避免 verify/repair 速度太慢。
    $idInst = [
        ['keys' => ['id' => 1], 'options' => ['unique' => true]],
        ['keys' => ['instime' => 1], 'options' => []],
    ];
    if ($base === 'mch_bak_order' || $base === 'mch_bak_payout_order') {
        return array_merge($idInst, [['keys' => ['finish_time' => 1], 'options' => []]]);
    }
    if ($base === 'mch_bak_merchant_bill_log') {
        return $idInst;
    }
    return [];
}

/**
 * defaultFixedIndexesByCollection：固定集合在未提供 indexes JSON 时的内置索引（用于重建后可直接跑业务）。
 */
function defaultFixedIndexesByCollection(string $collection): array
{
    // 固定集合默认索引策略（保守版）：
    // - id 唯一：保证 upsert/filter 的主键一致性
    // - instime：常见按时间排序/范围查询
    // - mid：后台按商户筛选时避免全表扫描
    $base = [
        ['keys' => ['id' => 1], 'options' => ['unique' => true]],
        ['keys' => ['instime' => 1], 'options' => []],
        ['keys' => ['mid' => 1], 'options' => []],
    ];

    if (in_array($collection, ['order', 'payout_order', 'source_order', 'payout_source_order'], true)) {
        return $base;
    }
    return [];
}

/**
 * getDistinctMids：从 MySQL 表查出满足 where 的去重 mid 列表（排除 NULL/空串），用于 index/verify 按商户展开 `{mid}`。
 *
 * @return list<scalar>
 */
function getDistinctMids(PDO $pdo, string $table, string $where): array
{
    // 用于动态集合（包含 {mid}）的 mid 分组。
    // - SQL：SELECT DISTINCT mid
    // - 过滤掉 NULL（以及空字符串）
    // - ORDER BY 保证每次跑出来顺序一致（便于定位和对比）
    $sql = "SELECT DISTINCT `mid` FROM `{$table}` WHERE `mid` IS NOT NULL";
    if ($where !== '') {
        $sql .= " AND ({$where})";
    }
    $sql .= ' ORDER BY `mid` ASC';
    $stmt = $pdo->query($sql);
    if (!$stmt) {
        return [];
    }
    $out = [];
    while ($r = $stmt->fetch(PDO::FETCH_ASSOC)) {
        if (isset($r['mid']) && $r['mid'] !== '' && $r['mid'] !== null) {
            $out[] = $r['mid'];
        }
    }
    return $out;
}

/**
 * getIdBoundsForMid：在固定 mid 下查询 MySQL 表 idField 的 MIN/MAX（叠加 where 与可选 id 区间）。
 *
 * @return array{0: ?int, 1: ?int}
 */
function getIdBoundsForMid(PDO $pdo, string $table, string $idField, int $mid, string $where, ?int $startId, ?int $endId): array
{
    // 对某个 mid 的数据，返回 id 的最小值/最大值：
    // - verify-mode=count：如果总数对不上，就把这个 [min,max] 作为 repair 目标区间
    // - verify-mode=range：会进一步把 [min,max] 切成 rangeSize 段分别 count 对比
    $conds = ['`mid` = :mid'];
    $bind = [':mid' => $mid];
    if ($startId !== null) {
        $conds[] = "`{$idField}` >= :startId";
        $bind[':startId'] = $startId;
    }
    if ($endId !== null) {
        $conds[] = "`{$idField}` <= :endId";
        $bind[':endId'] = $endId;
    }
    if ($where !== '') {
        $conds[] = "({$where})";
    }
    $whereSql = 'WHERE ' . implode(' AND ', $conds);
    $sql = "SELECT MIN(`{$idField}`) AS min_id, MAX(`{$idField}`) AS max_id FROM `{$table}` {$whereSql}";
    $stmt = $pdo->prepare($sql);
    foreach ($bind as $k => $v) {
        $stmt->bindValue($k, $v, PDO::PARAM_INT);
    }
    $stmt->execute();
    $row = $stmt->fetch(PDO::FETCH_ASSOC) ?: [];
    if (($row['min_id'] ?? null) === null || ($row['max_id'] ?? null) === null) {
        return [null, null];
    }
    return [(int)$row['min_id'], (int)$row['max_id']];
}

/**
 * countMysqlRangeForMid：统计指定 mid 下 MySQL 表在 id 子区间与 where 内的行数（动态集合 verify-range 用）。
 */
function countMysqlRangeForMid(PDO $pdo, string $table, string $idField, int $mid, int $startId, int $endId, string $where): int
{
    $conds = [
        "`{$idField}` >= :s",
        "`{$idField}` <= :e",
        '`mid` = :mid',
    ];
    if ($where !== '') {
        $conds[] = "({$where})";
    }
    $sql = 'SELECT COUNT(*) AS c FROM `' . $table . '` WHERE ' . implode(' AND ', $conds);
    $stmt = $pdo->prepare($sql);
    $stmt->bindValue(':s', $startId, PDO::PARAM_INT);
    $stmt->bindValue(':e', $endId, PDO::PARAM_INT);
    $stmt->bindValue(':mid', $mid, PDO::PARAM_INT);
    $stmt->execute();
    $row = $stmt->fetch(PDO::FETCH_ASSOC);
    return (int)($row['c'] ?? 0);
}

/**
 * withRetry：对可重试异常做指数退避重试。
 */
function withRetry(callable $fn, int $retries, int $baseMs, int $maxMs, string $label): mixed
{
    $attempt = 0;
    begin:
    try {
        return $fn();
    } catch (Throwable $e) {
        $attempt++;
        $isRetryable = isRetryableThrowable($e);
        if (!$isRetryable || $attempt > $retries) {
            throw $e;
        }
        $backoff = (int)min($maxMs, $baseMs * (2 ** max(0, $attempt - 1)));
        $jitter = $backoff > 1 ? random_int(0, (int)floor($backoff / 4)) : 0;
        $waitMs = $backoff + $jitter;
        fwrite(STDERR, "[retry] {$label} attempt={$attempt}/{$retries} wait_ms={$waitMs} error=" . $e->getMessage() . "\n");
        usleep($waitMs * 1000);
        goto begin;
    }
}

/**
 * isRetryableThrowable：判断是否是“值得重试”的临时性错误。
 */
function isRetryableThrowable(Throwable $e): bool
{
    $msg = strtolower($e->getMessage());
    if ($msg === '') {
        return false;
    }
    $nonRetryKeywords = [
        'syntax error',
        'unknown column',
        'doesn\'t exist',
        'duplicate key',
        'invalid argument',
        'authentication failed',
        'auth failed',
    ];
    foreach ($nonRetryKeywords as $kw) {
        if (str_contains($msg, $kw)) {
            return false;
        }
    }
    $retryKeywords = [
        'server has gone away',
        'lost connection',
        'connection reset',
        'broken pipe',
        'timed out',
        'timeout',
        'temporarily unavailable',
        'too many connections',
        'lock wait timeout',
        'deadlock',
        'not primary',
        'node is recovering',
        'network',
        'econnreset',
        'econnrefused',
        'connection refused',
    ];
    foreach ($retryKeywords as $kw) {
        if (str_contains($msg, $kw)) {
            return true;
        }
    }
    return false;
}

/**
 * normalizeScalar：把形似数字的标量转为 int/float，减少 Mongo 中数字被存成字符串的情况。
 */
function normalizeScalar(mixed $value): mixed
{
    // 目标：尽量把 MySQL 返回的“数字字符串”转成真正的数字类型。
    // 场景：
    // - MySQL 字段可能是 DECIMAL/INT，但 PDO fetch 结果在某些情况下会变成字符串
    // - Mongo 文档里如果把数字存成字符串，会导致范围查询/索引命中变差
    // - 所以这里用 is_numeric + 判断是否包含 '.' 来决定转 int 还是 float
    if (is_numeric((string)$value)) {
        return strpos((string)$value, '.') !== false ? (float)$value : (int)$value;
    }
    return $value;
}

/**
 * normalizeMchBakTemplateKey：把已解析集合名（如 `mch_bak_order_1003`）还原为带 `{mid}` 的模板，供任务查找与 rowDefault 匹配。
 *
 * Normalize mch_bak_order_1003 -> mch_bak_order_{mid} for lookup (mirrors App/MongoDb/MchBakModel naming).
 */
function normalizeMchBakTemplateKey(string $collection): string
{
    if (str_contains($collection, '{mid}')) {
        return $collection;
    }
    // 例如：
    // - 传入 `mch_bak_order_1003` -> 输出 `mch_bak_order_{mid}`
    // - 传入不符合该规则的集合名 -> 原样返回
    return preg_replace('/_[0-9]+$/', '_{mid}', $collection);
}

/**
 * mchBakRowDefaultsForTemplate：返回与指定 mch_bak 模板对应的「字段默认值表」，用于白名单裁剪；无模板则返回 null。
 *
 * @return array<string, mixed>|null defaults aligned with MchBak*::$rowDefault
 */
function mchBakRowDefaultsForTemplate(string $collection): ?array
{
    // 这块默认值是“白名单+补齐”：
    // - 如果你要写入的集合是 mch_bak_*_{mid} 对应模板，那么只取 rowDefault 里定义的字段
    // - 对于 MySQL 行里没有的字段，用默认值补上
    // - 这样写出来的 Mongo 文档字段集合尽量和你项目线上 BaseBakModel 保持一致
    $key = normalizeMchBakTemplateKey($collection);
    static $defaults = [
        'mch_bak_order_{mid}' => [
            'id' => 0,
            'trade_sn' => '',
            'order_sn' => '',
            'amount' => 0,
            'fee' => 0,
            'collected_amount' => 0,
            'actual_amount' => 0,
            'name' => '',
            'phone' => '',
            'email' => '',
            'instime' => 0,
            'updtime' => 0,
            'finish_time' => 0,
            'expire_time' => 0,
            'status' => 0,
            'notify_url' => '',
            'is_notice' => 0,
            'product_info' => '',
            'remark' => '',
            'payin_bank_id' => 0,
        ],
        'mch_bak_payout_order_{mid}' => [
            'id' => 0,
            'trade_sn' => '',
            'order_sn' => '',
            'amount' => 0,
            'fee' => 0,
            'collected_amount' => 0,
            'name' => '',
            'account' => '',
            'phone' => '',
            'email' => '',
            'instime' => 0,
            'finish_time' => 0,
            'updtime' => 0,
            'status' => 0,
            'notify_url' => '',
            'is_notice' => 0,
            'product_info' => '',
            'remark' => '',
            'payout_bank_id' => 0,
            'channel_id' => 0,
            'err_code' => '',
        ],
        'mch_bak_merchant_bill_log_{mid}' => [
            'id' => 0,
            'pre_balance' => 0,
            'amount' => 0,
            'after_balance' => 0,
            'trans_id' => '',
            'type' => 0,
            'order_sn' => '',
            'remark' => '',
            'instime' => 0,
            'updtime' => 0,
        ],
    ];
    return $defaults[$key] ?? null;
}

/**
 * shapeRowLikeMchBakInsert：按 mch_bak 模板的 rowDefault 白名单过滤/补全一行数据（与 BaseBakModel::insertMany 一致，文档不含 mid）。
 *
 * Same as BaseBakModel::insertMany — only $rowDefault keys; isset() merge (mid not in doc).
 */
function shapeRowLikeMchBakInsert(string $collectionTemplate, array $row): array
{
    $def = mchBakRowDefaultsForTemplate($collectionTemplate);
    if ($def === null) {
        return $row;
    }
    $out = [];
    foreach ($def as $key => $default) {
        $out[$key] = isset($row[$key]) ? $row[$key] : $default;
    }
    return $out;
}

/**
 * ensureParentDir：若文件路径父目录不存在则递归创建（用于 progress/diff 等路径）。
 */
function ensureParentDir(string $path): void
{
    $dir = dirname($path);
    static $checked = [];
    if (isset($checked[$dir])) {
        return;
    }
    if (!is_dir($dir) && !mkdir($dir, 0777, true) && !is_dir($dir)) {
        throw new RuntimeException("mkdir failed: {$dir}");
    }
    $checked[$dir] = true;
}

/**
 * appendJsonLine：将一行 JSON 追加写入文件（JSONL，带锁），用于进度与 diff。
 */
function appendJsonLine(string $path, array $row): void
{
    // JSONL：每次只追加一行（适合长时间任务/断点续跑）。
    // 这里的 row 通常是：
    // - phase=full 时：type=batch，包含 batch_start_id/batch_end_id/last_end_id 等字段
    // - phase=verify 时：type=diff，包含 mysql_count/mongo_count 等差异信息
    ensureParentDir($path);
    $line = json_encode($row, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    if ($line !== false) {
        file_put_contents($path, $line . PHP_EOL, FILE_APPEND | LOCK_EX);
    }
}

/**
 * loadProgressState：扫描 progress JSONL，汇总每个「mysql表->mongo集合模板」最后一次成功的 last_end_id，供 `--resume` 使用。
 *
 * @return array<string, array{last_end_id: mixed}>
 */
function loadProgressState(string $filePath): array
{
    // 从 progress-file 读取最近成功的 batch 进度，用于 resume=1。
    // 规则：
    // - 只认 type=batch 且 status=ok 的行
    // - 以 taskKey(mysql_table,mongo_collection) 为索引
    // - last_end_id 作为下一次起点的依据（resumeStart = last_end_id + 1）
    if (!is_file($filePath)) {
        return [];
    }
    $state = [];
    // progress-file 可能会随着跑批增长：用 SplFileObject 逐行读取，避免 file() 一次性读入大文件。
    $fp = new SplFileObject($filePath);
    while (!$fp->eof()) {
        $line = (string)$fp->fgets();
        $line = trim($line);
        if ($line === '') {
            continue;
        }
        $row = json_decode($line, true);
        if (!is_array($row)) {
            continue;
        }
        if (($row['type'] ?? '') !== 'batch' || ($row['status'] ?? '') !== 'ok') {
            continue;
        }
        $table = (string)($row['mysql_table'] ?? '');
        $coll = (string)($row['mongo_collection'] ?? '');
        if ($table === '' || $coll === '') {
            continue;
        }
        $state[taskKey($table, $coll)] = ['last_end_id' => $row['last_end_id'] ?? null];
    }
    return $state;
}

/**
 * taskKey：生成「MySQL 表 + Mongo 集合（模板）」的稳定字符串键，用于进度与任务对应。
 */
function taskKey(string $mysqlTable, string $mongoCollection): string
{
    return $mysqlTable . '->' . $mongoCollection;
}
