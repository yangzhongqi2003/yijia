#!/bin/bash

set -ue
set -o pipefail

GLOBAL_NAMESPACE=kube-system
GLOBAL_KUBECONFIG=""
GLOBAL_VALUES_PATH="loongcollector/values.yaml"

GLOBAL_EMPTY_MUSTPARAMS=false
GLOBAL_KUBECONFIG_CMD=""
GLOBAL_HELM_PATH=""

# initArch discovers the architecture for this system.
initArch() {
  ARCH=$(uname -m)
  case $ARCH in
    armv5*) ARCH="armv5";;
    armv6*) ARCH="armv6";;
    armv7*) ARCH="arm";;
    aarch64) ARCH="arm64";;
    x86) ARCH="386";;
    x86_64) ARCH="amd64";;
    i686) ARCH="386";;
    i386) ARCH="386";;
  esac
}

# initOS discovers the operating system for this system.
initOS() {
  OS=$(echo `uname`|tr '[:upper:]' '[:lower:]')

  case "$OS" in
    # Minimalist GNU for Windows
    mingw*|cygwin*) OS='windows';;
  esac
}

verifySupported() {
  local supported="linux-386\nlinux-amd64\nlinux-arm\nlinux-arm64\nlinux-ppc64le\nlinux-s390x\ndarwin-amd64"
  if ! echo "${supported}" | grep -q "${OS}-${ARCH}"; then
    echo "Current script does not support for ${OS}-${ARCH}."
    exit 1
  fi
}


confirmAction() {
    echo "select your confirm:"
    echo "1) yes"
    echo "2) no"

    read -p "please input (1 or 2): " choice  # 提示用户输入

    case $choice in
        1)
            echo "use confirm: yes"
            ;;
        2)
            echo "use confirm: no"
            exit 0  
            ;;
        *)
            echo "invalid option, please input 1 or 2。"
            confirm_action
            ;;
    esac
}

checkHelm() {
  local helmPkgPath=./helm.tar.gz
  GLOBAL_HELM_PATH=./helm/helm-$OS-$ARCH
  if [ -f "$GLOBAL_HELM_PATH" ]; then
      echo "$GLOBAL_HELM_PATH exists."
  else
    tar zxvf $helmPkgPath -C ./
  fi
}

checkKubeConfig() {
  if [[ $GLOBAL_KUBECONFIG != "" ]]; then
    echo "use kubeconfig $GLOBAL_KUBECONFIG"
    GLOBAL_KUBECONFIG_CMD="--kubeconfig=$GLOBAL_KUBECONFIG"
  fi
}

checkMustParams() {
  local find_str=$1:
  local str=`grep ^$find_str $GLOBAL_VALUES_PATH`
  local str=${str#*${find_str}} 
  if [ -z $str ] || [ $str == '""' ] || [ $str == "" ];then
      echo empty $1
      GLOBAL_EMPTY_MUSTPARAMS=true
  fi
}

confirmInput() {
  echo "====== your input start ====="
  grep "^projectName" $GLOBAL_VALUES_PATH
  grep "^region" $GLOBAL_VALUES_PATH
  grep "^aliUid" $GLOBAL_VALUES_PATH
  grep "^accessKeyID" $GLOBAL_VALUES_PATH
  grep "^accessKeySecret" $GLOBAL_VALUES_PATH
  grep "^clusterID" $GLOBAL_VALUES_PATH
  echo "====== your input end ====="

  checkMustParams "projectName"
  checkMustParams "region"
  checkMustParams "aliUid"
  checkMustParams "accessKeyID"
  checkMustParams "accessKeySecret"
  checkMustParams "clusterID"

  if [ $GLOBAL_EMPTY_MUSTPARAMS == true ];then
    echo "please confirm your input"
    exit 1
  fi

  echo "please confirm your input is valid?"
  confirmAction
}

# 定义安装函数
install() {
    echo "Installing..."
    $GLOBAL_HELM_PATH $GLOBAL_KUBECONFIG_CMD install loongcollector ./loongcollector --namespace $GLOBAL_NAMESPACE
}

# 定义更新函数
update() {
    echo "Updating..."
    $GLOBAL_HELM_PATH $GLOBAL_KUBECONFIG_CMD upgrade loongcollector ./loongcollector --namespace $GLOBAL_NAMESPACE
}

main() { 
    initArch
    initOS
    verifySupported
    checkHelm
    checkKubeConfig

    confirmInput


    case "$1" in
        install)
            install
            return 0
            ;;
        update)
            update
            return 0
            ;;
        *)
            echo "Invalid option: $1"
            echo "Usage: $0 {install|update}"
            exit 1
            ;;
    esac

}


main "$@"