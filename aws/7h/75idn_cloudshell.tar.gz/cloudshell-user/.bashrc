# .bashrc

# Source global definitions
if [ -f /etc/bashrc ]; then
	. /etc/bashrc
fi

# User specific environment
if ! [[ "$PATH" =~ "$HOME/.local/bin:$HOME/bin:" ]]
then
    PATH="$HOME/.local/bin:$HOME/bin:$PATH"
fi
export PATH

# Uncomment the following line if you don't like systemctl's auto-paging feature:
# export SYSTEMD_PAGER=

# User specific aliases and functions
if [ -d ~/.bashrc.d ]; then
	for rc in ~/.bashrc.d/*; do
		if [ -f "$rc" ]; then
			. "$rc"
		fi
	done
fi

unset rc
complete -C '/usr/local/bin/aws_completer' aws
export PS1='\W $ '
alias pod='kubectl get pod'
alias po='kubectl get pod'
alias poo='kubectl get pod -owide'
alias svc='kubectl get svc'
alias ns='kubectl get ns'
alias pvc='kubectl get pvc'
alias pv='kubectl get pv'
alias sc='kubectl get sc'
alias cm='kubectl get cm'
alias sa='kubectl get sa'
alias kn='kubectl get node'
alias ingress='kubectl get ingress'
alias all='kubectl get all'
alias deployment='kubectl get deployments'
alias daemonset='kubectl get daemonsets'
alias sts='kubectl get statefulsets'
alias vs='kubectl get vs'
alias gateway='kubectl get gateway'
sudo cp /home/cloudshell-user/kubens /usr/local/sbin/kubens
export KUBE_EDITOR=vim
PS1='\[\033[35m\][\[\033[00m\]\[\033[31m\]\u\[\033[33m\]\[\033[33m\]@\[\033[03m\]\[\033[35m\]\h\[\033[00m\] \[\033[5;32m\]\w\[\033[00m\]\[\033[35m\]]\[\033[00m\]\[\033[5;31m\]\$\[\033[00m\] '
sudo rm -rf /usr/local/bin/kubectl-connect
