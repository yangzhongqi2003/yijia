          tcpSocket:
            port: 9121
          initialDelaySeconds: 10
          periodSeconds: 5
          timeoutSeconds: 3
          successThreshold: 1
          failureThreshold: 3
        volumeMounts:
        - name: idn-tr-pvc
          mountPath: /app/ssl
          subPath: ssl
      volumes:
      - name: idn-tr-pvc
        persistentVolumeClaim:
          claimName: idn-tr-pvc

ll


cat > cashout-order-statistics-rollout.yml << 'EOF'
apiVersion: argoproj.io/v1alpha1
kind: Rollout
metadata:
  name: cashout-order-statistics
  namespace: prod-idn-tr
spec:
  replicas: 1
  strategy:
    canary:
      steps:
      - setWeight: 20
      - pause: {duration: 10}
      - setWeight: 40
      - pause: {duration: 10}
      - setWeight: 60
      - pause: {duration: 10}
      - setWeight: 80
      - pause: {duration: 10}
      - setWeight: 100
      - pause: {duration: 10}
  revisionHistoryLimit: 2
  selector:
    matchLabels:
      app: cashout-order-statistics
  template:
    metadata:
      labels:
        app: cashout-order-statistics
    spec:
      terminationGracePeriodSeconds: 120
      tolerations:
      - effect: NoSchedule
        key: prod
        operator: Equal
        value: prod
      nodeSelector:
        prod: prod
      imagePullSecrets:
      - name: ecr-regcred
      containers:
      - name: cashout-order-statistics
        image: 676206931376.dkr.ecr.ap-southeast-1.amazonaws.com/cashout:release-a759169-72
        imagePullPolicy: IfNotPresent
        lifecycle:
          preStop:
            exec:
              command:
              - /bin/sh
              - -c
              - sleep 90
        command:
        - /bin/bash
        - -c
        args:
        - >
          cd /app && ./app orderStatistics
        env:
        - name: APP_ENV
          value: Prod
        - name: NACOS_DATA_ID
          value: "cashout"
        - name: NACOS_GROUP
          value: "DEFAULT_GROUP"
        - name: NACOS_HOST
          value: "nacos-headless.nacos.svc.cluster.local"
        - name: NACOS_PORT
          value: "8848"
        - name: NACOS_NAMESPACE_ID
          value: "idn_tr"
        - name: NACOS_USERNAME
          value: "nacos_idn_tr"
        - name: NACOS_PASSWORD
          value: "8XcMx3ap5h5507G1"
        - name: TZ
          value: "Asia/Jakarta"
        livenessProbe:
          tcpSocket:
            port: 9121
          initialDelaySeconds: 30
          periodSeconds: 10
          timeoutSeconds: 5
          successThreshold: 1
          failureThreshold: 3
        readinessProbe:
          tcpSocket:
            port: 9121
          initialDelaySeconds: 10
          periodSeconds: 5
          timeoutSeconds: 3
          successThreshold: 1
          failureThreshold: 3
        volumeMounts:
        - name: idn-tr-pvc
          mountPath: /app/ssl
          subPath: ssl
      volumes:
      - name: idn-tr-pvc
        persistentVolumeClaim:
          claimName: idn-tr-pvc
EOF

l
ll
kubectl apply -f .
po
ll
cat cashout-mq-consumer-rollout.yml
ll
 cat > cashout-mq-consumer-rollout.yml << 'EOF'
apiVersion: argoproj.io/v1alpha1
kind: Rollout
metadata:
  name: cashout-mq-consumer
  namespace: prod-idn-tr
spec:
  replicas: 4
  strategy:
    canary:
      steps:
      - setWeight: 20
      - pause: {duration: 10}
      - setWeight: 40
      - pause: {duration: 10}
      - setWeight: 60
      - pause: {duration: 10}
      - setWeight: 80
      - pause: {duration: 10}
      - setWeight: 100
      - pause: {duration: 10}
  revisionHistoryLimit: 2
  selector:
    matchLabels:
      app: cashout-mq-consumer
  template:
    metadata:
      labels:
        app: cashout-mq-consumer
    spec:
      terminationGracePeriodSeconds: 120
      tolerations:
      - effect: NoSchedule
        key: prod
        operator: Equal
        value: prod
      nodeSelector:
        prod: prod
      imagePullSecrets:
      - name: ecr-regcred
      containers:
      - name: cashout-mq-consumer
        image: 676206931376.dkr.ecr.ap-southeast-1.amazonaws.com/cashout:release-ab42eaa-80
        imagePullPolicy: IfNotPresent
        lifecycle:
          preStop:
            exec:
              command:
              - /bin/sh
              - -c
              - sleep 90
        command:
        - /bin/bash
        - -c
        args:
        - >
          cd /app && ./app mqConsumer
        env:
        - name: APP_ENV
          value: Prod
        - name: NACOS_DATA_ID
          value: "cashout"
        - name: NACOS_GROUP
          value: "DEFAULT_GROUP"
        - name: NACOS_HOST
          value: "nacos-headless.nacos.svc.cluster.local"
        - name: NACOS_PORT
          value: "8848"
        - name: NACOS_NAMESPACE_ID
          value: "idn_tr"
        - name: NACOS_USERNAME
          value: "nacos_idn_tr"
        - name: NACOS_PASSWORD
          value: "8XcMx3ap5h5507G1"
        - name: TZ
          value: "Asia/Jakarta"
        livenessProbe:
          tcpSocket:
            port: 9121
          initialDelaySeconds: 30
          periodSeconds: 10
          timeoutSeconds: 5
          successThreshold: 1
          failureThreshold: 3
        readinessProbe:
          tcpSocket:
            port: 9121
          initialDelaySeconds: 10
          periodSeconds: 5
          timeoutSeconds: 3
          successThreshold: 1
          failureThreshold: 3
        volumeMounts:
        - name: idn-tr-pvc
          mountPath: /app/ssl
          subPath: ssl
      volumes:
      - name: idn-tr-pvc
        persistentVolumeClaim:
          claimName: idn-tr-pvc
EOF

ll
kubectl apply -f .
po
kubectl delete -f .
po
kubectl apply -f .
ll
cat > cashout-retry-rollout.yml << 'EOF'
apiVersion: argoproj.io/v1alpha1
kind: Rollout
metadata:
  name: cashout-retry
  namespace: prod-idn-tr
spec:
  replicas: 1
  strategy:
    canary:
      steps:
      - setWeight: 20
      - pause: {duration: 10}
      - setWeight: 40
      - pause: {duration: 10}
      - setWeight: 60
      - pause: {duration: 10}
      - setWeight: 80
      - pause: {duration: 10}
      - setWeight: 100
      - pause: {duration: 10}
  revisionHistoryLimit: 2
  selector:
    matchLabels:
      app: cashout-retry
  template:
    metadata:
      labels:
        app: cashout-retry
    spec:
      terminationGracePeriodSeconds: 120
      tolerations:
      - effect: NoSchedule
        key: prod
        operator: Equal
        value: prod
      nodeSelector:
        prod: prod
      imagePullSecrets:
      - name: ecr-regcred
      containers:
      - name: cashout-retry
        image: 676206931376.dkr.ecr.ap-southeast-1.amazonaws.com/cashout:release-f78345c-91
        imagePullPolicy: IfNotPresent
        lifecycle:
          preStop:
            exec:
              command:
              - /bin/sh
              - -c
              - sleep 90
        command:
        - /bin/bash
        - -c
        args:
        - >
          cd /app && ./app retry
        ports:
        - name: retry
          containerPort: 9121
          protocol: TCP
        env:
        - name: APP_ENV
          value: Prod
        - name: NACOS_DATA_ID
          value: "cashout"
        - name: NACOS_GROUP
          value: "DEFAULT_GROUP"
        - name: NACOS_HOST
          value: "nacos-headless.nacos.svc.cluster.local"
        - name: NACOS_PORT
          value: "8848"
        - name: NACOS_NAMESPACE_ID
          value: "idn_tr"
        - name: NACOS_USERNAME
          value: "nacos_idn_tr"
        - name: NACOS_PASSWORD
          value: "8XcMx3ap5h5507G1"
        - name: TZ
          value: "Asia/Jakarta"
        livenessProbe:
          tcpSocket:
            port: 9121
          initialDelaySeconds: 30
          periodSeconds: 10
          timeoutSeconds: 5
          successThreshold: 1
          failureThreshold: 3
        readinessProbe:
          tcpSocket:
            port: 9121
          initialDelaySeconds: 10
          periodSeconds: 5
          timeoutSeconds: 3
          successThreshold: 1
          failureThreshold: 3
        volumeMounts:
        - name: idn-tr-pvc
          mountPath: /app/ssl
          subPath: ssl
      volumes:
      - name: idn-tr-pvc
        persistentVolumeClaim:
          claimName: idn-tr-pvc
EOF

ll
kubectl apply -f .
po
cd .
cd ..
ll
cd svc-yml/
ll
cat > cashout-http-svc.yml  << 'EOF'
apiVersion: v1
kind: Service
metadata:
  annotations:
  labels:
    app: cashout-http
  name: cashout-http-svc
  namespace: prod-idn-tr
spec:
  ports:
  - name: http
    port: 20021
    targetPort: http
  - name: rpc
    port: 10001
    targetPort: rpc
  selector:
    app: cashout-http
  type: ClusterIP
EOF

ll
kubectl apply -f cashout-http-svc.yml 
cd ..
ll
cd ..
ll
cd channel-yml/
ll
mkdir rollouts-yml
ll
cd rollouts-yml/
ll
cat > channel-http-rollout.yml  << 'EOF'
apiVersion: argoproj.io/v1alpha1
kind: Rollout
metadata:
  name: channel-http
  namespace: prod-idn-tr
spec:
  replicas: 2
  strategy:
    canary:
      steps:
      - setWeight: 20
      - pause: {duration: 10}
      - setWeight: 40
      - pause: {duration: 10}
      - setWeight: 60
      - pause: {duration: 10}
      - setWeight: 80
      - pause: {duration: 10}
      - setWeight: 100
      - pause: {duration: 10}
  revisionHistoryLimit: 2
  selector:
    matchLabels:
      app: channel-http
  template:
    metadata:
      labels:
        app: channel-http
    spec:
      terminationGracePeriodSeconds: 120
      tolerations:
      - effect: NoSchedule
        key: prod
        operator: Equal
        value: prod
      nodeSelector:
        prod: prod
      imagePullSecrets:
      - name: ecr-regcred
      containers:
      - name: channel-http
        image: 676206931376.dkr.ecr.ap-southeast-1.amazonaws.com/channel:master-897ba57-224
        lifecycle:
          preStop:
            exec:
              command:
              - /bin/sh
              - -c
              - sleep 90
        command:
        - /bin/bash
        - -c
        args:
        - >
          cd /app && ./app channel
        ports:
        - name: http
          containerPort: 20022
          protocol: TCP
        - name: rpc
          containerPort: 10022
          protocol: TCP
        env:
        - name: APP_ENV
          value: Prod
        - name: NACOS_DATA_ID
          value: "channel"
        - name: NACOS_GROUP
          value: "DEFAULT_GROUP"
        - name: NACOS_HOST
          value: "nacos-headless.nacos.svc.cluster.local"
        - name: NACOS_PORT
          value: "8848"
        - name: NACOS_NAMESPACE_ID
          value: "idn_tr"
        - name: NACOS_USERNAME
          value: "nacos_idn_tr"
        - name: NACOS_PASSWORD
          value: "8XcMx3ap5h5507G1"
        - name: TZ
          value: "Asia/Jakarta"
        livenessProbe:
          tcpSocket:
            port: 9121
          initialDelaySeconds: 30
          periodSeconds: 10
          timeoutSeconds: 5
          successThreshold: 1
          failureThreshold: 3
        readinessProbe:
          tcpSocket:
            port: 9121
          initialDelaySeconds: 10
          periodSeconds: 5
          timeoutSeconds: 3
          successThreshold: 1
          failureThreshold: 3
        volumeMounts:
        - name: idn-tr-pvc
          mountPath: /app/ssl
          subPath: ssl
      volumes:
      - name: idn-tr-pvc
        persistentVolumeClaim:
          claimName: idn-tr-pvc
EOF

l
ll
kubectl apply -f channel-http-rollout.yml 
po
ll
cat > channel-mq-consumer-rollout.yml << 'EOF'
apiVersion: argoproj.io/v1alpha1
kind: Rollout
metadata:
  name: channel-mq-consumer
  namespace: prod-idn-tr
spec:
  replicas: 2
  strategy:
    canary:
      steps:
      - setWeight: 20
      - pause: {duration: 10}
      - setWeight: 40
      - pause: {duration: 10}
      - setWeight: 60
      - pause: {duration: 10}
      - setWeight: 80
      - pause: {duration: 10}
      - setWeight: 100
      - pause: {duration: 10}
  revisionHistoryLimit: 2
  selector:
    matchLabels:
      app: channel-mq-consumer
  template:
    metadata:
      labels:
        app: channel-mq-consumer
    spec:
      terminationGracePeriodSeconds: 120
      tolerations:
      - effect: NoSchedule
        key: prod
        operator: Equal
        value: prod
      nodeSelector:
        prod: prod
      imagePullSecrets:
      - name: ecr-regcred
      containers:
      - name: channel-mq-consumer
        image: 676206931376.dkr.ecr.ap-southeast-1.amazonaws.com/channel:master-897ba57-224
        imagePullPolicy: IfNotPresent
        lifecycle:
          preStop:
            exec:
              command:
              - /bin/sh
              - -c
              - sleep 90
        command:
        - /bin/bash
        - -c
        args:
        - >
          cd /app && ./app mqConsumer
        env:
        - name: APP_ENV
          value: Prod
        - name: NACOS_DATA_ID
          value: "channel"
        - name: NACOS_GROUP
          value: "DEFAULT_GROUP"
        - name: NACOS_HOST
          value: "nacos-headless.nacos.svc.cluster.local"
        - name: NACOS_PORT
          value: "8848"
        - name: NACOS_NAMESPACE_ID
          value: "idn_tr"
        - name: NACOS_USERNAME
          value: "nacos_idn_tr"
        - name: NACOS_PASSWORD
          value: "8XcMx3ap5h5507G1"
        - name: TZ
          value: "Asia/Jakarta"
        livenessProbe:
          tcpSocket:
            port: 9121
          initialDelaySeconds: 30
          periodSeconds: 10
          timeoutSeconds: 5
          successThreshold: 1
          failureThreshold: 3
        readinessProbe:
          tcpSocket:
            port: 9121
          initialDelaySeconds: 10
          periodSeconds: 5
          timeoutSeconds: 3
          successThreshold: 1
          failureThreshold: 3
        volumeMounts:
        - name: idn-tr-pvc
          mountPath: /app/ssl
          subPath: ssl
      volumes:
      - name: idn-tr-pvc
        persistentVolumeClaim:
          claimName: idn-tr-pvc
EOF

ll
kubectl apply -f .
po
cd ..ll
cd ..
ll
mkdir svc-yml/
ll
cd svc-yml/
l
ll
cat > channel-http-svc.yml  << 'EOF'
apiVersion: v1
kind: Service
metadata:
  name: channel-http-svc
  namespace: prod-idn-tr
spec:
  ports:
  - name: http
    port: 20022
    protocol: TCP
    targetPort: http
  - name: rpc
    port: 10022
    protocol: TCP
    targetPort: rpc
  selector:
    app: channel-http
  type: ClusterIP
EOF

ll
kubectl apply -f .
svc
        ppopo
po
kubectl delete po backend-admin-5456ff875d-vff96 
 
po
kubectl logs -f backend-admin-5456ff875d-jcgrr  
po
cd
l
cd mysql
ll
cd mysql-
cd mysql-yml/
ll
kubens 
kubens  mysql
ll
cat dg-agent-idn-bp-deployment.yml 
ll
cat > dg-agent-idn-tr-deployment.yml  << 'EOF'
apiVersion: apps/v1
kind: Deployment
metadata:
  name: dg-agent-idn-tr
  namespace: mysql
  labels:
    app: dg-agent-idn-tr
spec:
  replicas: 1
  selector:
    matchLabels:
      app: dg-agent-idn-tr
  template:
    metadata:
      labels:
        app: dg-agent-idn-tr
    spec:
      tolerations:
      - effect: NoSchedule
        key: prod
        operator: Equal
        value: prod
      nodeSelector:
        prod: prod
      containers:
      - name: dg-agent-idn-tr
        image: dg-image-repository-registry.cn-hangzhou.cr.aliyuncs.com/dg-public/dg-public:latest
        env:
        - name: DG_AGENT_TOKEN
          value: "FEqSv2u1KceK8McFL9CxkY3Yx1os47c3"
        - name: DG_AGENT_ENDPOINT
          value: "pub-ap-southeast-1.dg.aliyuncs.com"
        resources:
          requests:
            memory: "64Mi"
            cpu: "50m"
          limits:
            memory: "128Mi"
            cpu: "100m"
---
apiVersion: v1
kind: Service
metadata:
  name: dg-agent-idn-tr-service
  namespace: mysql
  labels:
    app: dg-agent-idn-tr
spec:
  selector:
    app: dg-agent-idn-tr
  ports:
  - protocol: TCP
    port: 80
    targetPort: 8080  # 根据实际镜像调整目标端口
  type: ClusterIP
EOF

ll
kubectl apply -f dg-agent-idn-tr-deployment.yml 
p
po
poo
poppopo
po
kubens 
kubens  transafe
kubectl 
kubens 
kubens prod-idn-tr
ku
kubectl top node
kn
kubectl describe node |grep Ta
kube
kubens rocketmq
kubectl top po
kubens 
kubens  mongodb-idn-bp
kubectl top po
po
kubens rocketmq-idn-bp
kubectl top po
po
kubectl top node
kn
kubectl describe node |grep Ta
po
p
k
kn
cd
ll
cp -r rocketmq-idn-bp-yml rocketmq-idn-tr-yml
ll
cd rocketmq-idn-tr-yml
ll
vim rocketmq-nameserver.yml
kubectl apply -f rocketmq-nameserver.yml
kubens 
kubectl create ns rocketmq-idn-tr
kubectl apply -f rocketmq-nameserver.yml
kubens rocketmq-idn-tr
po
poo
kubectl describe node |grep Ta
kn
po
poo
po
pod
ll
cp rocketmq-broker-idn-bp-master.yml rocketmq-broker-idn-tr-master.yml
ll
vim rocketmq-broker-idn-tr-master.yml
kubectl apply -f rocketmq-broker-idn-tr-master.yml
po
pvc
po
poo
l
ll
poo
rm -rf rocketmq-broker-idn-bp-master.yml
ll
mv rocketmq-broker-idn-bp-slave.yml rocketmq-broker-idn-tr-slave.yml
ll
vim  rocketmq-broker-idn-tr-slave.yml
kubectl apply -f rocketmq-broker-idn-tr-slave.yml
poo
pvc
poo
kubectl describe po rocketmq-broker-idn-tr-master-0 
ll
vim  rocketmq-broker-idn-tr-master.yml
kubectl apply -f  rocketmq-broker-idn-tr-master.yml
po
kubectl describe po rocketmq-broker-idn-tr-master-0  
po
kubectl delete po rocketmq-broker-idn-tr-master-0  --force
po
ll
vm rocketmq-dashboard.yml
vim rocketmq-dashboard.yml
kubectl apply -f rocketmq-dashboard.yml
po
ll
poo
ll
mv rocketmq-exporter-idn-bp.yml rocketmq-exporter-idn-tr.yml
ll
vim rocketmq-exporter-idn-tr.yml
kubectl apply -f rocketmq-exporter-idn-tr.yml
ppo
poo
ll
mv rocketmq-proxy-idn-bp.yml rocketmq-proxy-idn-tr.yml
ll
vim rocketmq-proxy-idn-tr.yml
kubectl apply -f rocketmq-proxy-idn-tr.yml
po
poo
ll
cat rocketmq-dashboard-Ingress.yml
ll
cat > rocketmq-dashboard-Ingress.yml << 'EOF'
apiVersion: networking.k8s.io/v1
kind: Ingress
metadata:
  name: rocketmq-dashboard-ingress
  namespace: rocketmq-idn-tr
  annotations:
    cert-manager.io/cluster-issuer: prod-issuer 
    acme.cert-manager.io/http01-edit-in-place: "true"
    nginx.ingress.kubernetes.io/ssl-redirect: 'false'
    nginx.ingress.kubernetes.io/proxy-body-size: '4G'
spec:
  ingressClassName: nginx
  rules:
  - host: rocketmq-idn-bp.transafe.co
    http:
      paths:
      - path: /
        pathType: Prefix
        backend:
          service:
            name: rocketmq-dashboard
            port:
              number: 8082

  tls:
  - hosts:
    - rocketmq-idn-bp.transafe.co
    secretName: rocketmq-dashboard-ingress-tls
EOF

ll
kubectl apply -f rocketmq-dashboard-Ingress.yml
ingress 
po
poo
ingress 
po
kubectl logs -f cm-acme-http-solver-z4xb7  
po
kubectl get certificate
po
poo
po
ll
cd
lll
ll
cp -r mongodb-yml mongodb-idn-tr-yml
ll
cd mongodb-idn-tr-yml
ll
cd
ll
mv mongodb-yml mongodb-idn-bp-yml
ll
cd mongodb-idn-tr-yml
ll
vim mongodb-StatefulSet.yml
cat mongodb-StatefulSet.yml
poo
ll
kubectl apply -f  mongodb-StatefulSet.yml
kubectl create mongodb-idn-tr
kubectl create ns mongodb-idn-tr
kubectl apply -f  mongodb-StatefulSet.yml
poo
kubens 
kubens  mongodb-idn-tr
poo
kn
kubectl describe node |grep Ta
poo
ll
vim mongodb-Service.yml
kubectl apply -f mongodb-Service.yml
vim mongodb-Service.yml
kubectl apply -f mongodb-Service.yml
svc
po
poo
svc
ll
cat dg-agent-deployment.yml 
ll
cat mongodb-StatefulSet.yml
ll
cat > dg-agent-deployment.yml  << 'EOF'
apiVersion: apps/v1
kind: Deployment
metadata:
  name: dg-agent
  namespace: mongodb-idn-tr
  labels:
    app: dg-agent
spec:
  replicas: 1
  selector:
    matchLabels:
      app: dg-agent
  template:
    metadata:
      labels:
        app: dg-agent
    spec:
      nodeSelector:
        mongodb-idn-tr: mongodb-idn-tr
      tolerations:
      - effect: NoSchedule
        key: mongodb-idn-tr
        operator: Equal
        value: mongodb-idn-tr
      containers:
      - name: dg-agent
        image: dg-image-repository-registry.cn-hangzhou.cr.aliyuncs.com/dg-public/dg-public:latest
        env:
        - name: DG_AGENT_TOKEN
          value: "InxAG592n9kXUx1KCYuhDhtrCcwkiaCM"
        - name: DG_AGENT_ENDPOINT
          value: "pub-ap-southeast-1.dg.aliyuncs.com"
        resources:
          requests:
            memory: "64Mi"
            cpu: "50m"
          limits:
            memory: "128Mi"
            cpu: "100m"
---
apiVersion: v1
kind: Service
metadata:
  name: dg-agent-service
  namespace: mongodb-idn-tr
  labels:
    app: dg-agent
spec:
  selector:
    app: dg-agent
  ports:
  - protocol: TCP
    port: 80
    targetPort: 8080  # 根据实际镜像调整目标端口
  type: ClusterIP
EOF

ll
kubectl apply -f dg-agent-deployment.yml 
po
poo
ll
cat mongodb-StatefulSet.yml 
po
poo
ll
svc
exit
kubectl get pod -A
exit
kubectl get pv
ls
cd prod-idn-tr-yml/
ls
cd php-yml/
ls
more php-pay.yml 
ls
kubectl get pv
kubectl get pv prod-idn-tr/idn-tr-pvc  -o jsonpath='{.spec.csi.volumeHandle}'
kubectl get pv prod-idn-tr/idn-tr-pvc  -o jsonpath='{.spec.csi.volumeHandle}' -n prod-idn-tr
kubectl get pvc
kubectl get pvc -a
kubectl get pvc -A
ls
kubectl get pod -A
kubectl exec -it backend-admin-6bf56974d5-zk4gt  -n prod-idn-tr -- bash
kubectl exec -it backend-admin-6bf56974d5-zk4gt  -n prod-idn-bp -- bash
kubectl get pod -A
kubectl exec -it rocketmq-proxy-idn-bp-79db75fbd6-gnt7z  -n   rocketmq-nameserver-0                           1/1     Running   0             29d-- bash
kubectl exec -it rocketmq-proxy-idn-bp-79db75fbd6-gnt7z  -n rocketmq-idn-bp -- bash
ls
exit
