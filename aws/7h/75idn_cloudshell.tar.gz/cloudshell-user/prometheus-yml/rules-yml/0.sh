# 更新前面创建空的prometheus-rules的ConfigMap
kubectl -n monitoring create configmap prometheus-rules \
--from-file=blackbox-ssl.rules.yml \
--from-file=hosts.rules.yml \
--from-file=kubeadm.rules.yml \
--from-file=pod.rules.yml \
--from-file=pvc.rules.yml \
--from-file=mysql.rules.yml \
-o yaml --dry-run=client | kubectl apply -f -
