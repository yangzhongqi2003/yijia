<?php

use EasySwoole\Log\LoggerInterface;

$tmpDir = '/tmp/coverpay';
return [
    'SERVER_NAME' => "transafe-1001",
    'TIMEZONE' => 'Asia/Jakarta',
   // 'SLAVE_SERVER' => true,
    'LOCATION' => 'ID',
    'DOMAIN' => 'https://api-idn.transafe.co',
    'CASHIER_DOMAIN' => 'https://pay.mandiri.ink',
    'GolangOrderService' => 'https://g-idn.transafe.co',
    'MAIN_SERVER' => [
        'LISTEN_ADDRESS' => '0.0.0.0',
        'PORT' => 7800,
        // 可选为 EASYSWOOLE_SERVER  EASYSWOOLE_WEB_SERVER EASYSWOOLE_WEB_SOCKET_SERVER
        'SERVER_TYPE' => EASYSWOOLE_WEB_SERVER,
        'SOCK_TYPE' => SWOOLE_TCP,
        'RUN_MODEL' => SWOOLE_PROCESS,
        'SETTING' => [
            'worker_num' => 9,
            'reload_async' => true,
            'max_wait_time' => 5,
            'max_connection' => 85000, // 最大连接数
            'max_coroutine' => 100000, // 最大进程数
            'max_concurrency' => 65000, // 最大并发 HTTP 请求数
            'heartbeat_check_interval' => 10, // websocket每5秒侦测一次心跳
            'heartbeat_idle_time' => 30, // 一个TCP连接如果在10秒内未向服务器端发送数据，将会被切断
            'document_root' => EASYSWOOLE_ROOT . '/Public/',
            'enable_static_handler' => true,
        ],
        'TASK' => [
            'workerNum' => 6,
            'maxRunningNum' => 512,
            'timeout' => 15
        ]
    ],
    'TEMP_DIR' => $tmpDir,

    'AWS_CONF' => [
        'credentials' => [
            'key' => 'AKIAZ24IS5WYHAEBZE6Y',
            'secret' => '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',
        ],
        'region' => 'ap-southeast-3',
        'bucket' => 'transafe-ids3' //S3
    ],
    "LOG" => [
        'dir' => EASYSWOOLE_ROOT.'/Log/Cover',
        'level' => LoggerInterface::LOG_LEVEL_INFO,
        'handler' => new \App\Log\LogHandler(EASYSWOOLE_ROOT.'/Log/Cover'),
        'logConsole' => false,
        'displayConsole' => true,
        'ignoreCategory' => [],
        // 单独记录的日志级别 level
        'apart_level' => ['error'],
        // 单独记录的日志类型 category
        'apart_category' => ['sql', 'worker', 'lowlevel'],
    ],

    'MONGO' => [
        'url' => 'mongodb://root:j25OuvEvLjdPbdJB@mongodb-headless.mongodb-idn-tr:27017',
        'dbname' => 'coldpay'
    ],

    'MYSQL' => [
        'default' => [
            'host' => 'mysql-idn-tr-instance-1.c3ykomem8ks1.ap-southeast-3.rds.amazonaws.com',
            'port' => 3306,
            'user' => 'pay_goadmin',
            'pre' => 'pay_',
            'password' => 'kh22UuWqL9^pl1',
            'database' => 'pay',
            'timeout' => 30,
            'charset' => 'utf8mb4',
            'maxObjectNum' => 500, // 设置 连接池最大数量
            'minObjectNum' => 1, // 设置 连接池最小数量
            'intervalCheckTime' => 15 * 1000, // 设置 连接池定时器执行频率
            'maxIdleTime' => 5, // 设置 连接池对象最大闲置时间 (秒)
        ],
        'read' => [
            'host' => 'mysql-idn-tr-instance-1.c3ykomem8ks1.ap-southeast-3.rds.amazonaws.com',
            'port' => 3306,
            'user' => 'pay_goadmin',
            'pre' => 'pay_',
            'password' => 'kh22UuWqL9^pl1',
            'database' => 'pay',
            'timeout' => 30,
            'charset' => 'utf8mb4',
            'maxObjectNum' => 500, // 设置 连接池最大数量
            'minObjectNum' => 1, // 设置 连接池最小数量
            'intervalCheckTime' => 15 * 1000, // 设置 连接池定时器执行频率
            'maxIdleTime' => 5, // 设置 连接池对象最大闲置时间 (秒)
        ],
    ],
    'REDIS' => [
        'default' => [
            'host' => 'master.redis-idn-tr.m3xuvy.apse3.cache.amazonaws.com', // Redis 地址
            'port' => '6379', // Redis 端口
            'auth' => '', // Redis 密码
            'timeout' => 2.0, // Redis 操作超时时间
            'reconnectTimes' => 3, // Redis 自动重连次数
            'db' => 0, // Redis 库  pdl 3 4   game 5 6
            'serialize' => \EasySwoole\Redis\Config\RedisConfig::SERIALIZE_NONE, // 序列化类型，默认不序列化
            'packageMaxLength' => 1024 * 1024 * 2, // 允许操作的最大数据

            'intervalCheckTime' => 15 * 1000, // 设置 连接池定时器执行频率
            'maxIdleTime' => 10, // 设置 连接池对象最大闲置时间 (秒)
            'maxObjectNum' => 9000, // 设置 连接池最大数量
            'minObjectNum' => 80, // 设置 连接池最小数量
            'getObjectTimeout' => 5.0, // 设置 获取连接池的超时时间
            'loadAverageTime' => 0.001, // 设置 负载阈值
        ],
        'statics' => [
            'host' => 'master.redis-idn-tr.m3xuvy.apse3.cache.amazonaws.com', // Redis 地址
            'port' => '6379', // Redis 端口
            'auth' => '', // Redis 密码
            'timeout' => 2.0, // Redis 操作超时时间
            'reconnectTimes' => 3, // Redis 自动重连次数
            'db' => 10, // Redis 库  pdl 3 4   game 5 6
            'serialize' => \EasySwoole\Redis\Config\RedisConfig::SERIALIZE_NONE, // 序列化类型，默认不序列化
            'packageMaxLength' => 1024 * 1024 * 2, // 允许操作的最大数据

            'intervalCheckTime' => 15 * 1000, // 设置 连接池定时器执行频率
            'maxIdleTime' => 10, // 设置 连接池对象最大闲置时间 (秒)
            'maxObjectNum' => 9000, // 设置 连接池最大数量
            'minObjectNum' => 80, // 设置 连接池最小数量
            'getObjectTimeout' => 5.0, // 设置 获取连接池的超时时间
            'loadAverageTime' => 0.001, // 设置 负载阈值
        ],
        'list' => [
            'host' => 'master.redis-idn-tr.m3xuvy.apse3.cache.amazonaws.com', // Redis 地址
            'port' => '6379', // Redis 端口
            'auth' => '', // Redis 密码
            'timeout' => 2.0, // Redis 操作超时时间
            'reconnectTimes' => 3, // Redis 自动重连次数
            'db' => 9, // Redis 库  pdl 3 4   game 5 6
            'serialize' => \EasySwoole\Redis\Config\RedisConfig::SERIALIZE_NONE, // 序列化类型，默认不序列化
            'packageMaxLength' => 1024 * 1024 * 2, // 允许操作的最大数据

            'intervalCheckTime' => 15 * 1000, // 设置 连接池定时器执行频率
            'maxIdleTime' => 10, // 设置 连接池对象最大闲置时间 (秒)
            'maxObjectNum' => 9000, // 设置 连接池最大数量
            'minObjectNum' => 80, // 设置 连接池最小数量
            'getObjectTimeout' => 5.0, // 设置 获取连接池的超时时间
            'loadAverageTime' => 0.001, // 设置 负载阈值
        ],
        'websocket' => [
            'host' => 'master.redis-idn-tr.m3xuvy.apse3.cache.amazonaws.com', // Redis 地址
            'port' => '6379', // Redis 端口
            'auth' => '', // Redis 密码
            'timeout' => 1.0, // Redis 操作超时时间
            'reconnectTimes' => 3, // Redis 自动重连次数
            'db' => 8, // Redis 库
            'serialize' => \EasySwoole\Redis\Config\RedisConfig::SERIALIZE_NONE, // 序列化类型，默认不序列化
            'packageMaxLength' => 1024 * 1024 * 2, // 允许操作的最大数据

            'intervalCheckTime' => 15 * 1000, // 设置 连接池定时器执行频率
            'maxIdleTime' => 5, // 设置 连接池对象最大闲置时间 (秒)
            'maxObjectNum' => 3000, // 设置 连接池最大数量
            'minObjectNum' => 5, // 设置 连接池最小数量
            'getObjectTimeout' => 3.0, // 设置 获取连接池的超时时间
            'loadAverageTime' => 0.001, // 设置 负载阈值
        ],
        'common' => [
            'host' => 'master.redis-idn-tr.m3xuvy.apse3.cache.amazonaws.com', // Redis 地址
            'port' => '6379', // Redis 端口
            'auth' => '', // Redis 密码
            'timeout' => 1.0, // Redis 操作超时时间
            'reconnectTimes' => 3, // Redis 自动重连次数
            'db' => 0, // Redis 库  pdl 3 4   game 5 6
            'serialize' => \EasySwoole\Redis\Config\RedisConfig::SERIALIZE_NONE, // 序列化类型，默认不序列化
            'packageMaxLength' => 1024 * 1024 * 2, // 允许操作的最大数据

            'intervalCheckTime' => 15 * 1000, // 设置 连接池定时器执行频率
            'maxIdleTime' => 5, // 设置 连接池对象最大闲置时间 (秒)
            'maxObjectNum' => 6000, // 设置 连接池最大数量
            'minObjectNum' => 5, // 设置 连接池最小数量
            'getObjectTimeout' => 3.0, // 设置 获取连接池的超时时间
            'loadAverageTime' => 0.001, // 设置 负载阈值
        ],
    ],

    // 超级管理员id
    'SUPER_ROLE' => [1, 'Super'],

    'UPLOAD' => [
        'dir' => EASYSWOOLE_ROOT . '/Public/',
        'domain' => 'http://image-admin-easyswoole.develop',
    ],

    // 与客户端交互的字段名
    'fetchSetting' => [
        // 当前第几页
        'pageField' => 'page',
        // 每页大小
        'sizeField' => 'pageSize',
        // 列表dataSource的Key
        'listField' => 'items',
        // 合计页的Key
        'footerField' => 'summer',
        // 总条数
        'totalField' => 'total',
        // 导出表头
        'exportThField' => '_th',
        // 导出全部时发送的文件名
        'exprotFilename' => '_fname',
    ],

    'CHANNEL_CASHIER_HOST'=>'icicbank.ink',

    'export_dir' => $tmpDir . '/excel/',

    'TELEGRAM_CONF' => [
        'botToken' => '7121437237:AAHx8qWtE1KmL_9rRuxH035SwS9mRixnnR8',
        'botId' => '',
        'botName' => '@TransafeIdNotifyBot',
        'testChat' => -4087188509,
    ],
    // 通道telegram
    'TELEGRAM_CHANNEL_CONF' => [
        'botToken' => '7379612408:AAHPD4EZKH7lfzNv1_2Mut8KpCYwwPdQ1I0',
        'botName' => '@TransafeIdHelperBot',
        'testChat' => -4087188509,
    ],
    // 集团telegram
    'TELEGRAM_CLIQUE_CONF' => [
        'botToken' => '7630039904:AAHHctJOIQckfXBZuQND9210bXA8qeMQb5A',
        'botName' => '@BestPayChannelBot',
        'testChat' => -4087188509,
    ],

    // telegram
 //   'TELEGRAM_BOT_TOKEN' => '5651773008:AAGxifoduAt2jfMK4wbHCYRwhJbK_pNI5Z8', // telegram机器人 @OnepayNotifyBot
  //  'TELEGRAM_BOT_TEST' => '-804088740', // telegram测试账号

    // 滑块验证码
    'slider_verify_code' => [
        'appKey' => 'FFFF0N0000000000A8D3',
        'regionId' => 'cn-hangzhou',
        'accessKeyId' => 'LTAI5tGevAYdXwfMpV9mBM4e',
        'accessSecret' => 'wmH1F7f4dJWUGRlPJnkeIn4NKaXUqM',
        'scene' => 'Login',
        'ip' => '172.0.0.1',
    ],

    // APP配置信息
    'app' => [
        'verify' => 'cmmZMkNber%gyWPMUa6$K#C*gMaa@@GC6Q3w#F@9$Bpg46P5fammdvgD698XUP^b',
    ],

    /* jwt */
    'auth' => [
        'key' => '21Bs9aN5jrzc/weTKft5gEiX8WFQZrP78MaPL0J4Z7da7YchAmvJ69wO1+pQ=',
        'adminKey' => '19I136qT7%jA7ppkS44SfJ^A*6@8Psm2kKzS3Uh', // 后台
        'agentKey' => '001dUe9bhbc5hLQh9U!hq#UXzus%ad4LQoN3aC', // 代理商
        'apikey' => 'spay_key',
        'expire' => 86400 * 15, // token有效期
        'refresh' => 86400 * 10  // token有效期小于此值会自动续期
    ],


    //"GEETEST" => [
   //     "captcha_id" => "c6b11ed08abbd973ba297174d55523e4",
   //     "captcha_key" => "40726612f55e340b0903bc9e3cc098ef"
   // ],

    "GOOGLE_RECAPTCHA" => [
            "SITE_KEY" => "6LeDXesqAAAAACtwGnJVFP5mLoEmjd5qvUqpc9_T",
            "SECRET_KEY" => "6LeDXesqAAAAADfNkeWu9oNls4XpOxcXtylaKvq2",
        ],

    // 高权运营账户
    'HIGH_OP_LIST' => ["zhong",'zcy','lzp','easy','czz','zhy','mxm','guanchao','xwj950811','zhujiahui','xiangqin1992','jxl','hj','smy','wanglijuan','cdj'],
        // 内部商户
    'INTERNAL_MCH' => [1005],
    // 审核员
    'SUPER_HIGH_OP_LIST' => ['zhong','ratu', 'zcy','guanchao','xiangqin1992','hj', 'jxl'],

    //邮箱服务配置
    'MAILER' => [
        'host' => 'smtpout.secureserver.net',
        'port' => '465',
        'ssl' => true,
        'username' => 'donotreply@transafe.co',
        'password' => 'G9C8TfLJtFk2mq',
        'serverName' => 'Transafe Server',
    ],

    // 波场钱包
    'TRON_LINK' => [
        'doMain' => 'https://api.trongrid.io',
        'privateKey' => '0xec64b014638c0a8d576475f082bcf530b3a17b722e02d7f109c9ad2024bbf895',
        'addr' => 'TY3Z789GZyNZqwrgynwWmQeavtpA9A6wyh',
        'energyKey' => 'd73c7228-5558-4e9b-ac69-5aeab3816ddd'
    ],

//    'CASHIER_CONF_RBL' => [
//        'doMain' => 'https://order.webgameoss.com',
//        'channel_id' => 13,
//        'bank_id' => 3,
//        'conf_key' => 'plat_rbl'
//    ],
//
//    'CASHIER_CONF' => [
//        'doMain' => 'https://order.webgameoss.com',
//        'channel_id' => 13,
//        'conf_key' => 'plat',
//        'bank_id' => 3
//    ],

    // 平台公钥
    'PUBLIC_KEY' => 'MIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEAz/VKkjHLNPlmnVBVprSCYuSQS/guXo6ofWuzLbifQsQ8+hqHcdFGHEFixXqs1pjQjA9VOpqY5dpPo5b5HVSXG0yJ1pJBOvhnZjwgaT4PoYkVazjh/RXQH2Bof9pOGKIr7ifcN44jRra9ciqW0JB0RdXblIYmEtX7+oySzC9AUURW4FCb0oDWKQaE7AyS/6RXFCsRklUCDTLHp+fzerHwWhFM2jYvenw9imVgKq9VRbM3u+zLa6jUiC8a4KWUSpFa4KMs/Ug1zUKoFrhL+6Q1mW8m/l9RQg05BPsFE43zFUfLDt0yXUcDx6TR8yeYFiV2gOVJr6X18Nk2m/xg0Jg41wIDAQAB',
    // 平台私钥
    'PRIVATE_KEY' => 'MIIEvQIBADANBgkqhkiG9w0BAQEFAASCBKcwggSjAgEAAoIBAQDP9UqSMcs0+WadUFWmtIJi5JBL+C5ejqh9a7MtuJ9CxDz6Godx0UYcQWLFeqzWmNCMD1U6mpjl2k+jlvkdVJcbTInWkkE6+GdmPCBpPg+hiRVrOOH9FdAfYGh/2k4YoivuJ9w3jiNGtr1yKpbQkHRF1duUhiYS1fv6jJLML0BRRFbgUJvSgNYpBoTsDJL/pFcUKxGSVQINMsen5/N6sfBaEUzaNi96fD2KZWAqr1VFsze77MtrqNSILxrgpZRKkVrgoyz9SDXNQqgWuEv7pDWZbyb+X1FCDTkE+wUTjfMVR8sO3TJdRwPHpNHzJ5gWJXaA5UmvpfXw2Tab/GDQmDjXAgMBAAECggEAQmayPugDWJDiAQ0rrCUrFOSiZn+CXtLyXcnL1qeCwtDiH4HlCaSm3FLMdP3svkDhJjenISVH+OyyTSvhs0nVTfQsdwUQKwIyEeTU/IXCe/PHkQsCrcsPP1WLSHeuRBNUL6EuodaS0Pt8lj2fFk1psvrMOCp1ccI9yQyluujDgq7aC5LtLEOkmjuxBvzAqfwtKnK/LIKVhCtxy3q+GFkklHQTFodECMzylqOginJNpAWYJP0PVcOZFBKY2WXTVzRTxbLgDgm0/ETGFD75efKObtagNJZx7/RPI1RRClKBu0TP0D7L/uhQsZlRTD3+DEqbfbWkS3OjyFDZH0uQSfmRYQKBgQDwuruO9L7RwYpMkrZX1R+T48tu8c4A/oA9VKHHbY9mbpBAxTmZ/cWRe+3N0FnqQLWjQj1FT50VtgJd2pt2SGA68+htbasO7DcpJlO8dcR78Fe2YYRJmp+rQnh2tClS9q3SyPjv2RkxgVsvNZeY0Id69iACCEbuHSMCBXrDqvhQmQKBgQDdJmC0sktQ/O1XRGVIXozMTr0H9GdeJVFbb1TVRwJUHx8vItSrzOepsDFDWPQDX2GyllivmIX/XpJEDtbl/Zib4AXqGSWRe5tiDigOhU+PXTr6WRkYwG4tMTsIuaIvKEim9Kc2FzLLCIhJABKsOhXGyXdT0zeZTzCY2kWgHPcK7wKBgCN8k3uObrbDHh0Nn52xCDen4+xV7vVMjyD7YeHhL7t83vz9VfFybHZ222Z0qVyT73LCp/+YreJuc0jcmgBEyRLHs+K1wPqxLax+PufQQIe4tWVoWLT0+0amxNVS16ioPpWNFM1epo0asZNzBgb77ozczXkfOT2OxANfRWqkwHg5AoGBAMdT1gpIQbZnoozrqtaF0iY8Ogk3cwvaWvAs8quhaynjOzpDDKkk8RFzK5PmU1nO2MIc3Sa4NN6toOwS7AM0hh7I1svfiosMfErvM4+S/NjdUVFgiUxT9XpqSylcGCClEIbbMPOCCVgTArO5ixsM55/a6uD1GcHnLIg5BFSChvClAoGASYAO/2pRJthIwP3cFQDfjfkNZhtt3xIAc7XolzrWF0/eci9yq8y9GlAEFXqCGMuQYojniSSfC38E/NTDn499/EzZGZPI9rVjW/aH/DzDR3j4huC5DjGdDGTZ6kzDSXXjJ2IUqndfrTFyhMcd/L0wt9XPlhMgFfsifUGDr9bIPJg=',

    'DF_E2PAY' => [
        //'clientId' => 'f2b5ff1658688ded6fd47c4af8b11db1',
        //'secretKey' => '3a4719387299f8d73728e602091212cf',
        //'doMain' => 'https://disbursement.mbayar.co.id',
        //'username' => '081219218301',
        //'password' => 'D398305559E304ECC2AB8D3B6B5C4C21', //!Chichu6688
        //'accountSrc' => '7612000123120001',
        //'mobileMain' => 'https://disbursement.mbayar.co.id',
        //'sourceId' => 'JVSPG',
        //'oldRedisName' => 'common',
        //'oldRedisPrefix' => 'GM',
        //'oldPayoutChannelId' => 1,
            
        'doMain' => 'https://disbursementtest.mbayar.co.id/', // 测试
        //'doMain' => 'https://disbursement.mbayar.co.id/',
        'merchantID' => 'SB_EP00009449',
        'username' => 'anfalmutafif@outlook.com',
        'password' => 'K~5uA@4wH#9t',
        'clientId' => 'U0owV2XgERIrfkUGE0Ge609xGWuKFE1t',
        'clientSecret' => 'BhZnzaqtxmx5KIylFySotj03ENdf3PTc',
        'partnerId' => 1213,
        'sourceId' => 'SINARTS',
        'verify_key' => '0692953c5bb8c2505dc886cb0775b240',
        'secret_key' => '541502c8e821d85fb806f7cdfe3e8e4e',
    ],
    'DS_E2PAY' => [
        //'doMain' => 'https://pay.e2pay.co.id',
        //'merchantCode' => 'IF00400_S06',
        //'merchantKey' => 'QaycBSo38j2',
        //'orderNoPrefix' => 'SPB-',

        //'doMain' => 'https://pg.e2pay.co.id/',
        'doMain' => 'https://pg-sandbox.e2pay.co.id/', // 测试
        'merchantID' => 'SB_EP00009449',
        'clientId' => 'U0owV2XgERIrfkUGE0Ge609xGWuKFE1t',
        'clientSecret' => 'BhZnzaqtxmx5KIylFySotj03ENdf3PTc',
        'partnerId' => 1213,
        'sourceId' => 'SINARTS',
        'verify_key' => '0692953c5bb8c2505dc886cb0775b240',
        'secret_key' => '541502c8e821d85fb806f7cdfe3e8e4e',
    ],
    'ODEO_PAY' => [
        'doMain' => 'https://api.biz.odeo.co.id',
        'clientId' => 'x8f8rdsqogNvtw9dfZKBdxlxGNPtYbM6',
        'secretKey' => 'M14WfWTV7C2BSuD7FOJKEuZjIL72JqujvYg54O83RmcocjVGYg6kal8GKt4BnEpe',
        'signingKey' => 'a1gKuedBUuUqggwq57SOEPsOcUluTEuuEGwd2s692R13FVzO4AEwKfOMwGpi49oi',
        'oldRedisName' => 'common',
        'oldRedisPrefix' => 'GM',
    ],
    'ODEO_PAY1' => [
        'doMain' => 'https://api.biz.odeo.co.id',
        'clientId' => 'H6zCfhQ4zU2jH9eByPqHkNs6FvjvJhZP',
        'secretKey' => 'ZLsjjWsBkhX60SRcdoveuqwbN4bDHlueLf07XkmQJOjnMMSwbSshHS9LhKIvQyTM',
        'signingKey' => 'hVFOXZV7i9d2mfxxtC7zIESYNCbP3DnYDQFFDLdOTLBrXRedPzAyIJdJ7QP9fqEf',
        'oldRedisName' => 'common',
        'oldRedisPrefix' => 'GM',
    ],
    'LOKAL_PAY' => [
        'doMain' => 'https://api.carpentum.tech',
        'merchantCode' => 'LFI22-G7OZU6BH1V',
        'secretKey' => 'Brz34awnrF0lGgzex3tY0KkrndHij22OWGwYIThMWo53flC6rE',
        'oldRedisName' => 'common',
        'oldRedisPrefix' => 'GM',
        'oldPayinChannelId' => 5,
        'oldPayoutChannelId' => 9,
    ],
    'PEAR_PAY2' => [
        'doMain' => 'https://pay.pearpayment.com',
        'merchantId' => '10896',
        'payoutAppId' => '1089611866',
        'payinAppId' => '1089611867',
        'partnerKey' => 'iXvKSWv5c1b_RQfALlIsuchAGsyP7nRF',
        'aesKey' => 'AwZ2iBpjD19Ddjmx',
        'iv' => '87k5Hi01Tjbmtr83',
        'token' => 'fcqViz2LWeeD7aYeFZ9PW-pwIi9eoLki'
    ],
    //TarsPay
    'PARS_PAY' => [
        'doMain' => 'https://payment.tarspay.com',
        'mchNo' => 'M1734543514',
        'currency' => 'IDR',
        'platPublicKey' => '03029c655932f22aee81034d109795fbd7e23ca173ca27e195091d434e593a2e0f',
        'publicKey' => '02b6ff610e10013f4f9a94a3ea95b55fb08679d201b2bc0ab5fae1bdd0077f5b90',
        'privateKey' => '371b41984ca657afef01d192d145f39f11822673b73833a8d818b64c192c32f7',
    ],
    'PEAR_PAY' => [
                    'doMain' => 'https://pay.pearpayment.com',
                        'merchantId' => '10940',
                            'payoutAppId' => '1094011916',
                                'payinAppId' => '1094011917',
                                    'partnerKey' => 'c5hXQ3WG_OYXDZg5Y1Nm7edTleoL0kIj',
                                        'aesKey' => 'fQTEJIMdXUi-KJRH',
                                            'iv' => '87k5Hi01Tjbmtr83',
                                                'token' => 'dPu-bcpAFzNBQBX-QVTBUKNbEmx6fQJK'
    ],
    'GAJAH_PAY' => [
        'doMain' => 'https://api.cronosengine.com',
        'key' => 'CE-JUVGWNUZHGQGX9OS',
        'token' => 'o93bazCzCsdLBRCQkxK2w4RchHCmPOf6',
    ],
    'QBIZ_PAY' => [
        'doMain' => 'https://api.51qbiz.id/openapi',
        'platformUserId' => '20240814200145334478',
        'apiSecret' => '0BAY9Y89)gFfYxR9nDQ(lV9lL^n37gQkwgtw(W2d$2v$9h9ELfQGz!cCCmJyShk)',
        'merchantId' => '20240814200141446993',
    ],
    'LINKQU_PAY' => [
            'doMain' => 'https://api.linkqu.id',
            'clientId' => 'bd8b5367-e596-4730-8dbb-0f64e246ea23',
            'secretKey' => 'L90EqZKKtyzRWEms16sdXbuHP',
            'username' => 'LI876PZIN',
            'pin' => 'ElOg0kuTqlOOKjQ',
            'serviceKey' => 'Ik83inrgfAbw2qOK9KMSfxg8'
    ],
    'IFORTE_PAYIN' => [
        'doMain' => 'https://api-live.mcpayment.id',
        'apiKey' => 'MC2024092411',
        'secretKey' => '0xd6cd29594f82077f26',
        'hashKey' => '2Ulke6RbyeXJ7OH2xhvzWhd6Hm2DsUw+GbVmAwuBEm4',
    ],
    'IFORTE_PAYOUT' => [
        'doMain' => 'https://api.senmo.id',
        'clientId' => 'MCPD2409250067',
        'clientSecret' => '74997938839477ba',
        'accessTokenSignature' => 'OnZoAdTxrx/cYm0JdQrAaJ96chNu4baENsJbfwS1ujmh/Sa0ZhsFnCNH4bjVns6gHdxeWlEcn2icw1M7TRbk0a3WT2u4byB3ZJFXqObi0FYKzKkXoi4oFmnYc/VABBgZBRPTVTCoiaJm/pqD6WjI6mXAGPVFyhhtTyizdjKoO9I/rQ9hNC0pJ83GHQUIWR4H0ofcx9+R1xsEfFeit7W/9iKcjZqog36rus1TwnhXJN5o6z4w1hlV4N5kBp+uUK3EhBwKekxZTfYIrKNM+yOFqfIHjG3GPRBO8ZxgSncIZ3Ak85PKZeQLEgZKclWANVEpuNQPKlHvO+YZvbA+Zv/H1Q==',
        'sourceAccountNo' => '0060013063817',
        'timestampSign' => '2024-09-25T16:59:56+07:00',
    ],
// 通道信息待核实确认   
    'IFORTE_PAYIN2' => [            
       'doMain' => 'https://api-live.mcpayment.id',          
       'apiKey' => 'MC2024092411',           
       'secretKey' => '0xd6cd29594f82077f26',        
       'hashKey' => '2Ulke6RbyeXJ7OH2xhvzWhd6Hm2DsUw+GbVmAwuBEm4',
    ],
    'IFORTE_PAYOUT2' => [
       'doMain' => 'https://api.senmo.id',
       'clientId' => 'FLY-MCH202511060087',
       'clientSecret' => 'm1ewjXNcFSZS2UPv',
       'accessTokenSignature' => 'OnZoAdTxrx/cYm0JdQrAaJ96chNu4baENsJbfwS1ujmh/Sa0ZhsFnCNH4bjVns6gHdxeWlEcn2icw1M7TRbk0a3WT2u4byB3ZJFXqObi0FYKzKkXoi4oFmnYc/VABBgZBRPTVTCoiaJm/pqD6WjI6mXAGPVFyhhtTyizdjKoO9I/rQ9hNC0pJ83GHQUIWR4H0ofcx9+R1xsEfFeit7W/9iKcjZqog36rus1TwnhXJN5o6z4w1hlV4N5kBp+uUK3EhBwKekxZTfYIrKNM+yOFqfIHjG3GPRBO8ZxgSncIZ3Ak85PKZeQLEgZKclWANVEpuNQPKlHvO+YZvbA+Zv/H1Q==',
       'sourceAccountNo' => '0060013063817',
       'timestampSign' => '2024-09-25T16:59:56+07:00',
    ],

    'PAYOK_CONF' => [
        'doMain' => 'https://api.payok.com',
        'merchantId' => '020754',
        'publicKey' => 'MIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEApe6gO0Lwm8mBFXw5IO3xbEet3GsHexaQehdkhHvwbuP41aW8L8PRDaSA2HjljOOoP3oVT5rkjLqBawUO/gVqU74LcNoXEnkg8/7ZJDPXjz6yk+RV0QxaOisS2zBdwQka25ckCgEay4Xpawfu7J8myEYIxAP0WvVK5EiNPtnUQhGgWtvM8brgKa4RzVRnQSryN4L2zsDE0b1AtCFzjxlnUe9RTJAfBQiO84dMO0IuC5luieDaIssvBeep9RzCWw7baiKx+p0MfbO6SR+MGHzYbBJzNLLqY1C/T/7s7vbxpnn4pG49XeiixR6SC3zgdoOP2b65lEXoE0Rvy1RI4/aEpwIDAQAB',
        'privateKey' => 'MIIEvAIBADANBgkqhkiG9w0BAQEFAASCBKYwggSiAgEAAoIBAQC5hZt+PoijfqKRGu2hQS7rtGTROwYdgWv1P0n2W1bbiMHX22YEW+4BB/OLEchWDZxZVipBiZyL6xpbdA3lyqOsKNvtJNDPQI65avkeKgLnkLuDduIyvdBAuCjl4MEZeUoPVfIzEeBSjN1bqdXc0Khe7CmKm5RLI+/rVzetqC70B76+B0B+2XBlGC1rZSSlN4euh6RysWdZTEb6+S5kwV5DeRq2NHlU69qw0hkGMOXfWn8/odt3ya62lt/duD4/VpSlxu+BFcDM+l4q5wtl5iToMvqTF4Hs8nVWH1J/YpfnJDo8b+F4cxPMhaFPau0tglhvKD2JbLMS7Rzu00n5lJRVAgMBAAECggEADqewPcvAzXF+dAn1hYx5oWLxp9mKxR/pIElslUpn1RW7gkqxh1yfs3MmWPEBq1KN7DyzP9QYCrF6toi3ZFSak0ny/Yuv9v85hwodPbXB3vr+5QaqHaoC3mntySL0/gcnw4hdho099CdugQQsgbH16vGq4mkh0MG4/RU5r70eYGZtXyIVtuwv0gBn04vI3QFnaEQW7BR2bF631zaNuGXjRk2FkuE8I6qwKAA3bM0QtoDBx9r/J0TNiJn3BsKYsIvznqtP1jmDziMwLzKX35vpO6aIBjaib3CeUg+xxxs4sTStGPsQzYz8y3GgKub9k/Ub7xl2mUDdj5VmacxA7Bi7jQKBgQD+6W5yy9D33vzNLm+W2tRA48NOlrt8vW9Qb3xGRYJa03Y1O5e7jzQY/cDdTQYPYR1wB9zef1x+QIc9868wNsptynkK+VuZ5chPscPuXTLMAMPhELLgeGRwHjPIAuVXKl2ZBseq9vV327geuxpnBqttn3gEjeHPvg+2WciZeyJYGwKBgQC6UFis0KiAhn3J9qlIUw2PZnV0QySFvXtW4DmPUCvLNDyo1YKIOTDd//4GnRrwbQ5qIAt0CBqq+h2xzROdYWBheRnYyLxgLsx4q+7K1sRqSFEy47n/dICuTVS6XP1vmCpBZLmUk+VvnNEW83865GUXAkFr1Kb8CLbt3b+843BsTwKBgFtlww4x+ekF8Mp4ndYO/A+QGpTxAqRFH8ZNUte3UHfUXgvUJCFBxUI4qZAvb77P6Ugj6ZN1QuqZpGQYHXZCDu6yrBe9NJTHiLzaVg//JplypMjrvdcyE4EHszVBpI1OSWT2w1yPU4/4HdoW5+6Mu6aAiP3JCW/9C5EsO/qb5cKFAoGARg0pmiiGAnUO3J3qfjAD/DPY25LXK5XXxw1ddv38yVVlrVFB1/gw4Hd8yn3NgDJw5gQQalsVs82A1rY1tsnDFEMVLcYj1cIizQhQK2HezdtM9GZdK6hhLagTwFJwU8IRuS6m/C8zZ+i9UPTSlJEFVUZa1LFK655XMU5b5ihZv88CgYBbG2aoMjGPoLXaHGoB2gjQEeAl0R8g1+s0HXU09S3wq1Tb10A9hCq9B7AAWCFTUfpsd8/l2y64UEs7X15vmbjtqNEOZJo6CnO54dFZSN2DVOdGTdprgD0ttAc1Ipyxc5iZFjUpyURjdrnAxrl8e0y6cAT4n6uxvEWqPCv4jeIGXQ==',
    ],
    'PAYOK_CONF_020842' => [
        'doMain' => 'https://api.payok.com',
        'merchantId' => '020842',
        'publicKey' => 'MIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEAhFWc03C0NFFnOEd1ObGg/MrUXEyIhU1vPTZMXHwpcffDOqdIxaO/MRaoxJ/ucw4aYO8E/rWDbzPz3rPObJwJy4l60tyv7gJBUPF49/qm491Y7SSuSFt9KClCESJLCT0doTT79uducdwGIS2bDJMUec9P3NDaGHXT1oq43EiwpnNqb07hcSNMCfVPamzxENAXLqhbCPpUCR+/JlhsdN/Qn4okFbu/YZcxhUgBiBh5JNfVGYOS9gjAnygGG6yZM9JxLf7S9FZdKbTBr86qKMAcUd1Vrm84Wzfx5xCTWsIv8mGOp4bDl3CSYWmhHuKVNE9r6K0WmxyiVpvUUWX1gW0qSwIDAQAB',
        'privateKey' => 'MIIEvQIBADANBgkqhkiG9w0BAQEFAASCBKcwggSjAgEAAoIBAQCjXTzIbQYSX/OgKHF2p6TSVlCSS9SdJETTlS+WTNms2t6DlpXeIH1HWsDUgOKsj9foc+O2TaIBEimE33MStAAfeiHO6JcNQcM3l8wnVzpMndrA5W0nEEkHrJL8mZ9eNs8H4sFUooYj7qjoCDmzGZwvn5ds6AhT7m6xVIejY08oC8DPcjUNkhiXLWBkrk6VNqNmj3iI+ilKMtPyrF5Odo0vNXCpFilxf9b7ITP8MgFcPbCDFifDA/kJqR9CqOXQre+JJIK2J4HLTwHQnvAcqKLoBy+yfK2FqQ8g/ZQzn/9BlvrZn1TFzsyE9r99Qi+zlWYSVPPeD9nhygONCFJ03qG5AgMBAAECggEAHdXMYQpQPpDZjJl2R2ZMmsF6y40f0mcqTr4DR97XLlN2qe+ZhUzHtH1llCnJvBw1IVXw831wJePsQ0EP4g2PrDAA9qnR1HD7Ny748QJkOlPl/K6p5aV6wPUKjyl7SpiV7OnDxzI7b1qJ7H58EzKNLMFnxVMHGlUEUEyQzQ05CqX3DhIQwxoQsWxy5Q7xNR8rDaDIE/wddw00SPaECmDOerng096nEuNPVSoakbBI1O+B7r/aBQzd681CnEy+NaQIBCoHKq4+0FXigHKY0TG2WWxM5DQmRnUzKtGr66cBdpe1pY42J5m7UyEnhZOd3SwO3f/5nLDNZo9rfoVrMkdsgQKBgQDy2AlTrEnFCMABzyQ2K+35hTN8VYuudl+UJ3pbl2O2ReMJbzQuvI/xKXh9S1eeH0Y9qHusYDkHN6GELt6ljS/RwSLNVczSbs+AW/VR8fxhear6QzXimvzA81lL42IUjLVOfJT7goib234mzok7usDLMKxaXuO1V+ioeT8P9qmfaQKBgQCsNujqgmVP897JTWYzGlSdtu2KcKQ9t3iTZey2JXElE0dVXz0CptrupG8pozXViLe8IC9k7hPhW7m+FBT4y9F/EuMdoW5PJJ27MqJGoK8Lvisi9y3B/BK+S/7eY+ZJCfC0UHeLKpgcJz9C1aAXDcWGdEJkT30ITEN8Rg0cQbT10QKBgQDWomL79VbuMyGhd7eFuaYH19b9mY5vkGhBxfK7aT7UJ0jXWdZBSJ/ggsrf0uuJ8hJfBL7qR9Gfs2eqMNLQd81AEvfzjFYP16jGxoA5ASwT6zlXIHhL5Lhoway3Ci3yA7trt2jmMyUSvBjvq7RXemRUMpzi8uNHsH8OCLvYHCcnoQKBgCakF3TvFy5uaNHARSs4QD43GmuSxLd4YFyqZQeltRJ9lebo/LaIm90qFitAjMbB64ARtLCv3tQVEcM9nEsK6JHbugwe+bJWY/Hp9ZFlYoF/BQzOa3z4Q3hhcumRfs1qppC+8WPPhdvjToV/i3FAzM5TbcY2M7bV7dqHmU96ytDRAoGAT0nbD8TF73zYxIJHWXlq0x80hvqVv4FAPkrf2i2NzGcutyy/jmb3ZDF1PJh037MEdeHLKQVTL0WyhB/AZxkKotZh2pTt16cEQJ7xy+Dea9CWcPAIeEAm46q/xXzHgDVeqUVDZlxMNax63/DhfQvxh9IWEi7RM1IAh6qPYQQv5k0=',
    ],
     //印尼payok 020850
    'PAYOK_CONF_3' => [
        'doMain' => 'https://api.payok.com',
        'merchantId' => '020850',
        'publicKey' => 'MIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEAx0LmtAsR74ViBPtt3m7B+ouXXOvDTryyHoPCZCaE/5U/SRpPNE2n73LFYmX2v51wtKI+Qj9wuPW+SY33v1TKhk4MAEVcU2ybJrWhSW3TGIbMnbNBb8rpp2AMxw/N7KfuuAbBywNm6sHn2YeAWc7TYZ85aiLnLubgLmV8aAK+wKImakTmr6v3nY1+bDHoezhsrQqmfSRxTac5vntmEl9NBZma9rZxnA4KPBd+dW7bWsGHDnzqXpnlm6fTWxJ9tgS8xy/WY5ptYvnpYRoFuoTbFxeUlSel7gYnLKZblS9K/amiysaOyeobo9gjZA/v9+FvlprQDSEHvnT8OIyrOcJHawIDAQAB',
        'privateKey' => 'MIIEvQIBADANBgkqhkiG9w0BAQEFAASCBKcwggSjAgEAAoIBAQDNZCWEu+5Ht9eMjw8KZgNVn1kzoaPt98ZgIt/BzVTOIUNt3QGjWcrf0W4UB7LT8S9rBjrS08fgIVDcqX7Y2KbuixsbbTKhmoBg4SlR0diGpXfmo3DKcZ+fYv+L04/wNotQ0SGYIA5N5gcrkCkFr1yMOaK9DE+AA49/8PZd6LOqgs4PBpxJPIFE/BIXZRlUD2eeosAIBEpW1gsEpmRVTJuU54sINsK2Ma28GBfkmfkhnqbZxexFMIwrdNRLcHf/bFu7Z41x66BLt1IZHdFHvbbqKoBA/ZnVKREDvj7tOrLBqeNBq/kexbyB8nw81mvhNm+7YPRBs2LefVPB66aTlFG/AgMBAAECggEAEHZ3f2Uk20DEGTMaTIYSvFkyaC4LmrZigzAoaTtREdies/6j8/jthvUdcqOPVOefGl/8dQuemLty5Mz9KtpqvvINcSxWg5eDtMA3dKRyS5CVxLnS/5cN6VOhEg8aGXH1xruMisn++4V1i6tZbmg47dBs1+RVtvgSF3oz9SECzabbg0QPM+5OH990UIjZDKmrJYYTzHoQzAMcpTitqN+PadmPy/5oy77txuYuRLpCudmBYJzgvCTZAPrjJCZjlK4Aucxw+ghyFkP+dfhukNGSQYIZCta8rej9S3Rg996suH1AxRWKbz4JoI7mYHVGofr3auwZLMMebWtQUTZ87BJ3iQKBgQD5jEVarXpkfGsyfTVIwEIX/NoXUuYXvy8JCHQwonXyKeu0CxvUF2NFU5xWIo1S4AoMx+i/GrOUrCk54OVrVNLggHKnR1fjZozJd9A5OiAaOCf3P4lSX2OTq1r1P3qYxrBjHTo4UPZcoM4SEswsOznSxb5m0i3xIOPXayeJNeZUtQKBgQDSs5t27IjY42Ph/aUjTYqOAI+G6GSOZ1AIvjDLYX2cVlJcJtw4vL4OdBWNqm+0I9dnuMQDQO0YvgV4Do5gY17iHhkSGfAuN0dyQ0zis5jhmfd+lGXtE1hEQYwnsu8A7E6T3PwuattelVXJFKmnPpe217xgdf0TwVDigjKWlsbpIwKBgErtwU1O1XcinJVWXw9vGulU9K8YJxpuP1M5BJotzbheufUfeMWgGCCS0FhUm5aMyre3trza6Zz0bJSCYKBvobnjF4n+s/cFrbQ4k377YvQ8dFOa8kKXfbCzPOZynv8MeZ3pArgyJyb86aMnncKSLfSJh3gcF8tVEtR1yjM6yeQZAoGBAMy3Gxap7LAmBrbdFWS+gx9DJjBifMjrUhScjZYda8jJCg5k51Ts9Q/f880Hyq5QoIozN6cdnv+KKJAkPGskQV0a9yriLr0Iko9PGlWtP536VUAT+RAl2n2+3ej4bkUMU7BQZmjHA8ra91V+kPNg2lEZPPrPyIs4KVlaPMKZTjvXAoGATBnEyAWbZKmvBvt92HCRyCXlLc9kX8W7s6jOBltNY6fMDo6AhiHx3TmpRA7jYy8xuOoOflDowRgTC6Z9le+5+HjUO+PDzW0/uOUSdTMT1sFC4gfa9RQ7IfyQnX9598GFU0kZlteJuVGf/l/NAMU736T848QRZdy9fYvYX6fEY7A=',
    ],
    //印尼payok 020896
    'PAYOK_CONF_4' => [
        'doMain' => 'https://api.payok.com',
        'merchantId' => '020896',
        'publicKey' => 'MIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEAh2F+tXuByXkQy7VEN2Ei//EOq5SNUoAAGPU76bDsU99Plfudw6AJQJYr9G4tXo8FZTuRRu8HjHawUvdbBNRGEiFubX7nT8oXwnoGt4XNgJwmaqx1SyFCE0uPqwMNjPKMndhuvpuhJun95HRMS+ciTW7QgZVT0uoVMTs7hfmuCWLac3hkg/Ai9c1byeEWnC1J2TJVlRlwpfcY88HIUP9tloyJ8/TRUO/mpD1ueKoBPNVewCxm7pD4ZjyTKvPJ5rUNr5XHasJNE8XMJkFFPfoeTMy7d/zdh/MSLtshdLQYAWdM7RBHXD0rnQI42drjCwMUyd4nJgdCKlpXNPqdfSjOXwIDAQAB',
        'privateKey' => 'MIIEvQIBADANBgkqhkiG9w0BAQEFAASCBKcwggSjAgEAAoIBAQCFCTiCw3zUtt2mjjLASsx04hDJTZj78Ya6H7N5I7AXqYaDQZz3CJmVkfB+MlN6Uj8Aku9HHW8ikwr9C+uh6a9M9pU2feJI68a2cCB0uC0G2Df0HDFAUVKWWVRqbGLkarObwcCGp8mt+V40eLoskbygjWpBnd/tsZfoewgL1GhiLb7Jwkwo8+KS0Nbskh9q94tjhVZK/9x+Yb2C9WICZnxGsVpmq1q895RTxOVqw5SIyPjB5xkpCVVm2tGb8eXbAP/PAuzThd9Q7hM3lQhe3J7p9IJ0UiwERKlFkmCm/PYWtRU9FdWfmv+acGTwtpwIsxYGArJDgx0jw+1hUtlmb9mdAgMBAAECggEAIOd+cC1Mx0nxeZwLJm95sWEmuLt2Hr6GzatAlzJCACBAcl98pMceQZXGj1gAOK12ArzU7Nh1X+5RlfPoVHQ5lQYaMs+g89tJG1+RT30sOdipwjlk3x0eGay/idEEBq3zfY9HAKcoZVzbtYu0tIhZSLahdNhJBf/abDhd7ZscNEfz8RmobTSmgqu9thEgVHzyvBS1iFlxQ0YMiYnAteaPy6UarONHWKtKT7axS0gpyS1On6xGkIBreoDYcCYBsQw2qedGwpChWQ+9feHTuMiyYtlE7GyEOSPEmueZXFj6IQGoo7StWLkZs3aQgl84j0nY7FiI9G6GGSSBvCtxjW3liwKBgQC5zerF9zP6DEJ2tv3kHu7f3QJy84DNDyKESH+XwStYlkWp3F1TtsvS+uGtyCTj0sLABasfHlv2B7F9WHQC5aPLz3MpkxIgvwCWOOYUK7ogGIz7xZBIgajwb/tr1hvHWSwN5yvnlEiPFUC9gkgDJCl2sOdg8regtHuI6xCssBVWZwKBgQC3S88pSPjrGkwyPQEgntdWH4pbQDOlXSyze3HQa20ZHsb8LpQdLsv6SBty7F/1ZfGBC3hr5gFysCLQvOcklhXMds0d4jMy7m1XYaN8hF5POXSbQhXTyRv7kNi1ByvccztIxuKwFsvwGMcCODnhbkeOWgjr9JAYYdFCH+4UiPDlWwKBgHZTdJft/ePXutvvXXDRYj6eeNjLydLNOKYVpWv3UKtxx5uNAsI1P0h1DROmyhdsOSogcgG3S8k6zQWONxNBOzaoPibTyk+gU7dXNO7Tigy2ldIg1unV6Mh2CB98kuQ5HZ0dAxDPlgXI+xm0xjd56A32SuOqrtZhGerwCAZxfKUxAoGAKCEEvbkoJfCf9e+9K3MbGdPV6pxnsjBv9Ot1w3eBbxp53gQkkS8JoUXgHIz7hTJIaUQlnRnB/2XoeWKiCDSDmTv5NC2tn9zrO1I5BK3GJ/ogOU2CkddZtP3FM/zZ8W2Y8Rn5zytugqYqC6ZbpasLJ3M2uNHWKkBgG+X5ra09cDkCgYEAonij4jSinTF9qe718mnsq+7izditZKLkTFett9V0mDdETR1eFqN6IUl9PrBwUNTjjz5cNXQ5smljf33O/rnd82nVJYmsx6NSIz/nOPq2tS9TgHAsazysCE/iQtuC8HM/K/0OIOrG5JrwKtEDxAwzFmorpHdRcXSrIOT/BuNLx9k='
    ],
    //印尼payok 021194
    'PAYOK_CONF_5' => [
        'doMain' => 'https://api.payok.com',
        'merchantId' => '021194',
        'publicKey' => 'MIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEAgD/Ki8dXUB8JLS7/834vsTvRj4cEIhsnTB3MfnFtow5x6sdGYh7Trpw1WQRygRNSNsVxkuWOAaxVzQ5cl/Xy/1qbABpjdFwkhWCsT55C8AkhK/WCaqdptaTbXqRAmGScjc0Au2JGBlEilFqkU3K/mTAaCxnznLrL00DAazhO7+X1r6mXYNAFZH/YF+rR6B7ger/+NmXl2OJCmYNDrTwAlO5rHzqB2oLG0JO9taf/bjrUIxhUk7ySfJKs3EyHeiGxgoEGuVrN3AADBiCy65myvj+DIQXfU1WIkU2N01DxpCQ0a7KdlqVAirE/de3foCcdTyBcP9kcYhMWAvjAi1sFbQIDAQAB',
        'privateKey' => 'MIIEvwIBADANBgkqhkiG9w0BAQEFAASCBKkwggSlAgEAAoIBAQDcOwjrLNBGpB1et9RHiSxsgsc+wrfyf7HomvEAhP0vuZjJEj+t+/RneOjSs6sW7aNuVovN1VVMIS2jQXGEZzu6w2ihVtglP3nFYDGCmu9SyLCfwFA3S+LyUJ9fsQ1qx3+g0b3d6qzYWgVGnvH4Fv/UxnjkGhNtBtdUoW9hJf2+Nuc+l3gyqN8C65C79E2H5T/NDAxlWFQxmirv1ZMEt1NZIdG7y0Zd5xGvwnqaSmGCTTfvixZzug4RLHr+erFDupGxt86psO7Lg/zOtWCb3VDzv7beRjvJyQx8lZKqtkSz9l+OUpBJmugcx8uhxaMOnp3NYOb4xpnMNH4AI/eo/ePPAgMBAAECggEAEF+hP57i00WzW03uje0AbQbiGmPuuixNRV5zqZa5njk9x0FAk8ZmOuUt5jBueXNskbEEjuacA196HaepcW8dbTrHBivHQSmxe3+13qB3R5/dJdtt+1Z8hoiA+OPYfAZeEk5Vv/CJLkKvHruFgOzw01h4N3lK1XHLQ6MG/WGONnyKGaaqogh3V0GhmoTy+unR0qoji2lixgYkPlQAEQUMc60khMxqRfvoS7Gcn3rkKWXLA1OeFWdNvba+mVhwnT5zZbNDQVuGsmbZk1DqvJQlExhkZYlUMjl3EaSeKVWvJhHRkKOBbzCH5oLTdTzO+lKzJNwai7aG6JGNwJ2enezfjQKBgQD/NcRTwd9ZzEhAWi7kBUK2Sq4dSRFU+CtWKUP5EOzu8m8ZvMuTOuX+JUJxkRpuDf5nhTJ4CSSF/q8SJRLWOVGzZkh8x3a6K49a9hHviu8638z+0skqxKOMTN9mHjanA1P0zwkNLsWF1/OvIY6r7gzTWjwlpZIh01hvfWft8O8IvQKBgQDc6Yyyp70TN3rkWi0m5agYDOqSbXsvfKLArkhXGCsX1sKuOg6XS8P78gIiJSNBVFBDf1rvbnpcYm4NMFthKj7Nhsve+RE/emMf4WL/tjnyE1h9JswgaVTS2h1R4X1bjiuJ59FgSXbi6QeaGAOs2vijnqjlzBhafgYLnLIl9O0FewKBgQC3eeQngx4b5O2ctjk33UBU5eO/UiSPvcsKKqifizeLoeeVzVFeC94FlKvsEbG6pXzc17ms6oXDf5JFrTmZoaPHIiXC73O/7Eknz/idCnlrDjLGkKvnf29FEo8ZT2djMtVNDvsm6xU+YD7lDW8Q1BeMazcKqbohb1wI61OokKqI0QKBgQDE0H69nJvjRwaB86VOhkUgSEGke03InO4TZDKnBa0+6+M+fhMJ0EKncJFeAmBKj+eCezB1KKRzMm6B6ZdAFfcl/PYdjSFEwLEXciJVV/CAL6QivDIYnj8oK5L7pD2fGCbKEnKDqm/08VAIhWSg1+W1QGGReigoVybjqZM+JdwViQKBgQCewDGTSSM9C0awvi9M4Jq9/RODRyrAA4A8BOLE7yKJ85sjtVHnmJB1sv2TSiqJV1VBkhmCZnfb3Wcn7cpvKfgg2ilMAmDM30ZgJk9cNF84Okny6Wugq3trQNsKzjoKE93OCOY8IEBo37m/EN3nNXFf6Hgl9ja1kQBxApX3cTazFA=='
    ],
    'PARHERE_CONF' => [
        'doMain' => 'https://api.payhere.id',
        'webHook' => '2d6fa945d0028e1bbd85e770d76a4734',
        'aiyKey' => 'eyJ0eXAiOiJKV1QiLCJhbGciOiJSUzI1NiJ9.eyJhdWQiOiI5NjJiMzgwMC1mNjU4LTRhOTQtOTQzZi02ZjFiMDlmNDVkN2YiLCJqdGkiOiI0NDM2ZGJhMDdhNWQxZTRkZWQ5MzUzOWY2NTgxMWY5NTIzYTJkMGFlMjY0Yjc2MTBkMzdlNGQ1Y2IyNTM3NmNjYWFmOGQ3Y2ZkNmVjYTkzYyIsImlhdCI6MTc0MDM4MDA0NS42MTc0MDksIm5iZiI6MTc0MDM4MDA0NS42MTc0MTEsImV4cCI6NDg5NjA1MzY0NS42MTM1NCwic3ViIjoiMTE3MiIsInNjb3BlcyI6W119.Daqp9D51IJvI4IrrIym4uj6oPSna44bBjqryBvYwyQFCBxxTIDTLc65fpAj7zn8f0D79IcrNjdFVD5p31AWNEJu7XTVIB8JXnFSBdMKekXPbjARTERuiv6zXls2gvVSExDjYxIVcfPu40eivnxMfX6P3VMxwWTJeikbD--0NGKIxGUQWwQnvFH2LV_Dzf4ZMh2idjWSooRKZHd61ivrra8RjRA6URrQ5HeICmF-JB85SddZgRh9SVxpaVta4nW5J1BfcV1vzoZiFBZionQqaBhAsI91tZPUOxtGzaCLyWxWdmOwRwjoLQ0tBI4Ne0Buacgx5EcKw0S8Wp2Zh4UeibJKA0M3luWcVDbzmEj1tLzQurl5AJZS-iVejzwU7tn9pAC3Rr0gpoSgv7iy4HSgKvYiDLAE266N_darz3GMKdjfSA3gaNG9Ijjo_oIQK1gh6_fnZU-ukhkjHx4OiK5zlZySGUwc7vmB1zsV3UHVx_jxUadkr2TCG6uZyMVhjWPeq2OM4pxI6qn_elTjnwPqP_3GRgwgtywU4di8vl_sUNGqMypvvEJGe4XdhiPIQMnydV69odnN95_IXTbCx0Fsy6VnvxvLFmbp08U-HWqTFVydzF2xDmiAf9ieECZm4n4VadDdEPexYpAAiz6JwqJjsZ98kAe7Ehi2X9egd3UyWeNM',
    ],
    'HILOGATE_CONF' => [
        'doMain' => 'https://app.hilogate.com',
        'merchantId' => '1867b13a-e0b5-479b-913d-6c67c7b06731',
        'secretKey' => '8de9ss2y681m203zx9p149x1m',
    ],
    // SSO配置
    'SSO_CONF' => [
        'host' => 'https://sso.transafe.co',
        'clientId' => 'idn',
        'publicKey' => '-----BEGIN PUBLIC KEY-----
MIICIjANBgkqhkiG9w0BAQEFAAOCAg8AMIICCgKCAgEA85OYntNWT2b+T8uum7H/
9KCy6cXYtmHw9PI4QVBeYVy9xPA6NDKJRGACd8SFZtF2bt74PqGhIb0YnUS9eSGS
lMZcFZ1bOPqYSnO1JHx1qtUDgD6NJQJ5ontDZZlonr8lp0EdroxE/ANZuXIfkvA0
4EBER6tB8QwLvpzAvLQqHGNEkRPtXzsuwK46vSnuFwObY6P+AmDglQoecv2Dt/WO
Dvd0dx9jISZH2cs0iV24c0uVfxU3uX+KmkvzZ02WdTBZUc+G6L62TRx7Zr3aL0VG
fumvzmbUbhSxpDYer1rU4JPPxljxFBHjahgXMN5cR1uivn3U9TfYq7HunyLF9Mc8
RaPPGYfHgISOnB0F4TuKKCFvk2dWaunBrsSB0BvrROIlT11oiC4vaYN1yk9GVC3V
0IqJRDQrNcGdx3tMuNe/+pql5gOGz/tiJYJjsKTgMp56WhOBBuVx9WdkbCKGU5Bu
ww9lg1/+2UjSjod/hEMHfV1z35oueI8K9Dg+bUlm97ANkRGJySH8iI1BzpBdUsC9
HA81yy4Xvsam8d0aThaW2zX3w/dRplbz6aMxqMewJTsphGrHE4ouNLwlmpKYNzeL
cg4qJ09dZtQJxXt1tcZOOFEsf/kx9CLMwpTicyB1v4vXFHeEvF1fHuT7FKfDB57r
1xtxMawagZqPeXg+my6GmskCAwEAAQ==
-----END PUBLIC KEY-----
',
    ],

    // 自动调整策略配置
    'AutoAdjustStrConf' => [
        'invalid_time' => 60, // 无效时间(去头时间)
        'period' => 600, // 时间段 5分钟
        'step' => 10, // 每次调整增加10个步子,减小10个步子/通道-1
        'min_order_num' => 8, // 通道最小订单数
        'lower_limit' => 5, // 最低限制5
        'two_channel_rate' => 0.1, // 两个通道时低通过率订单占比
        'more_channel_rate' => 0.2, // 三个+通道时低通过率订单占比
    ],
    'AutoAdjustStrNewConf' => [
            'redis_prefix' => 'auto_adjust_strategy:', // 存储动态策略权重
            'invalid_time' => 60, // 无效时间(去头时间)
            'period' => 60*4, // 监测时间段
            'min_order_num' => 8, // 通道最小订单数
            'lower_limit' => 5 // 最低限制5
    ],
    //群通知id
    'TELEGRAM_NOTICE_ID' => [
        'alarm' => -1002351667997,
        'finance' => -1002296583775,
        'operate' => -1002296583775,
        'review' => 0,
        'source' => -1002171473062,
        'risk' => -4928076353,
    ],
    'SERVICE_IP' => '16.78.48.121',
    'MERCHANT_BACKEND' => 'https://mch-idn.transafe.co',
    'SOURCE_NOTICE_FILTER' => [
        'members' => '@Estrela_101,@XXXMIGO_eth2,@hongyanng,@nickjun666,@firaobin,@Jiang2Wilson',
        'match' => [
            'upstream',
            'INVALID_BANK_CHANNEL'
        ],
    ],
    'CREGIS_CONF' => [
      'doMain' => 'https://t-dfezfyfw.cregis.io',
      'pid' => 1429903523594240,
      'apiKey' => 'e394d2c569a9441d834a617a9cf6a643',
    ],
    'XENDIT_CONF' => [
        'doMain' => 'https://api.xendit.co',
        'apiKey' => 'xnd_production_T6hcTWtUWuyrqFN2fho0iO7TcoL5OFsDuiG1OFDRViDu2to9cS1AxVxdmo5s1',
        'webhook' => 'H61Wo9QekeNjSrwK41loaNCVHWTnW58qq5eggtc6GFp7OdeM',
        'userId' => '683ff821f4c35e55cd471c74',
        'bpAccount' => '68463e1fe8909665e69d0618',
    ],
    'PEAR_NEW_CONF' => [
            'doMain' => 'https://partner-open.pearpayment.com',
            'merchantId' => 110075,
            'pearPublicKey' => 'MIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEAtlGkqoYQf9lty7FukFNQ8zv0oJ7PSV3Xsv//OZsNo7mB61l/im02OC4xmOSjBDpmwZkxNKiHwupInbZS2OdhZeGJgmEKvqsB4t3DQVaU0Q8cWvd7htq58ZJVrFQ0BHpIkDGrqMAwsiPMWZJfKr7AlFI60DZ7rCX5ORViTSKnhJN3nsPI4lQmW7/F+pPM9fN6eeHX+7Rerb+n0L/1Zzr2ijnwYP/ofOtK0Qs+v1cncqRBQWnuDpnP51Qy4HUCmfhF0q1xtNBRf4KLo/hcomxoOuT1VfzeXgQJrLkRns9UczvtBRrueK8sXEeef7A+LG4C3ZC6ViPyswXBMECdpmUqYwIDAQAB',
            'payinId' => 1100080,
            'payoutId' => 1100079,
            'currency' => 'IDR',
            'privateKey' => 'MIIEvQIBADANBgkqhkiG9w0BAQEFAASCBKcwggSjAgEAAoIBAQCbQ2yxOtoObrzXqmvLcx2wRQf7dgqPOps6AL5M02tHe0ftZ8c5NVl5FsJLeAPhDQwvnwaLTPx8cN1bzQ0OkhqaWpUcJSdmIeaZePL2HM/QaRQNwyLlVZfdiHikrc6Cjs29LYqlrv28mpNsUmuhYmhp/INXm3caAOIGuH7zZMcMADqEWTHggu7DJ4gZiYfVo7ITNpY1GnCbUbRqo9ELbueAu5m/cbGW+jp2D0EZ/fEC/MolEw8db0k2PyMH7t+7/2MvCaJNEDdRUun8q+wmaHKjJoE5VOXJYJTwKJ3XuifueGTSUiBGoD80B6uSzdsnr26wcXc0EqTOrqaqagg3lD5pAgMBAAECggEAKcomjbdY7KyKoIOqutpTodeas+iMJAvyrtR3ZAc9p0I71F7r5O6ClBB3oEd/x8myv3iOktzYUogwVF6nBoZ1qZj67FXlulwijKlcv7h2iNJXhvLASDjXBNYQHsb3P/W+043X9QtaGTMDvhKbDJeHogtIsMJT9shJDeUHqmw0FPrpa/t1BAbPIX7/4Bb+UEuCbREJZ9YBkT7ZuZx0gs5Z6FHhNXsRN8Va/wYPAoFi4uxRp2hoOJMpHmKYfEd3TH3A3/bkQnUGfzzIZ5p0cR7ImQfQbIZEECLESSLxFskP+hfU/qU+aTnt6IAUj0ZSyh8QybOVFJPO8D3MJGYbf1BUXwKBgQDLymDxVc+Oq2rhgUoyKme+B2S+zU6JGTuQn2VzcLGy7y1nPbuUUE274UpKi7SJBkMo/76tDJ/euM+CuzvCX1dTC0voAHusuR6dsy1aKHGnb/xnYxwLyD56q4Gju7xalAmJwXjVc6WmYxIA8xTXRiBhEApjtsoRwTGAPX5JGMSLiwKBgQDDCmMrJml1fqrq+mZiCXRTTOVgTNF+Qc9j00f4rZYIL4ndYiYsNlEUyLIYi0beNkBO01EBx7t4849/kyrstyLlD+1bEzbEXdRUWcPw8uFTdsncActULrwzmDT149p3fEtbHt1iVAPnriaRGQ1XYbs/C9ugADSxCRwchIAtt4hsWwKBgQCp8W6+UozvsMtEmojBJNO2iHvfEV64va4KgKIdjpDhYss+GSDgIcdxMgK9/5rh2bMP8ZWUwb5gAUYrAvBmuxMbUYRPSHfaJdX+NHlRggClXKHjpaaxvJ89tOA7JkeAUYtSsWCOwA4Xnu5YlF2A2B4QU0wWs0v3WmBpTN6PHnRo2QKBgB5nOB451qaiIDKQ5fTSVHfHvNnOH7n2uEVvYgC5znFoN61y51BtByaeQmThESMCgfPHrREB+Y9ZKD1Sy5Yq1h2u5ekUjaz+k2Kyu4CL2+QO2FibTv7Iaj4AtADAjAWkMnr5zLjPL+ylkQ19Qj8k1PN2/b1rSstuCBvJ69E0kueRAoGASlFsqc4FE3Rs9DAf5cHhD54b2KR2FvZiVsVNZe8ss4EaRkwVZPqUbtXMAv4U4ySafi4rV8tQigFX00L7dKnGHUMTYaXNIj9gdCCZacoKglVEJfcqBSnNXVHNBUC7jbkQ8jGMhBHUFzLCx0QORuxuSmW7t7Y5R0/VCby/LFfXW4A=',
            'publicKey' => 'MIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEAm0NssTraDm6816pry3MdsEUH+3YKjzqbOgC+TNNrR3tH7WfHOTVZeRbCS3gD4Q0ML58Gi0z8fHDdW80NDpIamlqVHCUnZiHmmXjy9hzP0GkUDcMi5VWX3Yh4pK3Ogo7NvS2Kpa79vJqTbFJroWJoafyDV5t3GgDiBrh+82THDAA6hFkx4ILuwyeIGYmH1aOyEzaWNRpwm1G0aqPRC27ngLuZv3Gxlvo6dg9BGf3xAvzKJRMPHW9JNj8jB+7fu/9jLwmiTRA3UVLp/KvsJmhyoyaBOVTlyWCU8Cid17on7nhk0lIgRqA/NAerks3bJ69usHF3NBKkzq6mqmoIN5Q+aQIDAQAB',
    ],
    'GIDI_CONF' => [
                    'doMain' => 'https://openapi.gidi.co.id/',
                            'merchantId' => 1989,
                                    'subMerchantId' => 863598,
                                            'credentialKey' => 'LS3sk7MUTB89Bpf4eD205dNgaqZcra',
                                                ],
    //"GEETEST" => [
    //    "captcha_id" => "c6b11ed08abbd973ba297174d55523e4",
    //    "captcha_key" => "40726612f55e340b0903bc9e3cc098ef"
    //],
    'TRANSAFE_UPSTREAM_CONF' => [
        'doMain' => 'https://up-api.upstreamtrading.org/',
        'mchId' => '2695814501', //商户号
        'appId' => 'zmpnDlPTaS69IYCJKa',
        'txChannel' => 'TX_BAR_001',
        'pubKey' => 'MIICIjANBgkqhkiG9w0BAQEFAAOCAg8AMIICCgKCAgEAkPdy1vAVo/GOSMtxOnHGuikuu93mfqSjJZUAInhlztDC0wVkPw4PndeakvIAmwR9CIDBTT11FnPPUfVXMN0icPfFPK7Ses5jDVJxbl62zfOjAvyjes4w/brTrGNy2Lw3JQG41lboG7lNaxZuPJ5/R34xe7p5TMW3EDsDJnVxroco9n6faiOP10JjAENYPzeKcKY8xrPDJ1h/VdNQWglqfb+O79NvLLNQY5RgooXFR5uBRK6+gJMRcaWWAxFy6VibWEFCqt2camDGrsS7WKjBycpRhWBiADznXul6Htdjeli5DJtiUIjXSW46su7e7zzr4whEL5dN6+/OtPd8r//c3zwWpZXQlecHIll2JuXQaK3OxaQO+7Ca/DPm+RFf56OGY0D7VkDpLGER6r5PRfeKr4R6NIMYt8VUrvgWy0ejU/z+jvq4Gh7TrGpPv6JPSniALQtc2cPWZwHDYNwXuUfAkbQDTf34+aLhGbrB0N/Nazw8Tm2AdWeplMQzywJuog3n0gpQEy+TzgV6gzSDSldETG958EsC52ax/ftlvSq8/lSZ3AByUz+K3ytZHi2fiOJ7d9GtuU0ChfZ8RsynlqNqRCXfmYr+OO8xe6oNgFhC3XGiOb7AmPfeSmIfBKFw+qYuQYCEujmEuwSBTpFDgnurtndsgfM43vnUkq+LrU1ERI0CAwEAAQ==',
        'priKey' => 'MIIEvAIBADANBgkqhkiG9w0BAQEFAASCBKYwggSiAgEAAoIBAQCnnJkPAxhQRoq/jJ4xlkRz4+mtbyt7LGb5GTG87+nyPJs677bDcZuCPUOmau7imR1Al/MMkmGZIYpD4jJcA2Wbg2GYfER6ebctaVNIq1LiLxmzogPRHcAEtjZtwKS07QkVoAsHKxR7RcqRNChsoKYkQzR3TqGqxGze+cUQc5g/j5IBo1mrfb6UYRci/1wy7LDybITmMeksW8mu22AP8B2ATClpsM8oU+mdUI8Jr6LDWEgvaJUqRJgS+NkPEFhsxBu5BjQWvaPc8UyM1EJzpiDv42QFwnrGI6n8yxJg+I1UfaD5OEdkxtHqrxMBgG7AJn13JQcbCxB5LQLCiHy6cfsBAgMBAAECggEABHPfiQuPAMru8qm8phqU1PNQCOB0KkCCt8lYjeldsKa1hPpLQ6Pn+qy/+FLM584jfczLkyDsYNIIR0diCRm6AEicNh3O/+Xt3NH4eWy7tfCEYUZDjbGZoUZp6b59YaUOYbmvsVAOqjuvZu4YyNH3t+zlHupC1zOCpOXDu20mtUGDEDwDYxpNx/8rh+p/rRK5O3pOSQbotHvrLCqR7CYRIYh8HB/AD2I+pM00UwUsSox70lIrzm112vLTmV+3iG59D9te5gRBkxUWaReJ6VS/A6155LDBiHxiAN1dN80dsd5WISd3UKzBIB79WLOQHAD+y6PTNnqHzxsw7646Y7YocQKBgQDm+0NSkb1V2tNYYwR+yYQNL1wzWF118/DiJHuV5NpQs2Uy/xS1rCOxHTBrhyCjh5PQSCrEVx9a+S+eGITGMtRizbsZWM6PJ3oFa+WZTNTlb4F+M2b14oSoc78OxYCgFJJuvSHAy3HMI/RwcWfRBxSwdJR+mf2FKpgDuSEWXYogZQKBgQC5xDHphzI8kWsc2BcoLAiTjsjkGxvOCNTTPHrVFzxuT63Q1Mtrg8oraC4W1NQ1PR+6GdMxDJmB2zFnC9He9dpUJQRpyyUa+1xL9GLSyJ0g+LzVLnUSTtO43Df3rC6gfv7AyxJ8lFKNXgSs5reYo+FOdea4sHAqwPsJft3CID5wbQKBgBNZZRBbqRKyHBZBZTUByJAaMY0Tj/C7mKg5CilKXId6H7Yf7Coz22GQ4md/kFpilx1RjlOYQMYsLbL+ttCrnWMRfOTorZUMZ4pguYEYEJWPu7dIsw1SBm7eE1k3bkj6sDGaomM2J7hEIsvwlBPMlg0aFv5sA/LN2KInNgBboaCJAoGABt45FjA4bELYGfXnTUXrf0EdLknOSlzLOZAX3n8AbfemLn1fk/cIZ3hvk8qEmf9Lh/7ibwLPPhzTg8LNHJgsXUYNFrg7A/ddHzXG3ZIrNQfdO2h/TZD6hPAnZZHJG4f2dTxMz6xQLQfX1milSxBsCRGU2Sk0zG/cGCrHmiDFDjUCgYAKe7PsYZfytYACG/6L3ONboVE3C1l1fSrLiof39OZUP3V5FeMyB+YMg/idgGDBjEks9+VLqjn/nIXZNA4Nn4hAu9ssH4HPA/yMDeDJgN0yFqn2QP/DUEDPGCYiSAfBb/9CFT1bYx8xqZKcGhoofXHl8i7mDKmElTtoVd0mGh/REA==',
    ],
    'PAKAILINK_CONF' => [
        'doMain' => 'https://api.pakailink.id',
        'partnerId' => 'PTR00000SI',
        'clientId' => "040570e437a711f089c5fa163e119ed5",
        'clientSecret' => 'fcc7dba841d9b693279e3023c3a975ef',
        'partnerReferenceNo' => '0523092018296420',
        'privateKey' => "MIIEvgIBADANBgkqhkiG9w0BAQEFAASCBKgwggSkAgEAAoIBAQCz0MnfIJA/x0tpdgH7va/tKM9Jbe6uWm/WiZ9xf0WC0hptvktENtz1nwcu9K8b9duWmMBoc7WxF+0hJmzcVl/HazNuXcBdbpLt4Ncxfp6vnqEz8iQFbK1h3cFQXjcl9jzQyPa0S2W1tWKV4aAM2UNiLPxN/SHBxa9U/tMXAtVj2s3qt3GPOCr+jMJ4jl5N9ywb9ElMs9QcbevwC76rV5hOUgSGfwpY2Jiwy6uCteCMsQM9B1Ri0We5PisKCtzo69n/HZfNME0oCHZ0yWD/KjS0NllVeWLQmyKZ5nsNoQOOIIEULtZ3WNeWPMWsolaiLbi50lOxgKLzOTvgSaWrKCBtAgMBAAECggEAAm0IhC+dcpbUOsss8gIC9m6iA/TCjxdI7KU1AaQnbRaQ5QvNBScTqmanrfz+wyBOgu9y98Bz4jyXO5FtT42vbh0molBhJiw15EAFIeBPm2vxndCgUXMVZb1xpw1rrgyZO8cyTjK5imQ058kVo9wR2ihkNlh6FPH/UGS9tqZC+GgMq+mJS1yiVrd7rbK9PqlCPC3hlPFfp2rQ0Z4ZJ/6PfsoYDZRXcRwraW6+pXt5ijpXEt9avE5/UNcnRT4fyVf7+6iCsyfDIF6UcupLTWL7Vdqn4S3CoFoNUbbqMLVKzdMlA3rv+lIR01doDmYYLtOSgnArOMMMzVWP85uX0WuDgQKBgQDaEnb6q59PYJ20AW2CGn12ff99uCfcDZPupqgg8rltOXzkytcfwtnJMKUnDtBUACj3AuyKddFz01CT/cY917sprw1+kLcq+QjIRWF+WbH6JDrX8/XMJ35Z5Z2YW//7Mi5bi34EV4gSBlFOt6B0sIe4oFPbDrZB0Gt1/OsvedrlrQKBgQDTFvkhQ3R2d222JubfXdfvl0NgpZgZ/pkQgxRZHz6fqfeTi91IHuomhoXyEt3F9q6Qxh39nCa3JGF4PgCq/utMSMctEd+xd4Q+tuM2wMwItn5bc3kgA5b3xgYHn2SpETYvxsM3945UIyGKmwOMQ3cw4jyzJIV/w5XC2NYP+1n9wQKBgBOWuwdTaVEZDbGAu1SHiqOdN9kUNMhok9RJNisXgp6UHmry6ZYZy7Rt4Tf79azGAugFZDgf0zvDTKaukiM2AMMCzYSD/WAn1KkgylwuNHWS0ZJagMbg+VGb9acdBIaNAGsKwbwkHL35wU3/4rL4tIhaJo4z6R1KWozTtlCico5VAoGBAKgOEim5Wm82hdIPBp+uRswo0SuQqpeHarUKppiNl33mA4UkRPe2JRSm5NzkyEtjKXd5Q0c1ml0UScVBF6cLbKk/B9OJ912CmXaUhDCDLe2B3PdR54zlTrvUm9hVvf4cBdfjlmhoXpf9oCaJYzm4PJxegZTd7qrZO9H0b/gpVGwBAoGBAKcTzBdQkLcaAs+ebCcf/NqOpURKUqBUzhwstkVTCcNb2O4+tRtqzW+Yfvg/wVBFhj2c9YEJAhciFwAFSceAWiQvd5XHMF5L/BUD2cnXZr1I8gDZm7e0GqRduhKcEG3SNIs0K86R+AuEdGmCyD4zkzZYDLusG+z3A64ask0J/16n",
       'publicKey' => "MIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEAs9DJ3yCQP8dLaXYB+72v7SjPSW3urlpv1omfcX9FgtIabb5LRDbc9Z8HLvSvG/XblpjAaHO1sRftISZs3FZfx2szbl3AXW6S7eDXMX6er56hM/IkBWytYd3BUF43JfY80Mj2tEtltbVileGgDNlDYiz8Tf0hwcWvVP7TFwLVY9rN6rdxjzgq/ozCeI5eTfcsG/RJTLPUHG3r8Au+q1eYTlIEhn8KWNiYsMurgrXgjLEDPQdUYtFnuT4rCgrc6OvZ/x2XzTBNKAh2dMlg/yo0tDZZVXli0JsimeZ7DaEDjiCBFC7Wd1jXljzFrKJWoi24udJTsYCi8zk74EmlqyggbQIDAQAB",
       'merchantId' => '1031331611',
       'terminalId' => '0523092018296420',
       'storeId' => 'TRANSAFE'
    ],
        // 印尼pakailink2
    
 'PAKAILINK_CONF2' => [
            'doMain' => 'https://api.pakailink.id',
               'partnerId' => 'PTR00000U0',
               'clientId' => "Tf7nAF5g6dWb4593cg0x1tIQs57gPk09",
            'clientSecret' => 'Cd1fe45F8WcKiXa7f53G7eyD5uMfXr7R',
            'partnerReferenceNo' => '0716021147895756',
            'publicKey' => 'MIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEApnGrAzWtJSKS5rossA7JszppwbknOqVZTv0AWZE7WWCCOXOj4bfp6AftC9+R3bEYdLwNyYj8VW47cIRt1wEMcNbt3rhzmHTSSNbHeaaYquu758DYZq9Gu380OXTcLbanAE5QslIqplTLQ5i/BBQ//lSiZxd00d08zBAQOHWpqmdKK8W8hNsCUXR1rmbpDezH9DT+6YRYk90R6CMqK/pXv1XsQ5Y37yrpQToJIiTH6VLdPJ7OIJVo20DB81MHaYtgy2z4xyM7yqHOai5MMLyr9Q4zhncVniT+TQK3GAkpbRU3aUofckfD8mxRMKMRyF054o5z9cR+Cvi5kZrsD/5E+QIDAQAB',
            'privateKey' => 'MIIEvQIBADANBgkqhkiG9w0BAQEFAASCBKcwggSjAgEAAoIBAQCsJAEu6mwujY3Q4Mc6vNlU2ycckNRKrENhXL+M1Oqr2dYZ3OLa1dpVSoCe5TDRwPCVF7bz/K1OY1L4B2W39sr3VNtnRu2h29280CgudcYT9glu8Tup4+Ev5rUlJot1WdA5Um7tUtTiz/GsF+j94xFGiF6ySVnn4l1Nv7keyZXJknb6SURmGOwVOWrrPSFZhxdBrOLgrYRne2Q3wK6fesdJbLDQis+3+9eaj0FWNv/RPb+2oE7SnXQzpxn7zpHGb7+jUbXDhLJF/BB/kyQjMh0UL4dToB2BBKgFBpYpaFWVKYp8T5E7+j4avFSjER2oQY7QThnqH7on4AtQPVWzaENVAgMBAAECggEABcmqHoU0QPZyc7jzCecKmZ9Kt9uov5/+Hfpr2FTaVQ/cn8qQ3hYQHDiVTVYiFzn2eNzu81dmFqfkgZRpbdPCLTaMaVBXSVS1cPb7f/4ungVxhynSGWIjz8/DPI4UyhDZ4H9h842qS+brREavNqTHJ9+K5lqw/Co+XG+TCoz9pR/e4iY70OA5V+Bjg92ooy7zTStth6Hs6Yxgy6n4/29XQTu0Fw/IbpKvVMJ5L/bio8BGptYO238UDlZDLKWBALlGFOi/rgv0phsGkP8eTu7jLbuisU7cRLOraMb2iK+MwxFFfQujfHbXkSjYd5UNKx9cGFocBXP/WHw6/w37GevIQKBgQDXhwBN0WWVzaYyHLR2MoKf2kUL1u8nyWVzu5C2sUHEn8NUvHWBoIXxEFLwfdnUiudDqd0vj45YWBHRrJliF+gCciXZC+jFVY8A4QCeLmZpBfcaPHFyy9W++YqU14EbcCu2eo9rTOwsGafpNHsjVrcKlaGgLG2+9LRKCWQ0+GS5cQKBgQDMd0itLAfWq+goL3uiQ2FeX9s3FVVbYHcLzTPaHRXw+TWqO5O1YKl83KHUrLWp3H5fg9n4T2ghs072Zeerkz0U8H2sOrIcXYwshq/yYjZSlnE1L1+rbWn1QAWexZs1DpKUX3nNCtT9e/AnhlHjblSnkAZcaBm4X9mF6v4VVKXWJQKBgQCS4IeOgKMQAcO+5tz8p9NpCKCBPwpgPNmMk0g9mHLPgmjlOEGEA1cEPzGmfr2SIM8Vx47auKQzBGGwWEV3Gf+cmxm73mfVA0efO7bmFYzpCY2qLYLKzqptqTWN1YdAoaLIiqFuaE+ShjFttbwtCw1Wgz5QH7byqWSsB9ZoWtaZoQKBgFRtKLhAxxfQMfNt79oHgowKfqUXDQDHK0DXQYLdobK35H3fTdWGDVX+cGA11GlIH3JnKjjK6Q+JT6CUYX3KNV2RFANq1SK7SecU0k/+V7nwXtx8LD/H1QmsnuV5aOYWl1Xmuo982oe0hmx7nRKQ+ymZYdcEMSKdiV8vsiyyoCt1AoGAb0AMFBvXImYWhRVHYgCEUzpXQW1f8KmKBdy9OKTdp78r/PPTwTCaVorxC54zvx4kB/mPysiz5lXRmUmAy/SGpSrnWgHgLneNJuP/GgwTcqPgUf+vOBOqqpReeQb28+4HPOEelkdX29y8uOiWhQSM17CzYkvpPMQKi7yadRsynAo=',
            'merchantId' => '1031331617',
            'terminalId' => '0716021147895756',
            'storeId' => 'BINATEKI'
    ],      

    'DEWIPAY_CONF' => [
            'doMain' => 'https://api.dewipay.id',
            'secret' => '390bYbRJ4tq3GLPpkRzZedrffu8n3u',
            'token' => 'eyJ0eXAiOiJKV1QiLCJhbGciOiJSUzI1NiJ9.eyJhdWQiOiI5ZWJjMzdmNi01NDgyLTQ2NmUtYjM1My04NTNkMjM3Y2JkMGQiLCJqdGkiOiJhMGViNzM0YjJlNTUxODlmNzU5YTVjZjA5MWY0YTg1ZjdkMTg1NGViMDFkNTc0NTMzY2IyZTRjODUzYTY0YzFiMWRlYjg2NTYzMzRlMDAxOSIsImlhdCI6MTc1NDA0ODc1NC4zODI4NTEsIm5iZiI6MTc1NDA0ODc1NC4zODI4NTMsImV4cCI6NDkwOTcyMjM1NC4zODA0NjgsInN1YiI6IjEyNyIsInNjb3BlcyI6W119.PpHxSn2BQfg-vE1z8BZNdFQXwIQ0UKOJb3tZ7y39xNELdapvApXkN3W9kpV6ZbhrL7kC_FvDo3gf0cywX3bH8Pq-NLtmqFYn1XzI7YlkPFSzGG0qIOlhR3-BmWTIdAF3RiOVvnYCPUgnAi-1WwEmL_zTzVBfu18ZucsPvek6BAGQ3KZUx44mZfrPZiO06YjmYBtM5qtfpvrY3TYN2zoeiQ6NuI6Kv_ezj5WT1yipLWMlOKBR-U4YjGcrfVZJWySM-st7_93mElmM1LEsPeUGcmlmtZ1_hhIcHtY7QCX_kKMnrAF1OCeFrD5ZAvkOShEuViDuMkYKIH3eAr27GqNhvIZeaHn-JT8vGLEjJ5cPFhFFLuQ4CWp83o89Ch_5IRKNjOJ46rfjf8wThgZ5qKi5-Iluz5X98QFYakCX7RktlhvGIGDs1Xen0s3ZpcByOKfbN6WI-d4u1O8PiV2nZ9fhShMZ1NEYYL_S70KZVWz-pDB59yODtlMgQaU4UaTI_PdTXp9yvB62f2D4QJLtSjgyniBS_iZxYy5btyj9OVYehzVsFiFVCLc-FbWBceYEM2_4nC8YRnXBj4U5swIOT7hVYDvDoy73MrGSECRrKzdJTUfLH1g_R6y6eZuUvcuRpZYSNEGzPaFysVvXdBUylEBv7wrxETPi6aRC4kq-pqOJeWg',
    ],
    'KILIPAY_CONF' => [
            'doMain' => 'https://prod.kilipayment.com',
            'merchantNo' => '6383671000',
            'apiSecret' => '8817fa8944d1487a983f4b9adbbc09e9',
            'configKey' => 'KILIPAY_CONF',
    ],
    'SUMIPAY_CONF' => [
                    'name' => '印尼-Sumipay',
                            'doMain' => 'https://api.sunmipay.net',
                                    'merchantId' => '20251103095616971837',
                                            'apiKey' => '20251103095616508381',
                                                    'apiSecret' => 'j#JoEGjeMzYL)3gSjF3x!zkZ)pcWsJM&Fesd^Z(@kn34HPiS3!eqEqF24TKa',
                                                            'sunmi_phone' => '08582690357',
                                                                    'sunmi_password' => '690357',
                                                                        ],
    "TelegramServiceConfig" => [
        "host" => "https://tg-idn.transafe.co",
        "action" => ["rrn","RRN","risk_order_operate","withdrawCancelBatch","withdrawConfirm","withdrawCancel","withdrawConfirmNotice","withdrawConfirmNoticeBatch"],
    ],
];
